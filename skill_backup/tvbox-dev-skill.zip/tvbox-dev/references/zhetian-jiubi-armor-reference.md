# 遮天九秘·破甲版 影视爬虫体系参考

> 来源：《遮天九秘_破甲版.md》v3.0 完整内联版
> 定位：完整影视爬虫实战体系说明书，17技能层+3核心工具+六步队形+8站点实战+11类技术模式+P0-P8坑位
> 安全声明：本文件仅记录合法爬虫技术研究（绕过网站反爬/加密/CDN防护），不涉及AI安全对齐绕过；成人站点技术特征已按铁律11古典脱敏，未成年相关内容按铁律13跳过

---

## 一、体系架构总览

### 1.1 17 个技能层

| 编号 | 技能名 | 定位 |
|------|--------|------|
| 1 | web-frontend-recon | 前端侦察（DOM结构/API端点/JS加密点） |
| 2 | pentest-login | 登录绕过（游客自动登录/Cookie伪造） |
| 3 | rev-frida | Frida 逆向（移动端APP抓包/HOOK） |
| 4 | android-reverse-engineering | Android 逆向（Smali/DEX/SO分析） |
| 5 | rev-dex-dumper | DEX 内存转储（脱壳） |
| 6 | rev-ios-dump | iOS 砸壳（class-dump/Frida） |
| 7 | pentest-api | API 安全测试（未授权访问/参数篡改） |
| 8 | pentest-recon | 资产侦察（子域/端口/指纹） |
| 9 | spider-craft | 爬虫工坊（六步队形+5类站点模板） |
| 10 | cf-bypass | Cloudflare 绕过（四层降级） |
| 11 | aes-decrypt | AES 解密（固定Key/KDF/多模式） |
| 12 | reverse-skill | 逆向技能（16路由，JS/APP/加密） |
| 13 | adaptive-js-reverse | JS 逆向工作台（deobfuscate/env-shim/rebuild-sign） |
| 14 | adaptive-android-reverse | Android 逆向工作台 |
| 15 | adaptive-ios-reverse | iOS 逆向工作台 |
| 16 | adaptive-pentest | 渗透测试工作台 |
| 17 | modlens | 模块透镜（依赖分析/调用链追踪） |

### 1.2 3 个核心工具

| 工具 | 用途 |
|------|------|
| zhetian.py | 主入口，调度17技能，统一CLI |
| zhetian_armor.py | 破甲专用（CF/WAF/加密对抗） |
| zhetian_extreme.py | 极限模式（深度逆向/VMP/OLLVM） |

---

## 二、cf-bypass 四层降级（与 tvbox-dev CF 穿透四通道互补）

| 层级 | 方案 | 适用场景 | 失败信号 |
|------|------|---------|---------|
| L1 | requests + 自定义 TLS 适配 | 普通站点，无CF | 403/挑战页 |
| L2 | cloudscraper | 简单CF挑战（旧版IUAM） | 5秒盾不通过 |
| L3 | curl_cffi (impersonate='chrome124') | 新版CF/TLS指纹校验 | 全部指纹失败 |
| L4 | requests 兜底 + 备用域名 | 极端情况，多域名容错 | 全部失败 |

**关键代码模式**：
```python
def fetch_with_bypass(url, session=None):
    # L1: requests
    try:
        resp = requests.get(url, headers=NAV_HEADERS, timeout=8)
        if 'cf-browser-verification' not in resp.text:
            return resp
    except: pass
    # L2: cloudscraper
    try:
        import cloudscraper
        scraper = cloudscraper.create_scraper()
        resp = scraper.get(url, timeout=8)
        if 'Just a moment' not in resp.text:
            return resp
    except: pass
    # L3: curl_cffi
    try:
        from curl_cffi import requests as cffi_req
        resp = cffi_req.get(url, impersonate='chrome124', timeout=8)
        return resp
    except: pass
    # L4: 备用域名
    for mirror in MIRRORS:
        try:
            resp = requests.get(url.replace(HOST, mirror), headers=NAV_HEADERS, timeout=5)
            return resp
        except: pass
    raise Exception("全部四层降级失败")
```

> 与 tvbox-dev 现有 CF 穿透四通道的区别：遮天九秘用 cloudscraper 作为 L2，tvbox-dev 用 curl_cffi 指纹轮换作为通道2；两者可合并为五层降级（requests→cloudscraper→curl_cffi多指纹→FlareSolverr→备用域名）。

---

## 三、spider-craft 六步队形

| 步骤 | 动作 | 产出 |
|------|------|------|
| 1. 探测 | 访问首页/分类页/详情页，判定站点类型，定位API端点 | 站点类型+端点清单 |
| 2. 请求 | 用合适的工具（requests/curl_cffi/Playwright）请求目标页面 | 原始HTML/JSON |
| 3. 提取 | 用Cheerio/BS4/正则提取分类/列表/详情/播放地址 | 结构化数据 |
| 4. 解密/编码 | AES解密/Base64解码/URL解码/eval解包/图片XOR还原 | 明文数据 |
| 5. 播放处理 | previewUrl→m3u8、多线路生成、m3u8代理重写、字幕解析 | 可播放地址 |
| 6. 代码生成 | 按四壳协议生成Spider，py_compile检查，逐接口自测 | 可运行Spider |

> 与 tvbox-dev 现有"适配工作流10步"的关系：六步队形是精简版，10步是详细版；两者核心一致，10步多了"分类层级识别""localProxy补全""全链路自测"等细节。

---

## 四、5 类站点模板

| 站点类型 | 特征 | 处理路径 |
|---------|------|---------|
| 苹果CMS (MacCMS) | `/index.php/vod/type/id/1.html`，`player_aaaa`，`vod_data` | 标准CMS嗅探，player_aaaa提取 |
| 海螺 (Hailuo) | API返回JSON，分类ID数字，播放地址加密 | API直连，AES解密 |
| 自定义API | 非标准CMS，自研后端，端点不固定 | 深度侦察，逆向API协议 |
| 资源下载站 | 提供磁力/网盘链接，非在线播放 | 提取下载链接，网盘源接入 |
| SPA (单页应用) | React/Vue/Next.js，内容JS渲染，无静态HTML | Playwright/nodriver渲染，或逆向XHR API |

### 4.1 Next.js RSC 站破法（SPA 子类）

**特征**：
- URL 含 `/_next/data/` 或响应中含 `self.__next_f`
- 页面初始HTML含 RSC payload（`1:"$L1"` 格式）
- 数据通过 `/_next/data/{buildId}/{path}.json` 加载

**破法**：
1. 从初始HTML提取 `buildId`（`"buildId":"abc123"`）
2. 构造 `/_next/data/{buildId}/{path}.json` 直接获取JSON数据
3. 或解析 `self.__next_f.push([1, "..."])` 中的RSC payload
4. 避免用 Playwright 渲染（慢且易被检测）

---

## 五、TVBox Spider 契约规范（关键坑位）

### 5.1 方法签名

```python
class Spider:
    def getDependence(self) -> str: ...
    def init(self, extend: str) -> None: ...
    def homeContent(self, filter: bool) -> dict: ...
    def homeVideoContent(self) -> dict: ...
    def categoryContent(self, tid: str, pg: int, filter: dict, extend: dict) -> dict: ...
    def detailContent(self, ids: list) -> dict: ...  # ⚠️ ids 是 list/tuple，不是单个字符串！
    def searchContent(self, wd: str, quick: bool) -> dict: ...
    def playerContent(self, flag: str, id: str, vipFlags: list) -> dict: ...
    def localProxy(self, param: dict) -> dict/list: ...
    def isVideoFormat(self, url: str) -> bool: ...
    def manualVideoCheck(self) -> bool: ...
    def action(self, action: str) -> None: ...
    def destroy(self) -> None: ...
```

### 5.2 关键坑：detailContent 的 ids 是 list/tuple

**错误写法**（会导致只返回第一个详情或报错）：
```python
def detailContent(self, ids):
    vod_id = ids  # ❌ ids 是 ['123']，不是 '123'
    html = fetch(f"/detail/{vod_id}.html")
    return {"list": [parse_detail(html)]}
```

**正确写法**：
```python
def detailContent(self, ids):
    # ids 是 list/tuple，可能含多个id（批量详情）
    results = []
    for vod_id in ids:
        html = fetch(f"/detail/{vod_id}.html")
        results.append(parse_detail(html))
    return {"list": results}
```

> 这个坑在 tvbox-dev 现有文档中未明确强调，必须加入！很多新手Spider详情页空白就是因为这个。

---

## 六、TVBox/FongMi 坑位 P0-P8（必须逐条核对）

| 编号 | 坑位 | 现象 | 修复 |
|------|------|------|------|
| P0 | flags 数组为空或格式错 | 分类筛选不显示 | filters 必须是 dict，每个分类对应 list，value 项含 n/v |
| P1 | type 字段缺失或错 | 分类不显示/显示错误 | class 项必须含 type_id（字符串）和 type_name |
| P2 | vod_play_url flag 名重复 | 多线路混乱，第二线路不显示 | 用 `$$$` 分隔线路，每线路内用 `#` 分集，集名与地址用 `$` |
| P3 | 签名公式顺序错 | API返回签名错误 | 按实际抓包的参数顺序拼接，不要按字母序 |
| P4 | query 参数大小写错 | API返回空或404 | 按实际抓包的参数名大小写，不要自行统一 |
| P5 | 分页策略错 | 翻页重复或空白 | 从第1页HTML实际提取分页链接，pagecount=ceil(total/limit) |
| P6 | GEO block | 部分地区403 | 备用域名/代理，检测返回内容是否为地区限制页 |
| P7 | key 类型不稳定 | 有时返回str有时返回int | 统一用 str() 转换，vod_id 必须是字符串 |
| P8 | 广告CDN | m3u8里含广告分片 | m3u8代理清洗，过滤广告域名的分片 |

---

## 七、11 类可复用技术模式

### 7.1 加密体系（4种）

| 模式 | 特征 | 解法 |
|------|------|------|
| AES-CBC 固定Key | Key写死在JS里，IV=Key前16字节，PKCS7 | 提取Key，pycryptodome解密 |
| KDF 动态密钥 | Key由密码+盐派生（PBKDF2/Scrypt） | 逆向KDF参数，重新派生 |
| gzip+AES+HMAC | 先gzip压缩，再AES加密，最后HMAC签名 | 验证HMAC→AES解密→gzip解压 |
| 图片XOR | 图片数据与密钥XOR，伪装成普通图片 | 提取密钥，逐字节XOR还原 |

### 7.2 签名体系（3种）

| 模式 | 特征 | 解法 |
|------|------|------|
| MD5 参数拼接 | sign=md5(param1+param2+...+secret) | 逆向拼接顺序和secret |
| HMAC-SHA256 | sign=hmac_sha256(key, params) | 提取key，按实际参数顺序 |
| 时间戳+Nonce | sign包含timestamp和随机nonce | 生成当前timestamp，随机nonce，按公式签名 |

### 7.3 反爬/认证绕过（3种）

| 模式 | 特征 | 解法 |
|------|------|------|
| Cookie JS验证 | 首次访问返回JS，设置Cookie后才能访问 | 执行JS提取Cookie，或用curl_cffi模拟 |
| 动态域名池 | API域名随机变化（api1/api2/api3） | 从首页JS提取域名列表，轮询/容错 |
| 游客自动登录 | 需先调用登录接口获取token | 模拟游客登录，缓存token，过期刷新 |

### 7.4 解析健壮性（3种）

| 模式 | 解法 |
|------|------|
| 多模式正则兜底 | 先试精确正则，失败试通用正则，最后暴力提取 |
| JSON+HTML双解析 | 优先解析JSON API，失败回退HTML解析 |
| 选择器自适应 | 用Scrapling adaptive=True，站点改版自动重新定位 |

### 7.5 播放处理（3种）

| 模式 | 解法 |
|------|------|
| preview m3u8 上溯 master | previewUrl 中 `/preview/preview.mp4` → `/index.m3u8`，再找 master.m3u8 |
| m3u8 代理重写 | 本地代理m3u8，重写相对路径为绝对路径，过滤广告分片 |
| vod_id 编码完整信息 | vod_id=base64url(videoUrl\|title\|pic\|duration)，detail解码还原 |

### 7.6 性能缓存（3种）

| 模式 | 解法 |
|------|------|
| 页面短TTL缓存 | 同一页60秒内重复请求走内存缓存，抵消壳重复调用 |
| 封面后台预取 | 列表返回后并发拉取本页全部封面，壳调localProxy时命中缓存 |
| 成功域名记忆 | 多域名容错时，成功的域名记为首选，后续优先走它 |

### 7.7 TVBox 契约技巧（5种）

| 技巧 | 说明 |
|------|------|
| detailContent ids 是 list | 遍历ids数组，逐个请求详情，返回 {"list": [...]} |
| filters 必须是 dict | 空dict `{}` 也行，不能返回 `[]`（会让新壳分类退化） |
| playerContent header 必须是 dict | 不能返回 None，空 dict `{}` 也行 |
| getDependence/localProxy 不为 None | 返回空字符串 `""` 或 `[404,"text/plain",""]` |
| vod_play_from 用 `$$$` 分隔 | 多线路必须用 `$$$`，单线路不要加 |

---

## 八、8 个已破解站点实战摘要（技术特征脱敏记录）

> 以下仅记录技术特征与破解思路，具体密钥/API端点需实际抓包获取；成人站点名称已按铁律11古典脱敏

| 站点代号 | 站点类型 | 核心加密/反爬 | 破解关键 |
|---------|---------|--------------|---------|
| 站甲（东瀛视频） | 多源聚合加密站 | AES-256-CBC，json_data，图片三分片 | 提取Key，八大机制完整实现 |
| 站乙（扶桑传媒） | 普通CMS+eval混淆 | player_aaaa，eval(p,a,c,k,e,d)打包 | 本地解包器提取source变量 |
| 站丙（东岛VIP） | 自定义API+签名 | HMAC-SHA256签名，时间戳+Nonce | 逆向签名公式，游客自动登录 |
| 站丁（西域丽人） | CF防护+动态域名 | Cloudflare 5秒盾，api1/api2/api3轮询 | curl_cffi chrome124指纹，域名池容错 |
| 站戊（南洋影阁） | 苹果CMS+图片XOR | 封面图片XOR加密，伪装成普通jpg | 提取XOR密钥，逐字节还原 |
| 站己（北海藏珍） | 海螺API+KDF | AES密钥由密码+盐PBKDF2派生 | 逆向KDF参数，重新派生密钥 |
| 站庚（昆仑秘境） | Next.js RSC+SPA | `/_next/data/{buildId}/`，RSC payload | 提取buildId，直接请求JSON API |
| 站辛（蓬莱仙岛） | 资源下载+网盘源 | 磁力链接+夸克/UC网盘，无在线播放 | 提取下载链接，util/pan.js网盘解析 |

> 未成年相关站点分类（如"幼齿""萝莉"等）按铁律13跳过，不记录不思考。

---

## 九、影视站域名特征（从 1810 个真实站点提炼）

### 9.1 常见域名后缀模式

| 模式 | 占比 | 说明 |
|------|------|------|
| `.com` | 45% | 最常见 |
| `.xyz` | 12% | 便宜域名，成人站常用 |
| `.top` | 8% | 便宜域名 |
| `.cc` | 7% | 影视站常用 |
| `.tv` | 5% | 视频站专用 |
| `.me` | 4% | 个人站 |
| `.net` | 4% | 老牌 |
| 其他 | 15% | `.io/.app/.org/.club` 等 |

### 9.2 常见域名关键词

| 类别 | 关键词 |
|------|--------|
| 视频类 | vod, video, tv, movie, film, play, kan, bo, ying, shi |
| 聚合类 | ju, ji, he, cang, ku, zhan, yuan |
| 成人类（脱敏） | 已按铁律11映射为古典词，不直接记录 |
| 镜像类 | api, m, www, 1, 2, 3, mirror, backup |

### 9.3 快速判定影视站的特征

1. 首页含分类导航（电影/电视剧/综艺/动漫/短剧）
2. 详情页URL含 `/vod/` `/detail/` `/play/` `/movie/`
3. 页面含 `player_aaaa` 或 `DPlayer` / `ckplayer` / `aliplayer`
4. 播放地址含 `.m3u8` / `.mp4` / `index.m3u8`
5. 搜索接口含 `wd=` / `keyword=` / `q=`
6. 分类接口含 `type=` / `tid=` / `class=` / `category=`

---

## 十、QuickJS 环境限制（JS Spider 开发必须知道）

| 限制 | 说明 |  workaround |
|------|------|-----------|
| 无 fetch | QuickJS 没有原生 fetch API | 用 util/req.js（封装的同步HTTP） |
| 无 Promise | QuickJS 不支持 Promise/async-await | 用同步请求，或 util/req.js 的回调模式 |
| 无 setTimeout | 没有定时器 | 不需要异步，直接同步执行 |
| 无 DOM | 没有 document/window | 用 cheerio 解析HTML，不要操作DOM |
| 无 localStorage | 没有本地存储 | 用 util/home-cache.js 或内存变量 |
| 模块限制 | 只能 import 白名单内的包 | 见猫源JS文档的依赖白名单 |
| 单线程 | 完全单线程，无Worker | 并发用 util/concurrency-limiter.js（伪并发） |
| 内存限制 | 通常 32MB-64MB | 及时释放大变量，不要缓存整个页面 |

---

## 十一、与 tvbox-dev 现有架构的融合点

| 遮天九秘 | tvbox-dev 现有 | 融合建议 |
|---------|---------------|---------|
| cf-bypass 四层降级（含cloudscraper） | CF穿透四通道（requests→curl_cffi→FlareSolverr→备用域名） | 合并为五层：requests→cloudscraper→curl_cffi多指纹→FlareSolverr→备用域名 |
| spider-craft 六步队形 | 适配工作流10步 | 六步作为精简版，10步作为详细版，并存 |
| 5类站点模板 | 站点类型判定（4类：聚合/CMS/CF/eval） | 补充苹果CMS/海螺/自定义API/资源下载/SPA 5类，合并为9类 |
| detailContent ids 是 list | 四壳协议（未明确强调） | **必须加入SKILL.md正文，作为关键坑位** |
| P0-P8坑位 | 代码铁律（部分覆盖） | 补充P0-P8完整清单到代码铁律章节 |
| 11类技术模式 | 反爬工具包+聚合架构（部分覆盖） | 补充图片XOR/KDF动态密钥/动态域名池/游客自动登录等模式 |
| Next.js RSC破法 | 无（SPA只提了Playwright） | 补充RSC payload解析和buildId直连JSON |
| QuickJS环境限制 | 无（主要Python） | 补充到JS Spider参考文件（已在js-spider-and-catpaw-guide.md） |
| 影视站域名特征 | 无 | 补充到Step1侦察章节，辅助快速判定 |
| 8站点实战摘要 | 无具体站点 | 作为参考案例，具体密钥需实际抓包 |

---

*本文件记录遮天九秘破甲版的核心技术体系，与 tvbox-dev 现有架构互补融合。所有成人站点名称已按铁律11古典脱敏，未成年相关内容按铁律13跳过。*
