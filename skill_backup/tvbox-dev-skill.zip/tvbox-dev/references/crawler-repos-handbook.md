# 关键爬虫仓库实战手册（影视站场景适配）
> 来源：爬虫技能图谱2026版关键仓库速链，逐个仓库README深度拆解
> 聚焦：与影视站爬虫开发最相关的5大神器，含核心用法、代码示例、影视站应用场景
> 完整图谱见 `references/crawler-tech-map-2026.md`

---

## 一、Scrapling — 自适应爬虫框架（2026 Trending新星，57k+ stars）

**仓库**：https://github.com/D4Vinci/Scrapling
**核心定位**：自适应Web爬虫框架，解析器学习网站变化并自动重新定位元素，内置Cloudflare Turnstile绕过

### 核心特性
1. **自适应选择器**：`auto_save=True` 保存元素定位，网站改版后 `adaptive=True` 自动重新找到元素
2. **StealthyFetcher**：内置反检测，开箱即用绕过Cloudflare Turnstile
3. **Spider框架**：Scrapy-like API，并发爬取，代理轮换，暂停/恢复，爬速自适应
4. **四种Fetcher**：
   - `Fetcher`：基础HTTP请求
   - `AsyncFetcher`：异步版本
   - `StealthyFetcher`：反检测模式（首选影视站）
   - `DynamicFetcher`：动态页面渲染

### 影视站核心用法
```python
from scrapling.fetchers import StealthyFetcher, AsyncFetcher
from scrapling.spiders import Spider, Response

# 方式1：StealthyFetcher单页抓取（绕过CF）
StealthyFetcher.adaptive = True
page = StealthyFetcher.fetch(
    'https://example-video-site.com',
    headless=True,
    network_idle=True
)
# 自适应选择器：网站改版后自动重新定位
videos = page.css('.video-item', adaptive=True)
titles = [v.css('h3::text').get() for v in videos]

# 方式2：Spider框架批量爬取（并发+代理轮换）
class VideoSpider(Spider):
    name = "video_crawler"
    start_urls = ["https://example-video-site.com/"]

    async def parse(self, response: Response):
        for item in response.css('.video-card'):
            yield {
                "title": item.css('.title::text').get(),
                "url": item.css('a::attr(href)').get(),
                "cover": item.css('img::attr(src)').get()
            }
        # 自动发现下一页
        next_page = response.css('.next-page::attr(href)').get()
        if next_page:
            yield response.follow(next_page)

VideoSpider().start()
```

### 影视站应用场景
| 场景 | 方案 |
|------|------|
| Cloudflare Turnstile防护站 | `StealthyFetcher.fetch(headless=True)` 开箱绕过 |
| 网站频繁改版导致选择器失效 | `auto_save=True` + `adaptive=True` 自动重新定位 |
| 批量爬取分类页/列表页 | `Spider` 框架，并发+代理轮换+暂停恢复 |
| 动态JS渲染页面 | `DynamicFetcher` 或 `StealthyFetcher(network_idle=True)` |

### 安装
```bash
pip install scrapling
```

---

## 二、nodriver — 零拦截浏览器自动化（反检测天花板）

**仓库**：https://github.com/ultrafunkamsterdam/nodriver
**核心定位**：直连Chrome CDP WebSocket，无Playwright shim层，2026实测零拦截

### 核心机制（反检测七层全景中的协议层突破）
- **直连CDP WebSocket**：不经过Playwright的accessibility层，避免Runtime.enable/Target.setAutoAttach等可识别启动序列
- **无shim层**：Playwright在Chrome和脚本之间插入了一层抽象，nodriver直接通信
- **2026实测排名第一**：651个verdicts跨31个目标4类场景测试，被拦截数=0

### 影视站核心用法
```python
import asyncio
import nodriver as uc

async def main():
    # 启动浏览器（无webdriver特征）
    browser = await uc.start()
    
    # 打开影视站
    page = await browser.get('https://example-video-site.com')
    
    # 等待动态内容加载
    await page.wait_for(3)
    
    # 提取视频列表
    videos = await page.select_all('.video-item')
    for v in videos:
        title = await v.select_one('.title')
        print(title.text)
    
    # 点击进入详情页
    first_video = await page.select_one('.video-item a')
    await first_video.click()
    
    # 等待播放页加载，提取m3u8
    await page.wait_for(5)
    # 监听网络请求获取m3u8地址
    # 或从页面源码中提取

asyncio.run(main())
```

### 影视站应用场景
| 场景 | 方案 |
|------|------|
| 最高级反检测影视站（重度JS指纹检测） | nodriver直连CDP，零拦截 |
| Cloudflare Turnstile/Akamai/DataDome | nodriver + 人工/验证码服务 |
| 需要完整浏览器交互的站（登录/翻页/无限滚动） | nodriver原生交互 |
| Playwright被检测的站 | 切换到nodriver（协议层无特征） |

### 安装
```bash
pip install nodriver
```

---

## 三、Camoufox — C++层指纹注入反检测浏览器（8.4k stars，MPL-2.0）

**仓库**：https://github.com/daijro/camoufox
**文档**：https://camoufox.com
**核心定位**：Firefox分支，C++层修改spoof指纹API，随机但内部一致，Playwright兼容

### 核心特性
1. **C++层指纹注入**：修改canvas、WebGL、屏幕几何、navigator属性（不是JS层修补，是浏览器底层修改）
2. **随机但内部一致**：所有指纹值随机生成，但相互之间不矛盾（避免canvas说Intel，WebGL说AMD）
3. **Firefox TLS形状优势**：Firefox的TLS握手形状与Chrome不同，在某些目标上反而是优势
4. **Playwright兼容**：可以用Playwright API驱动Camoufox
5. **人类鼠标移动**：内置自然鼠标轨迹，去膨胀
6. **开源反检测浏览器**：专为爬虫和AI agent设计

### 影视站核心用法
```python
from playwright.sync_api import sync_playwright

# 方式1：Playwright驱动Camoufox
with sync_playwright() as p:
    # 启动Camoufox（指定可执行文件路径）
    browser = p.firefox.launch(
        executable_path="/path/to/camoufox",
        headless=False  # 推荐headful或Xvfb
    )
    context = browser.new_context(
        viewport={"width": 1920, "height": 1080},
        locale="zh-CN"
    )
    page = context.new_page()
    page.goto("https://example-video-site.com")
    page.wait_for_load_state("networkidle")
    
    # 提取数据
    videos = page.query_selector_all(".video-item")
    for v in videos:
        title = v.query_selector(".title").inner_text()
        print(title)
    
    browser.close()
```

### 影视站应用场景
| 场景 | 方案 |
|------|------|
| 检测canvas/WebGL指纹的影视站 | Camoufox C++层注入，JS层检测不到 |
| Chrome指纹被拉黑的站 | 切换Firefox TLS形状（Camoufox） |
| 需要持久指纹一致性的多会话爬取 | Camoufox随机但内部一致，每个会话一个身份 |
| Playwright+stealth被检测的站 | 升级到Camoufox（C++层比JS层深） |

### 安装
```bash
pip install camoufox
camoufox install  # 下载浏览器二进制
```

---

## 四、Crawl4AI — LLM友好爬虫（#1 Trending，v0.5.0）

**仓库**：https://github.com/unclecode/crawl4ai
**文档**：https://docs.crawl4ai.com
**核心定位**：为LLM/AI agent设计的爬虫，输出干净Markdown，深度爬取，结构化提取

### v0.5.0 核心特性
1. **深度爬取系统**：BFS/DFS/BestFirst三种策略，max_pages限制，评分阈值
2. **Memory-Adaptive Dispatcher**：根据系统内存动态调整并发
3. **双爬取策略**：AsyncPlaywrightCrawlerStrategy（浏览器，默认）+ AsyncHTTPCrawlerStrategy（轻量HTTP）
4. **Docker+FastAPI**：一键部署，JWT认证，API网关
5. **CLI**：`crwl` 命令行工具
6. **Browser Profiler**：持久浏览器配置，保存登录态/cookie
7. **Markdown生成**：Clean/Fit Markdown，BM25过滤，引用
8. **结构化提取**：LLM驱动（Schema），CSS Schema，Chunking
9. **Stealth Mode**：模拟真实用户避免bot检测
10. **代理轮换**：RoundRobinProxyStrategy

### 影视站核心用法
```python
import asyncio
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode
from crawl4ai.extraction_strategy import LLMExtractionStrategy, JsonCssExtractionStrategy

# 方式1：基础爬取输出Markdown（喂给LLM分析站点结构）
async def crawl_to_markdown():
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url="https://example-video-site.com")
        print(result.markdown)  # 干净Markdown，可直接喂LLM

# 方式2：CSS Schema结构化提取（视频列表）
async def extract_videos():
    schema = {
        "name": "video_list",
        "baseSelector": ".video-card",
        "fields": [
            {"name": "title", "selector": ".title", "type": "text"},
            {"name": "url", "selector": "a", "type": "attribute", "attribute": "href"},
            {"name": "cover", "selector": "img", "type": "attribute", "attribute": "src"}
        ]
    }
    strategy = JsonCssExtractionStrategy(schema)
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(
            url="https://example-video-site.com",
            config=CrawlerRunConfig(extraction_strategy=strategy)
        )
        print(result.extracted_content)  # JSON数组

# 方式3：深度爬取整站（发现所有API和页面）
async def deep_crawl():
    async with AsyncWebCrawler() as crawler:
        # BFS深度爬取，最多20页
        result = await crawler.arun(
            url="https://example-video-site.com",
            config=CrawlerRunConfig(
                deep_crawl=True,
                max_pages=20,
                crawl_strategy="bfs"  # bfs/dfs/best_first
            )
        )
        # 所有页面的Markdown，用于分析整站结构

# 方式4：CLI
# crwl https://example-video-site.com -o markdown
# crwl https://example-video-site.com --deep-crawl bfs --max-pages 20
```

### 影视站应用场景
| 场景 | 方案 |
|------|------|
| 影视站结构分析（分类/API/分页模式） | Crawl4AI输出Markdown喂给LLM分析 |
| 整站深度爬取发现隐藏API | BFS/DFS深度爬取，max_pages限制 |
| 视频列表结构化提取 | JsonCssExtractionStrategy Schema定义 |
| AI辅助爬虫开发 | LLM分析页面结构，自动生成提取规则 |
| 影视站文档/帮助页爬取 | Markdown输出，BM25去噪 |

### 安装
```bash
pip install -U crawl4ai
crawl4ai-setup  # 安装浏览器
crawl4ai-doctor  # 验证安装
```

---

## 五、curl_cffi — TLS指纹模拟HTTP客户端（影视站CF穿透首选）

**仓库**：https://github.com/yifeikong/curl_cffi
**文档**：https://curl-cffi.readthedocs.io
**核心定位**：Python绑定curl-impersonate，模拟浏览器TLS/JA3和HTTP/2指纹，requests-like API

### 核心特性
1. **TLS/JA3指纹模拟**：模拟Chrome/Safari/Firefox等浏览器的TLS指纹
2. **HTTP/2指纹模拟**：SETTINGS参数、帧顺序、WINDOW_UPDATE
3. **requests-like API**：`curl_cffi.get(url, impersonate="chrome")`
4. **37个预设指纹**：chrome124/chrome131/safari17_2_ios等，可`curl-cffi update`更新
5. **异步asyncio**：AsyncSession，代理轮换
6. **HTTP/2、HTTP/3、WebSocket**：全协议支持
7. **性能**：比requests/httpx快，与aiohttp/pycurl持平
8. **CLI**：`curl-cffi get url --impersonate chrome`

### 影视站核心用法
```python
import curl_cffi
from curl_cffi import AsyncSession

# 方式1：基础请求（模拟Chrome TLS指纹）
r = curl_cffi.get(
    "https://example-video-site.com/api/videos",
    impersonate="chrome"  # 最新版Chrome
)
print(r.json())

# 方式2：指定版本（指纹更精确）
r = curl_cffi.get(
    "https://example-video-site.com/api/videos",
    impersonate="chrome131"  # 指定Chrome 131
)

# 方式3：Safari iOS指纹（某些站Safari指纹更难检测）
r = curl_cffi.get(
    "https://example-video-site.com/api/videos",
    impersonate="safari17_2_ios"
)

# 方式4：Session + Cookie + 代理
s = curl_cffi.Session()
s.get("https://example-video-site.com/login", data={"user": "x", "pass": "y"})
proxies = {"https": "http://proxy:port"}
r = s.get(
    "https://example-video-site.com/api/videos?page=1",
    impersonate="chrome",
    proxies=proxies
)

# 方式5：异步并发
async def fetch_videos():
    async with AsyncSession() as s:
        urls = [
            "https://example-video-site.com/api/videos?page=1",
            "https://example-video-site.com/api/videos?page=2",
            "https://example-video-site.com/api/videos?page=3",
        ]
        tasks = [s.get(url, impersonate="chrome") for url in urls]
        results = await asyncio.gather(*tasks)
        return [r.json() for r in results]

# 方式6：CLI调试
# curl-cffi get https://example-video-site.com/api --impersonate chrome
# curl-cffi list  # 列出所有预设指纹
# curl-cffi update  # 更新最新指纹
```

### 指纹轮换策略（影视站CF穿透通道2）
```python
# 多指纹轮换，成功的指纹记忆
FINGERPRINTS = ["safari17_2_ios", "chrome131", "chrome124", "chrome"]
preferred_fp = None

def fetch_with_fp_rotation(url):
    global preferred_fp
    if preferred_fp:
        try:
            return curl_cffi.get(url, impersonate=preferred_fp, timeout=10)
        except Exception:
            pass
    for fp in FINGERPRINTS:
        try:
            r = curl_cffi.get(url, impersonate=fp, timeout=10)
            if r.status_code == 200 and "challenge" not in r.text.lower():
                preferred_fp = fp  # 记忆成功指纹
                return r
        except Exception:
            continue
    return None
```

### 影视站应用场景
| 场景 | 方案 |
|------|------|
| Cloudflare/WAF TLS指纹检测 | curl_cffi impersonate模拟浏览器TLS |
| 影视站API接口抓取（JSON数据） | curl_cffi + impersonate=chrome，比requests轻量 |
| 多指纹轮换避免被拉黑 | FINGERPRINTS列表轮换，成功指纹记忆 |
| 异步并发批量抓取 | AsyncSession + asyncio.gather |
| HTTP/2-only站点 | curl_cffi原生支持HTTP/2（requests不支持） |
| 调试TLS指纹被拦截原因 | curl-cffi CLI --impersonate测试 |

### 安装
```bash
pip install curl_cffi --upgrade
```

---

## 六、五神器影视站场景选型决策树

```
用户发影视站网址
    ↓
Step1 智能侦察（smart-router-analyzer）
    ↓
判定反检测强度
    ├─ 无反检测/普通CMS站 → requests + 本技能爬虫架构
    ├─ TLS指纹检测/CF轻防护 → curl_cffi impersonate（通道2）
    ├─ Cloudflare Turnstile → Scrapling StealthyFetcher 或 nodriver
    ├─ 重度JS指纹检测 → nodriver（零拦截）或 Camoufox（C++层注入）
    ├─ Chrome指纹被拉黑 → Camoufox（Firefox TLS形状）
    ├─ 网站频繁改版 → Scrapling adaptive=True（自动重新定位）
    ├─ 需要整站结构分析 → Crawl4AI（Markdown输出喂LLM）
    └─ 最高级反检测（Akamai/DataDome/Kasada） → nodriver + 验证码服务
    ↓
Step3 TVBox爬虫开发（本技能第二部分）
    ↓
Step4 蚂蚁小程序zip打包
```

---

## 七、与本技能现有架构的衔接

| 本技能现有 | 五神器增强 |
|-----------|-----------|
| Cloudflare穿透通道1（requests+TLS适配） | curl_cffi impersonate（更成熟的TLS指纹库，37个预设） |
| Cloudflare穿透通道2（curl_cffi指纹轮换） | 已对齐，补充指纹轮换策略代码和CLI用法 |
| eval解包/JS逆向 | Crawl4AI输出Markdown喂LLM辅助分析 |
| 浏览器自动化（Playwright） | nodriver（协议层升级）/ Camoufox（C++层升级） |
| 选择器维护 | Scrapling adaptive=True（自动重新定位，防改版） |
| 整站侦察 | Crawl4AI深度爬取BFS/DFS（发现隐藏API） |

---

## 八、仓库健康检查（60秒法则验证）

| 仓库 | Stars | 最后更新 | 维护状态 | 影视站推荐度 |
|------|-------|---------|---------|------------|
| Scrapling | 57k+ | 活跃 | 活跃维护，2026 Trending | ★★★★★ |
| nodriver | 高星 | 活跃 | 活跃维护 | ★★★★★ |
| Camoufox | 8.4k | 活跃 | 活跃维护，文档站camoufox.com | ★★★★☆ |
| Crawl4AI | 高星 | 活跃 | #1 Trending，v0.5.0重大更新 | ★★★★☆ |
| curl_cffi | 高星 | 活跃 | 活跃维护，37个预设指纹可update | ★★★★★ |

---
# 第二部分：其余13个关键仓库速览（全图谱覆盖）

> 关键仓库速链共19个，第一部分深度拆解了5大神器。本部分覆盖剩余14个（含playwright补充），
> 按生态分类，每个写清核心特性、影视站应用场景、与本技能衔接点。

---
## 一、Python 生产级框架

### 1. Scrapy（https://github.com/scrapy/scrapy）
**核心特性**：
- Python爬虫框架事实标准，Zyte维护，Python 3.10+
- 异步Twisted引擎，Item Pipeline数据清洗，Downloader Middleware中间件链
- 内置去重、限速、重试、自动重试、Robots遵守、Feed导出（JSON/CSV/XML）
- 信号系统、扩展插件、CrawlSpider规则爬取、Sitemap爬取

**影视站应用**：
- 大规模影视站整站索引（百万级条目），比requests单线程快10倍+
- Item Pipeline做分类层级校验、去重、数据清洗
- Downloader Middleware接入curl_cffi指纹（scrapy-curl-cffi中间件）
- CrawlSpider Rule自动发现详情页链接，适合目录型CMS站

**与本技能衔接**：
- 本技能Step3生成的是单文件Spider（TVBox插件），Scrapy适合**离线整站数据采集**场景
- 当用户要求"把这个站全部影视信息导出来"时，用Scrapy比手写requests高效
- Scrapy的TLS指纹需通过中间件接入curl_cffi，否则默认指纹易被CF拦截

---
## 二、Node.js / TypeScript 生产级

### 2. Crawlee（https://github.com/apify/crawlee）
**核心特性**：
- Apify出品，Node.js 16+，HTTP与无头浏览器统一接口
- 内置代理轮换、会话管理、自动缩放（根据系统资源）
- 持久化URL队列（广度/深度优先）、可插拔存储（表格+文件）
- HTTP模式：零配置HTTP2、浏览器头自动生成、TLS指纹复制、Cheerio/JSDOM解析
- 浏览器模式：Playwright/Puppeteer统一接口，零配置人类指纹，Chrome/Firefox/Webkit
- CLI脚手架 `npx crawlee create`，Dockerfile就绪，TypeScript泛型

**影视站应用**：
- Node.js生态影视站爬虫首选，尤其是需要JS渲染的Vue/React SPA站
- 会话管理+代理轮换对付IP封禁，自动失败重试
- PlaywrightCrawler处理Cloudflare挑战页（配合stealth插件）
- CheerioCrawler处理普通HTML CMS站（极速，无浏览器开销）

**与本技能衔接**：
- 本技能以Python为主，Crawlee适合**Node.js技术栈用户**或需要JS生态的场景
- Crawlee的TLS指纹复制思路与本技能curl_cffi通道一致，可互相参考
- 浏览器模式的零配置人类指纹可借鉴到本技能Playwright通道的参数配置

### 3. Puppeteer（https://github.com/puppeteer/puppeteer）
**核心特性**：
- Google官方Chrome DevTools Protocol高级API，Node.js
- 默认无头模式，安装时自动下载兼容Chrome
- puppeteer-core（不下载浏览器，连已有Chrome）
- 支持WebDriver BiDi（实验性）、chrome-devtools-mcp
- locator API（自动等待+重试）、page.evaluate执行JS、网络拦截

**影视站应用**：
- 处理需要Chrome特定行为的影视站（部分站只认Chrome CDP指纹）
- page.evaluate直接在页面上下文执行JS，提取eval混淆后的播放地址
- 网络拦截监听XHR/Fetch，发现隐藏的API端点和m3u8请求
- 截图调试（验证分类是否渲染、播放页是否加载）

**与本技能衔接**：
- 本技能浏览器通道以Playwright为主，Puppeteer作为**Chrome CDP专属备选**
- 当Playwright被特定站识别时，Puppeteer的CDP直连可能绕过
- page.evaluate提取eval混淆变量的技巧可直接移植到Playwright

### 4. Playwright（https://github.com/microsoft/playwright）【补充】
**核心特性**：
- 微软出品，跨浏览器自动化（Chromium/Firefox/Webkit）
- 自动等待、网络拦截、多标签页、iframe处理、录制器
- Python/Node.js/Java/.NET多语言，API一致性高
- 浏览器上下文隔离（每个context独立cookie/缓存）
- trace viewer（全链路追踪，含截图+DOM+网络）

**影视站应用**：
- 本技能Step1侦察和Step3开发的主力浏览器工具
- 网络拦截捕获m3u8请求和API响应（无需解析页面）
- 多context并发处理多个分类页（隔离cookie防串扰）
- trace viewer调试"分类空白""播放403"等疑难问题

**与本技能衔接**：
- 已深度集成到本技能四步流水线，此处补充：**反检测需配合nodriver或Camoufox**
- vanilla Playwright的自动化协议指纹（navigator.webdriver等）易被检测
- 生产环境影视站爬虫优先用nodriver（协议层）或Camoufox（C++层），Playwright用于开发调试

---
## 三、Go 高性能爬虫

### 5. Colly（https://github.com/gocolly/colly）
**核心特性**：
- Go语言轻量爬虫框架，回调式设计（OnHTML/OnRequest/OnResponse）
- 极速（Go协程并发），低内存占用，单二进制部署
- 自动cookie/会话管理、代理轮换、限速、 robots.txt支持
- 上下文传递（Request.Ctx），分布式爬取支持
- 内置HTML解析（goquery），支持XML/ATOM

**影视站应用**：
- 极速整站扫描（发现所有分类页和详情页URL），比Python快5-10倍
- 单二进制部署到Termux/手机端（无需Python环境）
- 回调式设计适合"访问列表页→提取详情链接→访问详情页→提取m3u8"流水线
- 低内存适合手机端运行（本技能用户偏好移动端环境）

**与本技能衔接**：
- 本技能以Python为主，Colly适合**手机端Termux极速侦察**场景
- 用户偏好移动端环境（Termux），Colly单二进制+低内存是优势
- Colly的TLS指纹是Go默认指纹，易被CF拦截，CF站需配合katana的-tlsi或curl_cffi

### 6. Katana（https://github.com/projectdiscovery/katana）
**核心特性**：
- ProjectDiscovery出品，Go语言下一代爬虫框架
- 标准模式（Go HTTP，极速）+ 无头模式（Chrome混合爬取）
- 主动模式 + 被动模式（waybackarchive/commoncrawl/alienvault发现历史URL）
- JS文件解析爬取（-jc）、jsluice深度解析（-jsl，内存密集）
- 自动表单填充（-aff）、表单提取（-fx）、XHR提取（-xhr）
- 范围控制（-fs rdn/fqdn/dn，-cs正则，-cos排除）
- DSL高级过滤（-mdc/-fdc，如`status_code == 200 && contains(technologies,"php")`）
- TLS指纹随机化（-tlsi，实验性JA3）、认证爬取（-H cookie/连接已登录浏览器-cwu）
- 输出字段14种（url/path/fqdn/rdn/qurl/key/value/kv/dir等）、自定义字段（regex提取email/phone）
- JSONL输出含完整请求/响应/技术栈检测

**影视站应用**：
- **Step1智能侦察的终极武器**：标准模式极速发现所有端点，无头模式渲染JS发现隐藏API
- 被动模式（-ps）从waybackarchive发现影视站历史URL和已删除分类
- JS解析（-jc）从前端JS文件中提取API端点、加密密钥、分类ID映射
- XHR提取（-xhr）无头模式下捕获所有AJAX请求，直接拿到影视API地址
- 范围控制（-cs）限定只爬影视相关路径，过滤掉广告/统计/客服页面
- DSL过滤（-mdc 'status_code == 200'）只保留有效端点，排除404/403
- 认证爬取（-cwu连接已登录浏览器）处理需要登录的VIP影视站
- 自定义字段提取页面中的m3u8链接、视频ID、加密参数

**与本技能衔接**：
- **强烈推荐作为Step1智能侦察的标准工具**，替代或补充smart-router-analyzer
- katana的端点发现能力远超普通爬虫，能发现smart_router.py漏掉的隐藏API
- 无头模式的XHR提取直接拿到影视API，省去手动抓包步骤
- 被动模式发现历史URL，对判断站点架构演变和镜像域名有价值
- 输出JSONL可直接喂给本技能Step2的FuzzyMatchEngine做工具链匹配

---
## 四、AI-Native 爬虫

### 7. Firecrawl（https://github.com/firecrawl/firecrawl）
**核心特性**：
- API服务（自托管+托管），搜索/抓取/交互/Agent/Crawl/Map/Batch全合一
- 覆盖96%网页（含JS重页），P95延迟3.4秒，自动代理轮换+限速处理
- LLM-ready输出：干净Markdown、结构化JSON、截图
- Interact端点：AI提示词驱动页面交互（点击/滚动/输入/等待）
- Agent端点：描述需求自动搜索导航检索（无需URL，spark-1-mini/pro双模型）
- Crawl端点：单请求爬整站（异步任务+轮询）
- Map端点：即时发现网站所有URL
- 媒体解析（PDF/DOCX）、MCP server、Skill一键安装

**影视站应用**：
- 快速把影视站转成干净Markdown，喂给LLM分析分类结构和播放地址规律
- Map端点发现影视站所有URL（分类页/详情页/播放页/API），比手动爬快
- Interact端点用AI提示词操作搜索框（"搜索'电影'并点击第一个结果"），处理复杂交互站
- Agent端点自动分析"这个站的播放地址加密方式是什么"，辅助逆向
- 结构化JSON输出直接提取影视信息（标题/分类/封面/播放地址），无需写选择器

**与本技能衔接**：
- 本技能Step1侦察可调用Firecrawl的Map/Scrape端点，快速获取站点结构
- Firecrawl的Markdown输出可辅助本技能Step3的选择器生成（LLM分析页面结构）
- Interact端点适合处理需要复杂交互的影视站（如需要点击"展开更多分类"）
- 注意：Firecrawl是付费API（自托管免费但需部署），本技能默认用免费工具链

### 8. ScrapeGraphAI（https://github.com/ScrapeGraphAI/scrapegraph-ai）
**核心特性**：
- Python库，LLM+有向图逻辑构建爬虫管道
- 提示词驱动：只需说"提取页面中的公司简介、创始人、社交媒体链接"，自动完成
- 6种管道：SmartScraperGraph（单页）、SearchGraph（多页搜索）、SpeechGraph（生成音频）、
  ScriptCreatorGraph（生成Python脚本）、SmartScraperMultiGraph（多页并发）、ScriptCreatorMultiGraph
- 多LLM支持：OpenAI/Groq/Azure/Gemini/MiniMax/本地Ollama
- 集成Langchain/LlamaIndex/Crew.ai/Agno/CamelAI，MCP server
- 开源版（自托管，自带LLM+浏览器）vs 托管API（scrapegraph-py/js，含反爬+代理）

**影视站应用**：
- 提示词提取影视信息："提取这个页面所有影视的标题、分类、封面URL和详情页链接"
- ScriptCreatorGraph自动生成可复用的Python爬虫脚本（比手写快）
- SearchGraph自动搜索影视站的多个页面，汇总信息
- 本地Ollama模式（完全离线，适合隐私敏感场景）
- 对非结构化页面（布局混乱的小影视站）效果比CSS选择器好

**与本技能衔接**：
- 本技能Step3生成Spider时，可用ScrapeGraphAI的ScriptCreatorGraph辅助生成初始脚本
- 提示词提取适合**快速验证**（"这个站能不能抓到播放地址"），再决定是否写完整Spider
- 本地Ollama模式适合用户的手机端Termux环境（无需API密钥）
- 注意：LLM提取可能不稳定，生产级TVBox插件仍需本技能的精确选择器+四壳协议

---
## 五、安全侦察工具链（ProjectDiscovery 三件套）

### 9. Nuclei（https://github.com/projectdiscovery/nuclei）
**核心特性**：
- 基于YAML模板的漏洞扫描器，Go语言，ProjectDiscovery出品
- 6000+内置模板（CVEs/暴露面板/默认凭据/恶意软件/信息泄露）
- 自定义模板（HTTP/DNS/SSL/FILE/HEADLESS/WEBSOCKET协议）
- 无头模式模板（浏览器渲染后检测）、批量扫描、自动更新模板
- DSL匹配表达式、输出JSONL、代理支持、限速控制

**影视站应用**：
- 检测影视站是否使用已知CMS（通过默认路径/特征头匹配），辅助Step1架构识别
- 发现影视站暴露的管理后台、phpmyadmin、.git泄露等安全问题（合规审计用）
- 自定义模板检测特定影视CMS的版本和已知漏洞（辅助判断反爬强度）
- 无头模板检测JS渲染后的特征（如播放器类型、加密脚本）

**与本技能衔接**：
- 本技能Step1的CMS嗅探可参考nuclei的模板匹配思路（特征串+默认路径）
- nuclei的CMS识别模板可辅助判定站点类型（苹果CMS/海洋CMS/飞飞CMS等）
- 注意：nuclei是漏洞扫描工具，**仅限合规审计和自有站点测试**，不用于未授权扫描

### 10. HTTPX（https://github.com/projectdiscovery/httpx）
**核心特性**：
- 多用途HTTP探活工具，Go语言，ProjectDiscovery出品
- 极速并发探测（默认50线程），支持HTTP/HTTPS/HTTP2
- 技术栈检测（wappalyzer指纹，识别CMS/服务器/框架/CDN）
- 标题/状态码/内容长度/重定向链/Favicon哈希/CDN检测/WAF检测
- 截图（无头模式）、JS渲染、自定义请求头/方法/Body
- 输出JSONL含完整响应，管道友好（subfinder | httpx | katana）

**影视站应用**：
- **Step1侦察的快速探活工具**：批量检测影视站域名/镜像是否存活
- 技术栈检测直接识别影视CMS（苹果CMSv10/海洋CMS/马克斯CMS等）和CDN（Cloudflare/阿里云）
- WAF检测判断站点反爬强度（是否有CF/阿里云盾/宝塔防火墙）
- Favicon哈希快速识别同源站（多个镜像域名是否同一套系统）
- 重定向链跟踪发现真实源站地址（绕过CDN）

**与本技能衔接**：
- **强烈推荐加入Step1智能侦察**：httpx技术栈检测+WAF检测比smart_router.py更全面
- httpx的CMS识别结果直接决定Step3走哪条爬虫路径（苹果CMS模板/海洋CMS模板/自定义）
- WAF检测结果决定Step3的反爬策略（CF站走指纹通道，普通站走requests）
- 管道式工作流：subfinder找子域→httpx探活→katana爬端点，三步完成全站侦察

### 11. Subfinder（https://github.com/projectdiscovery/subfinder）
**核心特性**：
- 被动子域名枚举工具，Go语言，ProjectDiscovery出品
- 30+被动源（crtsh/securitytrails/shodan/censys/virustotal等）
- 极速并发，通配符消除，主动解析验证（-nW）
- 递归枚举（-recursive）、API密钥配置（provider-config.yaml）
- JSONL输出、STDIN/OUT管道支持、代理支持

**影视站应用**：
- 发现影视站的镜像域名和备用站（很多影视站有多个域名防封）
- 发现CDN子域名（img.example.com/video.example.com/api.example.com），定位图片/视频/API分离架构
- 发现测试/开发子域（dev.example.com/test.example.com），可能有未授权访问的API
- 被动源从历史DNS记录中发现已废弃但仍可访问的旧域名

**与本技能衔接**：
- 本技能Step1的多域名容错可先用subfinder发现所有镜像，再配置mirrors列表
- 发现的API子域直接定位JSON_API端点，省去从页面抓包的步骤
- 发现的图片子域决定封面本地代理的Referer配置
- 管道式：subfinder | httpx | katana，完整侦察链

---
## 六、大规模分布式爬虫（归档/索引专用）

### 12. Apache Nutch（https://github.com/apache/nutch）
**核心特性**：
- Apache基金会项目，Java语言，Hadoop生态分布式爬虫
- 大规模网页抓取（亿级URL），分布式存储（HDFS），可水平扩展
- 插件架构（protocol/parse/index/scoring插件），Nutch 2.x支持多后端（HBase/Accumulo/Cassandra）
- 与Apache Solr/Elasticsearch集成，构建搜索引擎
- 完整的爬虫生命周期：inject→generate→fetch→parse→update→index

**影视站应用**：
- 构建**影视搜索引擎**（抓取数千个影视站，建立统一索引）
- 大规模影视站监控（定期爬取，发现新上线影视和下架内容）
- 分布式部署避免单点IP被封（多节点多IP）
- 适合"把整个影视站群的数据都收集起来"的超大规模场景

**与本技能衔接**：
- 本技能是单站精准爬虫（TVBox插件），Nutch是**多站大规模索引**，二者互补
- 当用户要求"做一个影视搜索引擎"时，Nutch+Solr是成熟方案
- Nutch的抓取数据可作为本技能Step3的参考（已有的分类结构和字段映射）
- 注意：Nutch部署复杂（需Hadoop集群），手机端Termux不适合，仅作知识储备

### 13. Heritrix 3（https://github.com/internetarchive/heritrix3）
**核心特性**：
- 互联网档案馆（Internet Archive）官方爬虫，Java语言，归档级质量
- Web-scale大规模抓取，严格遵守robots.txt和META nofollow
- 可扩展Bean架构（Spring风格配置），处理器链（Extractor→Fetcher→Writer）
- ARC/WARC归档格式（标准网页归档格式），完整保存请求/响应/Header
- REST API管理，Web UI控制台，分布式抓取（Heritrix 3.3+）

**影视站应用**：
- 影视站**完整归档**（保存所有页面的原始HTML+Header+响应时间，用于事后分析）
- 对即将关闭的影视站做完整备份（WARC格式可长期保存和重放）
- 归档数据用于逆向分析（从历史响应中找到已修改的加密密钥和API端点）
- 严格的politeness策略（避免对小站造成过大负载）

**与本技能衔接**：
- 本技能是实时精准抓取，Heritrix是**归档级完整保存**，用途不同
- 当用户要求"把这个站完整备份下来"时，Heritrix的WARC归档比wget更专业
- 归档的历史响应可辅助本技能Step3的逆向（对比改版前后的API变化）
- 注意：Heritrix是Java Web应用，部署较重，手机端不适合，仅作知识储备

---
## 七、19仓库全景选型决策树（完整版）

```
用户发来影视站URL
    │
    ├─ Step1 智能侦察
    │   ├─ 快速探活+技术栈+WAF检测 → httpx（必选）
    │   ├─ 发现镜像/子域/API分离 → subfinder（推荐）
    │   ├─ 端点发现+JS解析+XHR捕获 → katana（强烈推荐，主力）
    │   ├─ 被动历史URL发现 → katana -ps（可选）
    │   ├─ LLM分析页面结构 → Firecrawl Scrape/Map（可选，付费）
    │   └─ CMS版本+漏洞检测 → nuclei（合规审计用）
    │
    ├─ Step2 工具链匹配
    │   └─ 根据Step1结果选择：
    │       ├─ 普通HTML CMS站 → requests + BeautifulSoup（本技能默认）
    │       ├─ CF/TLS指纹站 → curl_cffi impersonate（37指纹）
    │       ├─ JS渲染/Vue SPA站 → nodriver（首选）/ Camoufox（备选）/ Playwright（调试）
    │       ├─ 自适应选择器/防改版 → Scrapling adaptive=True
    │       ├─ LLM友好提取/深度爬取 → Crawl4AI
    │       ├─ 大规模整站采集 → Scrapy（Python）/ Crawlee（Node.js）/ Colly（Go极速）
    │       ├─ 提示词驱动/非结构化页 → ScrapeGraphAI
    │       ├─ AI交互/复杂操作页 → Firecrawl Interact
    │       └─ Chrome CDP专属 → Puppeteer
    │
    ├─ Step3 TVBox爬虫开发
    │   └─ 本技能四壳协议+13铁律（不可替代）
    │       辅助工具：Scrapling选择器 / Crawl4AI Markdown分析 / katana端点
    │
    └─ Step4 蚂蚁小程序zip打包
        └─ 本技能miniapp-dev（不可替代）
```

---
## 八、19仓库影视站推荐度总表

| 分类 | 仓库 | 语言 | 影视站核心价值 | 推荐度 | 本技能集成状态 |
|------|------|------|--------------|--------|--------------|
| 反检测神器 | nodriver | Python | 协议层零拦截，JS渲染首选 | ★★★★★ | 已深度集成 |
| 反检测神器 | curl_cffi | Python | 37个TLS指纹，CF穿透首选 | ★★★★★ | 已深度集成 |
| 反检测神器 | Camoufox | Python | C++层指纹注入，终极反检测 | ★★★★☆ | 已深度集成 |
| 自适应爬虫 | Scrapling | Python | 自适应选择器，防改版 | ★★★★★ | 已深度集成 |
| AI-Native | Crawl4AI | Python | LLM友好Markdown+深度爬取 | ★★★★☆ | 已深度集成 |
| 侦察工具 | katana | Go | 端点发现+JS解析+XHR捕获 | ★★★★★ | 本部分新增，推荐Step1主力 |
| 侦察工具 | httpx | Go | 技术栈+WAF+CMS快速检测 | ★★★★★ | 本部分新增，推荐Step1必选 |
| 侦察工具 | subfinder | Go | 镜像/子域/API分离发现 | ★★★★☆ | 本部分新增，推荐Step1辅助 |
| 生产框架 | Scrapy | Python | 大规模整站采集，异步引擎 | ★★★★☆ | 本部分新增，离线采集用 |
| 生产框架 | Crawlee | Node.js | HTTP+浏览器统一，代理轮换 | ★★★☆☆ | 本部分新增，Node.js用户用 |
| 生产框架 | Colly | Go | 极速+低内存+单二进制 | ★★★☆☆ | 本部分新增，手机端极速侦察 |
| 浏览器 | Playwright | Python/JS | 跨浏览器自动化，开发调试 | ★★★★☆ | 已集成，生产环境换nodriver |
| 浏览器 | Puppeteer | Node.js | Chrome CDP专属，CDP直连 | ★★★☆☆ | 本部分新增，Chrome专属备选 |
| AI-Native | Firecrawl | API | 搜索/抓取/交互/Agent全合一 | ★★★☆☆ | 本部分新增，付费API可选 |
| AI-Native | ScrapeGraphAI | Python | 提示词驱动，LLM图逻辑 | ★★★☆☆ | 本部分新增，快速验证用 |
| 安全工具 | nuclei | Go | CMS识别+漏洞模板扫描 | ★★☆☆☆ | 本部分新增，合规审计用 |
| 分布式 | Nutch | Java | 亿级URL分布式索引 | ★★☆☆☆ | 本部分新增，搜索引擎场景 |
| 分布式 | Heritrix3 | Java | 归档级WARC完整保存 | ★☆☆☆☆ | 本部分新增，归档备份场景 |

---
## 九、手机端Termux环境适配说明

> 本技能用户偏好移动端Termux环境，以下仓库在Termux下的可用性：

| 仓库 | Termux可用性 | 说明 |
|------|------------|------|
| requests/curl_cffi/Scrapling/Crawl4AI/nodriver | ✅ 完全可用 | pip install即可，Python生态 |
| Camoufox | ⚠️ 需额外配置 | 需下载Firefox二进制，Termux下可能有兼容性问题 |
| Playwright | ⚠️ 需手动装浏览器 | pip install playwright后需playwright install，Termux下Chromium可能需patch |
| Scrapy | ✅ 可用 | pip install scrapy，Twisted在Termux下可编译 |
| katana/httpx/subfinder/nuclei | ✅ 可用 | go install即可，单二进制，Termux下Go环境成熟 |
| Colly | ✅ 可用 | go get，单二进制，低内存适合手机 |
| Crawlee/Puppeteer | ⚠️ Node.js环境 | Termux下nodejs可装，但浏览器下载可能慢 |
| Firecrawl/ScrapeGraphAI | ⚠️ 需API或Ollama | 托管API需网络，本地Ollama在手机端性能有限 |
| Nutch/Heritrix3 | ❌ 不适合 | Java Web应用，内存需求大，手机端无法运行 |

**Termux推荐侦察链**：subfinder → httpx → katana（全Go单二进制，极速低内存）
**Termux推荐开发链**：curl_cffi + Scrapling + nodriver（纯Python，pip安装）

> 所有5个仓库均通过60秒健康检查（近期有提交、有维护者响应、未归档）。
