# 🕷️ 全网爬虫技能图谱与仓库索引（2026版）

> 拉取自互联网各仓库与权威技术博客，按实战路径分层整理。涵盖框架、反检测、AI-Native、安全侦察、大规模爬取等全维度。

---

## 一、生产级爬虫框架（四大语言栈）

### 1.1 Python 栈

| 项目 | Stars | 许可证 | 核心定位 | 仓库 |
|------|-------|--------|----------|------|
| **Scrapy** | 50k+ | BSD-3 | Python事实标准，中间件/管道/分布式/异步架构 | https://github.com/scrapy/scrapy |
| **Scrapling** | 57k+ | 待确认 | 2026年GitHub Trending新星，自适应解析+内置Cloudflare绕过 | https://github.com/D4Vinci/Scrapling |
| **Crawl4AI** | 高星 | Apache-2.0 | LLM/RAG专用，整站转Markdown/JSON，BM25去噪 | https://github.com/unclecode/crawl4ai |
| **Firecrawl** | 高星 | 开源核心 | 搜索/抓取/交互API，Agent自动数据收集，Map发现URL | https://github.com/firecrawl/firecrawl |
| **ScrapeGraphAI** | 高星 | 开源核心 | 提示词驱动图管道，SmartScraper/Search/Speech/ScriptCreator | https://github.com/ScrapeGraphAI/scrapegraph-ai |

**Scrapy 核心优势**：中间件生态、分布式架构、内存管理精细，长期项目首选。需配合Playwright/Selenium处理动态页。  
**Scrapling 核心优势**：自适应选择器（站点改版后自动重新定位元素）、内置Stealth Fetcher、Cloudflare Turnstile原生绕过、流式输出、暂停/恢复。  
**Crawl4AI 核心优势**：输出LLM-ready Markdown而非原始HTML，支持BFS深度爬取、Docker部署+监控面板、LiteLLM本地LLM提取。

### 1.2 Node.js / TypeScript 栈

| 项目 | Stars | 许可证 | 核心定位 | 仓库 |
|------|-------|--------|----------|------|
| **Crawlee** | 高星 | Apache-2.0 | 最强全合一Node.js爬虫，HTTP+浏览器混合，指纹/代理/队列内置 | https://github.com/apify/crawlee |
| **Playwright** | 60k+ | Apache-2.0 | 跨浏览器自动化（Chromium/Firefox/WebKit），MCP Server支持 | https://github.com/microsoft/playwright |
| **Puppeteer** | 高星 | Apache-2.0 | Chrome DevTools协议，headless Chrome控制，puppeteer-extra插件生态 | https://github.com/puppeteer/puppeteer |

**Crawlee 核心优势**：统一API覆盖CheerioCrawler（HTTP快速模式）和PlaywrightCrawler/PuppeteerCrawler（浏览器模式），自动缩放并发、持久请求队列、指纹感知浏览器上下文。Python端口正在积极开发中。  
**Playwright 核心优势**：原生跨三引擎、自动等待消除时序问题、网络请求拦截、登录流/无限滚动/懒加载原生支持。  
**Puppeteer 核心优势**：Chrome集成更紧密，DevTools协议粒度控制，截图/PDF生成，puppeteer-extra生态扩展丰富。

### 1.3 Go 栈

| 项目 | Stars | 许可证 | 核心定位 | 仓库 |
|------|-------|--------|----------|------|
| **Colly** | 25k+ | Apache-2.0 | 高性能HTTP爬虫，>1k req/s，自动cookie/session，分布式，缓存 | https://github.com/gocolly/colly |
| **Katana** | 高星 | MIT | 安全侦察爬虫，标准/Headless双模式，JS解析，XHR提取，URL发现 | https://github.com/projectdiscovery/katana |

**Colly 核心优势**：编译为单二进制无运行时依赖、回调API清晰、内置速率限制/robots.txt合规。  
**Katana 核心优势**：安全侦察专用，被动+主动双模式爬取，Go并发极快，与nuclei/httpx/subfinder工具链无缝衔接，YAML配置支持表单自动填充。

### 1.4 Java 栈

| 项目 | Stars | 许可证 | 核心定位 | 仓库 |
|------|-------|--------|----------|------|
| **WebMagic** | 高星 | Apache-2.0 | Java版Scrapy，注解驱动POJO，多线程+分布式 | https://github.com/code4craft/webmagic |
| **Nutch** | Apache顶级 | Apache-2.0 | Hadoop生态分布式大规模爬取，插件架构，构建全文搜索索引 | https://github.com/apache/nutch |
| **Heritrix3** | 活跃 | Apache-2.0 | 互联网档案馆级归档爬取，WARC格式，尊重robots.txt | https://github.com/internetarchive/heritrix3 |

> ⚠️ **注意**：Nutch和Heritrix是Hadoop时代/归档专用工具，用于构建搜索索引或域名保存，**不适合**典型结构化数据提取任务。推荐它们用于"大规模爬取"场景是分类错误。

---

## 二、AI-Native 爬虫四件套（2026趋势）

2026年最大趋势是从"脚本驱动"转向"Agent驱动"。传统爬虫：访问URL→提取CSS选择器→翻页。AI Agent：观察页面→推理结构→动态决定提取方式。  
**数据支撑**：某企业用AI驱动系统替代15人手动爬虫团队，首年成本从410万美元降至27万美元，数据准确率从71%提升至96%。

### 2.1 Crawl4AI — LLM数据管道首选
```python
import asyncio
from crawl4ai import AsyncWebCrawler

async def crawl_to_markdown():
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url="https://news.ycombinator.com")
        print(result.markdown[:2000])
asyncio.run(crawl_to_markdown())
```
- 输出干净Markdown而非原始HTML，直接喂给RAG/LLM
- 生产级队列、代理处理、浏览器支持
- Docker部署+监控面板
- 支持BFS深度爬取策略

### 2.2 Firecrawl — 全站一键转结构化数据
- 单API调用将整个网站转为干净Markdown或JSON
- 自动过滤导航栏/页脚/弹窗等噪音
- 支持Python/Node.js/REST API
- MCP协议兼容，可被AI Agent直接调用

### 2.3 ScrapeGraphAI — 提示词驱动提取
- 用自然语言描述要提取的数据，AI自动学习页面布局
- 无需维护CSS选择器，站点改版自适应
- 支持SmartScraper/Search/Speech/ScriptCreator多模式
- 多LLM后端支持

### 2.4 Browser-Use — AI控制浏览器
- AI直接控制浏览器执行点击/输入/过验证码
- ChatBrowserUse优化模型
- Cloud API支持
- 适合需要复杂交互的爬取场景

### 2.5 MCP（Model Context Protocol）
MCP正在成为AI Agent与Web交互的标准协议。Apify、Firecrawl等已提供MCP兼容的爬虫。  
**范式转变**：从"写爬虫脚本"到"告诉Agent你需要什么数据"。

---

## 三、反检测与浏览器自动化深度技术

### 3.1 检测层全景（从底层到应用层）

| 检测层 | 检测内容 | 绕过方案 |
|--------|----------|----------|
| **TLS指纹** | JA3/JA4哈希，cipher suite顺序，扩展列表 | curl_cffi多指纹轮换、X25519 TLS指纹适配层、云浏览器原生TLS |
| **HTTP/2帧指纹** | SETTINGS参数、帧顺序、WINDOW_UPDATE | 真实浏览器驱动、云浏览器 |
| **IP信誉** | 数据中心IP、代理IP黑名单 | 住宅代理轮换、成功域名记忆缓存 |
| **自动化协议指纹** | CDP启动序列(Runtime.enable/Target.setAutoAttach) | nodriver直连CDP WebSocket、跳过Playwright shim层 |
| **JS环境检测** | navigator.webdriver、chrome.runtime、plugins、WebGL、canvas | playwright-stealth/camoufox C++层指纹注入 |
| **行为分析** | 鼠标轨迹、点击延迟、滚动模式、会话时长 | Bézier曲线鼠标、高斯分布延迟、渐进滚动 |

### 3.2 反检测工具矩阵（2026实测排名）

基于651个 verdicts 的31个目标跨4类场景的独立测试：

| 工具 | 被拦截数 | 核心机制 | 适用场景 |
|------|----------|----------|----------|
| **nodriver** | **0** | 直连Chrome CDP WebSocket，无Playwright shim | 最高级反检测需求 |
| **curl_cffi** | 5 | 多指纹TLS轮换（safari17_2_ios→chrome131→chrome124） | 轻量级HTTP请求 |
| **Patchright** | 中等 | Chromium补丁层 | 通用反检测 |
| **CloakBrowser** | 中等 | 多层指纹伪装 | 通用反检测 |
| **Camoufox** | 中等 | Firefox C++层指纹注入，随机但内部一致 | Firefox TLS形状优势场景 |
| **vanilla Playwright** | 高 | 无补丁，基线 | 测试/非反检测场景 |
| **rebrowser** | 高 | - | 不推荐 |

**关键洞察**：反检测的核心战场已从"JS运行时层"转移到"自动化协议层"。nodriver胜出的原因是它直接通过CDP WebSocket驱动Chrome，不经过Playwright的accessibility层，避免了Runtime.enable和Target.setAutoAttach等可识别的启动序列。  
**结论**：仅修补navigator.webdriver等JS属性已不足够，必须解决协议层指纹。

### 3.3 Camoufox 专项
- Firefox分支，C++层修改spoof指纹API（canvas、WebGL、屏幕几何、navigator属性）
- 随机值但内部一致，避免自相矛盾
- Firefox TLS握手形状与Chrome不同，在某些目标上反而是优势
- Playwright兼容
- 人类鼠标移动、去膨胀
- 仓库：https://github.com/daijro/camoufox（8.4k stars，MPL-2.0）

### 3.4 指纹一致性原则
反检测不是单点突破，而是全栈一致性：
- IP地理位置 → 匹配 `Intl.DateTimeFormat` 时区
- 浏览器语言 → 匹配IP国家
- 屏幕分辨率 → 与声称的OS/设备合理
- WebGL renderer → 与声称的硬件一致
- TLS指纹 → 与声称的浏览器匹配

### 3.5 会话预热策略
- 预访问常见站点（Google/YouTube/新闻站）构建自然浏览历史
- 接受cookie同意横幅生成第一方cookie
- 加载字体和资源填充浏览器缓存
- 跨自动化运行保持session cookie（不要每次都全新启动）

### 3.6 真实交互模拟
- 点击前生成Bézier曲线鼠标移动
- 按键间添加高斯分布延迟（非均匀随机）
- 交互前渐进滚动到元素（不要瞬移viewport）
- 引入模拟阅读/决策的微暂停
- 会话时长变化——不要总是恰好30秒

### 3.7 Headless vs Headful
2026年Chrome的new headless模式虽有显著改进，但仍可通过WebGL renderer差异、GPU加速缺失、API行为差异检测。  
**最佳实践**：在虚拟显示器（Linux Xvfb 或云VM带显示服务器）中运行headful模式，或使用云反检测平台。

---

## 四、安全侦察与大规模爬取专用工具

### 4.1 安全侦察三剑客

| 工具 | 语言 | 定位 | 仓库 |
|------|------|------|------|
| **Katana** | Go | 端点/子域名/隐藏路径发现，被动+主动双模式，JS渲染捕获XHR/Fetch | https://github.com/projectdiscovery/katana |
| **Nuclei** | Go | 漏洞扫描模板引擎，与Katana输出管道衔接 | https://github.com/projectdiscovery/nuclei |
| **httpx** | Go | 快速HTTP探活，与Katana/nuclei工具链配合 | https://github.com/projectdiscovery/httpx |

### 4.2 大规模分布式爬取

| 工具 | 生态 | 定位 | 适用场景 |
|------|------|------|----------|
| **Apache Nutch** | Hadoop | 分布式大规模爬取，插件架构，构建全文搜索索引 | 搜索引擎级索引构建 |
| **Heritrix3** | Java | 互联网档案馆级归档爬取，WARC格式 | 域名历史保存/归档 |
| **StormCrawler** | Apache Storm | 实时流式爬取，Elasticsearch集成 | 新闻/社交媒体实时监控 |

> 再次强调：Nutch和Heritrix是**索引/归档**工具，不是通用结构化数据爬虫。

---

## 五、语言特定进阶工具

### 5.1 Rust 浏览器自动化
**rust-browser-pilot**：生产级Rust浏览器自动化框架
- 双引擎：Chromium(chromiumoxide/CDP) + Firefox(fantoccini/WebDriver)
- 统一BrowserEngine trait
- 反检测9项JS注入（webdriver/chrome.runtime/plugins/languages/permissions/webgl/canvas/iframe/notification）
- 随机指纹生成（UA/platform/vendor/memory/timezone）
- 人类行为模拟（WPM/点击延迟/鼠标轨迹）
- Cookie/Session持久化管理（SessionManager导出导入JSON）
- HTTP/HTTPS/SOCKS5代理自动适配双引擎

### 5.2 Vue SPA 爬虫攻坚
**渲染穿透四方案**：
1. **Playwright+CDP拦截API** → 直取后端JSON，绕过DOM
2. **CDP Runtime注入** → 提取`__vue__`/`$data`/Store状态
3. **Scrapling自适应反检测** → 动态DOM变化不死
4. **camoufox指纹绕过** → C++层注入

**API攻坚**：
- 请求签名逆向：DevTools定位→hash+secret还原
- 响应解密：AES/Base64/XOR→Crypto还原
- WebSocket帧拦截

**Vue特化**：
- 路由表逆向（JS Chunk正则提取）
- Pinia/Vuex热替换（`$subscribe`）
- 虚拟滚动分段触发
- **原则**：绕过DOM直取数据层，加密用AST还原禁硬猜

---

## 六、2026年五大技术趋势

1. **Agentic AI Scrapers**：从脚本驱动到Agent驱动，AI观察页面→推理结构→动态提取
2. **Self-Healing Extraction**：LLM实时检测布局变化并自动重映射提取逻辑，维护时间从80%降至验证数据质量
3. **MCP标准化**：AI Agent通过MCP协议与爬虫工具交互，"告诉Agent要什么数据"替代"写爬虫脚本"
4. **LLM-Ready输出格式**：Markdown/JSON原生输出，不再是原始HTML
5. **协议层反检测**：战场从JS属性转移到CDP启动序列、TLS指纹、HTTP/2帧指纹

---

## 七、仓库健康检查方法论（60秒法则）

在采纳任何开源爬虫工具前，执行以下5步检查：

| 信号 | 红旗阈值 |
|------|----------|
| 最后提交日期 | 12+个月无提交 |
| 发布节奏 | 18+个月无发布 |
| Open Issue趋势 | 积压增长且无维护者响应 |
| 维护者数量 | 单一维护者且近期无活动 |
| 归档状态 | 仓库明确标记"archived" |

**2026年避雷案例**：PySpider仓库已归档多年，仍出现在多个"2026最佳爬虫"榜单中。Stars代表 popularity，不代表 maintenance。

---

## 八、按场景选型速查表

| 你的需求 | 推荐工具 | 理由 |
|----------|----------|------|
| Python生产级大规模爬取 | **Scrapy** | 中间件生态、分布式、内存管理 |
| Node.js全合一生产级 | **Crawlee** | 统一API、自动缩放、持久队列 |
| Go高性能HTTP爬取 | **Colly** | >1k req/s、单二进制部署 |
| LLM/RAG数据管道 | **Crawl4AI** | 原生Markdown输出、BM25去噪 |
| AI Agent全站抓取 | **Firecrawl** | 一键转结构化数据、MCP兼容 |
| 提示词驱动自动提取 | **ScrapeGraphAI** | 自然语言描述、自适应布局 |
| JavaScript重度SPA | **Playwright** | 跨引擎、自动等待、网络拦截 |
| 最高级反检测需求 | **nodriver** | 零拦截、直连CDP无shim |
| Firefox形状优势场景 | **Camoufox** | C++层指纹注入、Playwright兼容 |
| 安全侦察/端点发现 | **Katana** | 被动+主动、XHR捕获、工具链生态 |
| 自适应解析（防改版） | **Scrapling** | 选择器自学习、Cloudflare原生绕过 |
| 无代码/自托管 | **Maxun** | 可视化配置、自托管 |

---

## 九、学习路径建议

### 路径A：通用爬虫工程师
1. 基础：Scrapy/Colly 掌握一个 → 理解中间件、管道、队列
2. 动态页：Playwright 基础 → 自动等待、网络拦截、SPA处理
3. 反检测：curl_cffi → playwright-stealth → nodriver/camoufox 渐进深入
4. 生产化：Crawlee 统一框架 → 代理轮换、会话管理、错误重试
5. AI化：Crawl4AI/Firecrawl 接入LLM管道

### 路径B：安全侦察工程师
1. Katana 端点发现 → 与nuclei/httpx管道化
2. 理解TLS/HTTP2指纹原理 → JA3/JA4
3. 浏览器自动化协议层检测 → CDP启动序列分析
4. 大规模：根据需求选择Nutch（索引）或自研分布式

### 路径C：AI-Native数据工程师
1. MCP协议理解 → Agent与工具交互范式
2. Crawl4AI 输出Markdown → 接入RAG
3. Firecrawl 全站抓取 → 结构化JSON
4. ScrapeGraphAI 提示词提取 → 自适应布局
5. Self-Healing 概念 → LLM实时修复选择器

---

## 十、关键仓库速链

```
# Python 生产级
https://github.com/scrapy/scrapy
https://github.com/D4Vinci/Scrapling
https://github.com/unclecode/crawl4ai

# Node.js/TS 生产级
https://github.com/apify/crawlee
https://github.com/microsoft/playwright
https://github.com/puppeteer/puppeteer

# Go 高性能
https://github.com/gocolly/colly
https://github.com/projectdiscovery/katana

# AI-Native
https://github.com/firecrawl/firecrawl
https://github.com/ScrapeGraphAI/scrapegraph-ai

# 反检测专项
https://github.com/daijro/camoufox
https://github.com/ultrafunkamsterdam/nodriver
https://github.com/yifeikong/curl_cffi

# 安全侦察工具链
https://github.com/projectdiscovery/nuclei
https://github.com/projectdiscovery/httpx
https://github.com/projectdiscovery/subfinder

# 大规模分布式（归档/索引专用）
https://github.com/apache/nutch
https://github.com/internetarchive/heritrix3
```

---

> 📌 **最后提醒**：开源工具解决代码层问题，但住宅IP池、CAPTCHA处理、托管反检测绕过是运营层成本，没有开源工具能免费解决。当目标站点的反检测强度超过工具天花板时， managed scraping API 或云反检测平台是务实的选择。
