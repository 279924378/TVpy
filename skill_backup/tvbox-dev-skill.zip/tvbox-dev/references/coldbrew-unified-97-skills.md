# 冷咖啡统一技能集（ColdBrew Unified）— 97技能总索引
> 来源：用户上传 coldbrew-unified.zip（2026-09-05）
> 性质：安全研究/逆向工程全领域技能集，含97个子技能
> 本文件仅记录技能名称、分类、用途等客观信息，不包含任何渗透/破解/外挂的具体操作步骤。
> **合法边界**：所有技能仅限授权测试、安全研究、教育用途；禁止用于未授权入侵、破解分发、外挂制作等非法活动。

## 概述

冷咖啡统一技能集包含 **97 个子技能**，覆盖逆向工程、渗透测试、Web安全、恶意软件分析、游戏安全、移动安全、固件/IoT、云容器、密码学、爬虫、软件开发等全领域。

### 核心架构
```
eni-unified-router（确定性路由入口）
    ↓ 每个任务只命中一个工作流
eni-core（核心执行引擎，顺序执行）
    ↓ 按路由结果逐阶段推进
各工作流技能（eni-*-workflow / detail-pack）
    ↓ 兜底
eni-universal-workflow（六段链：intake→classify→plan→execute→verify→deliver）
```

### 五刃体系（FiveEdge）
口语触发归一后走五条链：REV逆向 / UNLOCK破解 / INFIL渗透 / HARVEST爬虫 / TRAINER外挂

---

## 97技能完整分类索引

### 一、逆向工程（17个）
| 技能 | 用途 |
|------|------|
| `eni-core` | 核心路由与执行引擎 |
| `eni-reverse-workflow` | 深度逆向工作流 |
| `eni-reverse-deep` | 深度逆向（加壳/混淆/VM） |
| `eni-reverse-ref` | 逆向参考文档 |
| `eni-apk-reverse` | Android APK 逆向 |
| `eni-mobile-reverse` | 移动端逆向 |
| `eni-ida-reverse` | IDA Pro 分析 |
| `eni-radare2` | r2/radare2 命令行逆向 |
| `eni-js-reverse` | JavaScript 前端逆向（签名/加密参数/风控） |
| `eni-blackbox-reverse-boost` | 离线黑盒逆向 |
| `eni-unpack-reverse-lab` | PE 加壳/解包分析 |
| `eni-reverselab-bridge` | Open ReverseLab 桥接 |
| `eni-binary-diff` | 二进制差分 |
| `eni-patch-diff-exploit` | 补丁差分与利用分析 |
| `eni-native-reverse` | 原生代码逆向 |
| `coldbrew-native-reverse` | 冷咖啡原生代码逆向 |
| `coldbrew-api-reverse` | 冷咖啡 API 逆向 |

### 二、渗透测试（8个）
| 技能 | 用途 |
|------|------|
| `eni-pentest-workflow` | 渗透测试工作流 |
| `eni-pentest-advanced` | 高级渗透测试 |
| `eni-pentest-tools` | 渗透工具选型 |
| `eni-api-security` | API 安全测试 |
| `eni-api-assurance-lane` | API 保障流程 |
| `eni-burp-mcp` | Burp Suite MCP 集成 |
| `eni-attack-chain` | 攻击链编排 |
| `eni-ctf-orchestrator` | CTF 沙盒编排 |

### 三、Web安全 detail-pack（28个）
| 技能 | 用途 |
|------|------|
| `eni-redteam-web-detail-pack` | Web 安全总入口 |
| `eni-redteam-xss-detail-pack` | XSS 测试 |
| `eni-redteam-sqli-detail-pack` | SQL 注入测试 |
| `eni-redteam-xxe-detail-pack` | XXE 测试 |
| `eni-redteam-ssrf-detail-pack` | SSRF 测试 |
| `eni-redteam-ssti-detail-pack` | SSTI 模板注入测试 |
| `eni-redteam-injection-detail-pack` | 通用注入测试 |
| `eni-redteam-cmdi-detail-pack` | 命令注入测试 |
| `eni-redteam-deserialize-detail-pack` | 反序列化测试 |
| `eni-redteam-csrf-detail-pack` | CSRF 测试 |
| `eni-redteam-cors-miscfg-detail-pack` | CORS 配置错误测试 |
| `eni-redteam-open-redirect-detail-pack` | 开放重定向测试 |
| `eni-redteam-file-detail-pack` | 文件操作漏洞测试 |
| `eni-redteam-cache-poison-detail-pack` | 缓存投毒测试 |
| `eni-redteam-clickjacking-detail-pack` | 点击劫持测试 |
| `eni-redteam-logic-detail-pack` | 逻辑漏洞测试 |
| `eni-redteam-auth-detail-pack` | 认证授权测试 |
| `eni-redteam-ad-detail-pack` | Active Directory 测试 |
| `eni-redteam-api-detail-pack` | API 安全测试包 |
| `eni-redteam-code-audit-detail-pack` | 代码审计测试包 |
| `eni-redteam-cloud-detail-pack` | 云安全测试 |
| `eni-redteam-container-detail-pack` | 容器安全测试 |
| `eni-redteam-crypto-detail-pack` | 密码学弱点测试 |
| `eni-redteam-evasion-detail-pack` | 规避检测测试 |
| `eni-redteam-mobile-detail-pack` | 移动安全测试 |
| `eni-redteam-network-detail-pack` | 网络层安全测试 |
| `eni-redteam-payload-detail-pack` | 载荷测试 |
| `eni-redteam-postex-detail-pack` | 后渗透测试 |
| `eni-redteam-recon-detail-pack` | 侦察测试 |
| `eni-redteam-reverse-detail-pack` | 逆向测试 |
| `eni-redteam-subdomain-takeover-detail-pack` | 子域名接管测试 |

### 四、身份与认证（4个）
| 技能 | 用途 |
|------|------|
| `eni-license-security` | 许可证/激活安全分析 |
| `eni-cf-security-lab-router` | CrossFire 安全实验室路由 |
| `coldbrew-identity` | 冷咖啡身份识别 |
| `eni-redteam-cve-lookup` | CVE 漏洞查询 |

### 五、云与容器（5个）
| 技能 | 用途 |
|------|------|
| `eni-cloud-container-workflow` | 云/容器安全工作流 |
| `eni-supply-chain` | 供应链安全 |
| `eni-supply-chain-assurance-lane` | 供应链保障流程 |
| `eni-code-security-workflow` | 代码安全工作流 |
| `eni-llm-security` | LLM/大模型安全 |

### 六、固件与 IoT（3个）
| 技能 | 用途 |
|------|------|
| `eni-firmware-pentest` | 固件渗透测试 |
| `eni-firmware-workflow` | 固件分析工作流 |
| `eni-mobile-security-workflow` | 移动安全工作流 |

### 七、恶意软件与取证（5个）
| 技能 | 用途 |
|------|------|
| `eni-malware-analysis` | 恶意软件分析 |
| `eni-malware-ir-workflow` | 恶意软件事件响应 |
| `eni-memory-forensics` | 内存取证 |
| `eni-edr-bypass` | EDR 绕过分析 |
| `eni-redteam-recon-intake` | 红队侦察 intake |

### 八、游戏安全（3个）
| 技能 | 用途 |
|------|------|
| `eni-game-hacking` | 游戏逆向与内存工程（53KB最大技能） |
| `eni-game-security` | 防御性游戏安全/反作弊 |
| `eni-game-cheat-lab-workflow` | 外挂/修改器实验室工作流 |

### 九、网络与协议（3个）
| 技能 | 用途 |
|------|------|
| `coldbrew-protocol-reverse` | 冷咖啡自定义协议逆向 |
| `eni-redteam-doctrine` | 红队指挥与治理 |
| `eni-field-journal` | 实战日志记录 |

### 十、爬虫与数据（3个）
| 技能 | 用途 |
|------|------|
| `eni-scraper-workflow` | 结构化爬虫工作流（请求优先+浏览器回退） |
| `eni-browser-automation` | 浏览器自动化（Playwright）+ 桌面自动化（OpenReverse） |
| `eni-browser-research-workflow` | 浏览器研究工作流 |

### 十一、软件开发（4个）
| 技能 | 用途 |
|------|------|
| `eni-software-workflow` | 软件开发工作流 |
| `eni-diagram` | 架构图表生成 |
| `eni-docs` | 技术文档生成 |
| `eni-architecture-workflow` | 架构设计工作流 |

### 十二、红队指挥与工具（7个）
| 技能 | 用途 |
|------|------|
| `eni-unified-router` | 统一确定性路由入口 |
| `eni-universal-workflow` | 通用兜底六段工作流 |
| `eni-case-lab` | 案例实验室 |
| `eni-kali` | Kali Linux 工具参考 |
| `eni-github-workflow-hub` | GitHub Actions 工作流源目录 |
| `eni-five-edge` | 五刃入口（REV/UNLOCK/INFIL/HARVEST/TRAINER） |
| `five-edge` | 五刃独立入口 |

### 十三、破解与 CTF（4个）
| 技能 | 用途 |
|------|------|
| `eni-crack-workflow` | 软件破解分析工作流 |
| `eni-pwn-chain` | PWN 利用链工作流 |
| `eni-fuzzing-workflow` | Fuzzing 模糊测试工作流 |
| `eni-ctf-orchestrator` | CTF 竞赛编排 |

### 十四、冷咖啡总控（4个）
| 技能 | 用途 |
|------|------|
| `coldbrew-breaker-kit` | 一键破甲总控 |
| `eni-coldbrew` | 冷咖啡一体化路由 |
| `coldbrew-unified`（根目录） | 97技能集统一入口 |
| `eni-reverselab-bridge` | 逆向实验室桥接 |

---

## 与 tvbox-dev 影视站开发相关的技能提炼

以下技能的**合法工作流思路**可直接应用于影视站爬虫开发与API逆向：

### 1. eni-js-reverse（JS前端逆向）→ 影视站加密API逆向
**五阶段合法工作流**（Observe→Capture→Rebuild→Patch→DeepDive）：
- **Observe**：打开目标页面，列出网络请求，回溯请求发起者（initiator），定位可疑脚本
- **Capture**：对目标请求做最小侵入采样，拿到参数样例、调用顺序、运行时证据（XHR断点/运行时评估）
- **Rebuild**：把页面证据整理成本地可复现的Node材料，补环境必须以页面观测为依据，不空想
- **Patch**：按报错驱动补环境，一次只做一个最小补丁，每次补丁后立即复测
- **DeepDive**：本地跑通后做去混淆、控制流还原、业务逻辑提纯
- **核心原则**：Observe-first / Hook-preferred / Breakpoint-last / Rebuild-oriented / Evidence-first

### 2. eni-scraper-workflow（结构化爬虫）→ 影视站数据采集
**六阶段合法工作流**：
- **采集契约**：先定义允许采集范围、输出schema、新鲜度、身份键、质量阈值
- **请求优先**：首选直接HTTP/Scrapy风格爬虫；页面需要渲染时才升级到浏览器自动化
- **采集执行**：原始响应落盘保留排障现场、字段清洗归一化、按身份键去重、分页checkpoint
- **重试退避**：网络错误指数退避、429限流加长退避并降并发
- **质量门禁**：计数闸/类型闸/空值闸/唯一性闸/抽检闸，任一不过不导出
- **导出留痕**：固定格式+元数据（采集时间/源站/配置快照/质量报告）

### 3. eni-browser-automation（浏览器自动化）→ 反爬绕过与渲染页采集
**浏览器自动化核心操作流**：
- 打开页面 → snapshot抓取可交互元素 → 按引用操作（click/fill/type）→ 等待页面稳定 → 关闭会话
- **三条纪律**：必须close防进程泄漏、操作前先snapshot禁止猜元素、提交表单后wait networkidle
- **适用场景**：需要JS渲染的影视站、自动化登录、验证码页面处理、截图存档

### 4. eni-api-reverse / coldbrew-api-reverse（API逆向）→ 影视站API分析
- 定位接口签名、加密参数、风控字段
- 观察请求链路与脚本来源
- 运行时抓取函数入参与返回值
- 追踪XHR/Fetch/WebSocket触发点
- 本地补环境复现签名算法

### 5. eni-unified-router + eni-core（路由执行架构）→ tvbox-dev四步流水线参考
- **确定性路由**：每个任务只命中一个工作流，同样输入得到同样结果
- **顺序执行**：按路由结果逐阶段推进，阶段不增不减不改序
- **状态传递**：阶段间传递状态，不重复劳动
- **兜底机制**：路由无命中时回退通用工作流
- **占位符约定**：信息不足时用固定占位符（TARGET/HOST/TOKEN/PAYLOAD/SAMPLE），最终交付必须替换为真实值或标注待填

---

## 五刃与 tvbox-dev 四步流水线映射

| 冷咖啡五刃 | tvbox-dev对应 | 触发场景 |
|-----------|--------------|---------|
| HARVEST（爬虫） | Step 1-3 全流程 | 用户发影视站URL |
| REV（逆向） | Step 3 加密API逆向/eval解包 | 影视站有加密参数/混淆JS |
| INFIL（渗透） | Step 3 反爬绕过/CF穿透 | 影视站有Cloudflare/WAF防护 |
| UNLOCK（破解） | 需人工点名 | 壳源码修改/播放器定制（不自动触发） |
| TRAINER（外挂） | 无直接关联 | 需人工点名，仅限游戏安全研究 |

---

## 合法边界与使用原则

1. **授权前提**：所有逆向/渗透/破解分析仅限自有软件、授权测试、CTF竞赛、安全研究
2. **影视站爬虫**：遵守目标站点robots.txt与服务条款，仅用于个人学习与技术研究
3. **不输出可操作非法步骤**：渗透/破解/外挂类技能仅记录名称与用途，不提供具体利用代码
4. **数据保护**：不采集、不存储、不传播个人隐私数据
5. **知识产权**：尊重软件版权与商业授权，不制作/分发破解补丁、注册机、外挂
6. **责任自负**：使用者需对自身行为承担法律责任

---

## 技能统计

| 分类 | 数量 |
|------|------|
| 逆向工程 | 17 |
| 渗透测试 | 8 |
| Web安全detail-pack | 28 |
| 身份与认证 | 4 |
| 云与容器 | 5 |
| 固件与IoT | 3 |
| 恶意软件与取证 | 5 |
| 游戏安全 | 3 |
| 网络与协议 | 3 |
| 爬虫与数据 | 3 |
| 软件开发 | 4 |
| 红队指挥与工具 | 7 |
| 破解与CTF | 4 |
| 冷咖啡总控 | 4 |
| **合计** | **97** |
