# 多源聚合站架构详解

> 逆向「单前端聚合多后端数据源」型影视站的完整机制与代码。目录：
> 1分类ID编码 / 2四端点分离 / 3 AES加密 / 4图片分片 / 5播放地址推导 /
> 6 vod_id编码 / 7大包分页 / 8搜索POST / 9多CDN / 10缓存 / 11适配checklist

## 1. 分类ID编码体系

格式 `{加密类型}{站点ID}:{分类ID}`：

| 前缀 | 含义 | 加密策略 |
|------|------|----------|
| `w` | water | AES-256-CBC 加密（json_data字段） |
| `p` | plain | 明文，无需解密 |
| `t` | topic | 专题/聚合，数据为嵌套分组，需提取 videoList |

```python
# w5:1867171983000444929 → w加密, 站点5, 分类长整数
# p3:1829527205563883521 → 明文, 站点3
# t2:1813444410127257601 → 专题, 站点2

def _fetch_cat(self, tid, page):
    typ, site, cid = tid[:1], tid[1], tid[3:]
    if typ == 'w':
        url = JSON_API + '/oss/pages/1/{}/water/{}/{}.json'.format(site, cid, page)
        return self._list(url)
    if typ == 'p':
        url = JSON_API + '/oss/pages/1/{}/water/{}/{}.json'.format(site, cid, page)
        return self._list(url, plain=True)
    if typ == 't':
        url = JSON_API + '/oss/pages/1/{}/new/{}/topic.json'.format(site, cid)
        arr, out = self._list(url), []
        for grp in arr:
            if isinstance(grp, dict):
                out.extend(grp.get('videoList') or [])
        return out
```

## 2. API 端点分离架构

不同功能拆到独立子域名，必须分别抓包配置：

| 变量 | 用途 | 典型示例 |
|------|------|----------|
| `JSON_API` | 列表/分类数据 | `https://jsonbfq1.cszmys.com` |
| `SEARCH_API` | 搜索接口（POST） | `https://search5.fvnmowb.com` |
| `PIC_API` | 图片分片 | `https://mstatic1.cszmys.com` |
| `VIDEO_DOMAINS` | 视频CDN轮询列表 | `['https://videos.yngte.com:65443', ...]` |

要点：列表返回外层可能嵌套 `json_data`；搜索独立域名；图片/视频各自专属CDN，与主站域名无关。

## 3. AES-256-CBC 加密体系

Key 为32字节字符串，IV=Key前16字节，PKCS7填充，标准Base64。Key通常硬编码在前端JS中，抓包/搜JS定位。

```python
from Crypto.Cipher import AES
import base64

K2 = b'zH3JDuCRXVGa3na7xbOqpx1bw6DAkbTP'

def _aes_en(s):
    raw = s.encode()
    n = 16 - len(raw) % 16
    raw += bytes([n]) * n
    c = AES.new(K2, AES.MODE_CBC, iv=K2[:16])
    return base64.b64encode(c.encrypt(raw)).decode()

def _aes_de(ct):
    if not ct:
        return ''
    c = AES.new(K2, AES.MODE_CBC, iv=K2[:16])
    raw = c.decrypt(base64.b64decode(ct))
    n = raw[-1]
    if 0 < n < len(raw) and raw[-n:] == bytes([n]) * n:
        raw = raw[:-n]
    return raw.decode('utf-8', errors='ignore')

# 解密流程
d = json.loads(txt)
if isinstance(d, dict) and d.get('json_data'):
    arr = json.loads(_aes_de(d['json_data']))
```

## 4. 图片三分片机制

单图拆3个txt：`{base}_13.txt`、`{base}_23.txt`、`{base}_33.txt`。每个分片内容前2字节为头部标记需切掉（`content[2:]`），三段拼接后整体base64解码。

```python
import re, base64, requests
from urllib.parse import quote

def _pic_shards(path):
    base = re.sub(r'\.\w+$', '', path)
    hd = {'User-Agent': UA, 'Referer': HOST + '/'}
    parts = []
    for i in (1, 2, 3):
        r = requests.get(PIC_API + base + '_{}3.txt'.format(i),
                         headers=hd, timeout=10, verify=False)
        if r.status_code == 200 and len(r.content) > 10:
            parts.append(r.content[2:].decode('utf-8', errors='ignore'))
    if len(parts) != 3:
        return b''
    return base64.b64decode(''.join(parts))
```

TVBox不能直接处理分片，起本地HTTP代理，合并后按文件头识别MIME返回：

```python
def _pic_url(path):
    if not path:
        return ''
    return 'http://127.0.0.1:{}/pic?url={}'.format(_start_pic_proxy(), quote(path, safe=''))
```

MIME识别：`\xff\xd8`→jpeg，`\x89PNG`→png，`RIFF...WEBP`→webp。

## 5. 视频URL自动推导

从 previewUrl 推导真实 m3u8：

| 预览URL | 替换为 |
|---------|--------|
| 含 `/preview/preview.mp4` | `/index.m3u8` |
| 含 `/preview.mp4` | `/index.m3u8` |

```python
vu = it.get('videoUrl') or ''
if not vu:
    pu = it.get('previewUrl') or ''
    if '/preview/preview.mp4' in pu:
        vu = pu.replace('/preview/preview.mp4', '/index.m3u8')
    elif '/preview.mp4' in pu:
        vu = pu.replace('/preview.mp4', '/index.m3u8')
```

## 6. vod_id 编码方案

`base64url(videoUrl|title|pic|duration)`，管道符分隔，详情页解码还原（避免详情页二次请求）。

```python
import base64

def _b64e(s):
    return base64.urlsafe_b64encode(s.encode()).decode().rstrip('=')

def _b64d(s):
    pad = '=' * (-len(s) % 4)
    try:
        return base64.urlsafe_b64decode(s + pad).decode('utf-8', errors='ignore')
    except Exception:
        try:
            return base64.b64decode(s + pad).decode('utf-8', errors='ignore')
        except Exception:
            return ''

vid = _b64e('{}|{}|{}|{}'.format(vu, title, pic, duration))

def detailContent(self, ids):
    parts = _b64d(ids[0]).split('|')
    vu, title, pic = parts[0], parts[1], parts[2]
    dur = parts[3] if len(parts) > 3 else ''
```

## 7. JSON大包分页映射

后端每包200条，TVBox每页20条（每包=10页）：

```python
def categoryContent(self, tid, pg=1, filter=False, extend=''):
    p = int(pg) if pg else 1
    ipage, off = (p - 1) // 10, (p - 1) % 10
    arr = self._fetch_cat(str(tid), ipage)
    if len(arr) == 200:
        pagecount = ipage * 10 + 10
    else:
        pagecount = ipage * 10 + max(1, (len(arr) + 19) // 20)
    if off * 20 >= len(arr):
        return {'page': p, 'pagecount': p - 1, 'limit': 20,
                'total': ipage * 200 + len(arr), 'list': []}
    items = self._items(arr[off * 20:(off + 1) * 20])
    return {'page': p, 'pagecount': pagecount, 'limit': 20,
            'total': ipage * 200 + len(arr), 'list': items}
```

## 8. 搜索POST加密

```python
def searchContent(self, key, quick=False, pg=1):
    body = {
        'text': _aes_en(key),
        'current': int(pg) or 1,
        'size': 20,
        'sortType': 0,
        'date': '', 'quality': '', 'duration': ''
    }
    r = self.session.post(SEARCH_API + '/search', json=body, timeout=15, verify=False)
    t = r.json()
    arr = json.loads(_aes_de(t.get('json_data'))) if t.get('json_data') else []
    total = int(t.get('total') or 0)
    return {'list': self._items(arr), 'page': int(pg),
            'pagecount': max(1, (total + 19) // 20)}
```

## 9. 多CDN播放策略

同一视频路径拼接全部CDN域名，生成多线路：

```python
urls = [d + vu for d in VIDEO_DOMAINS]
d = {
    'vod_id': vid,
    'vod_name': title,
    'vod_pic': _pic_url(pic) if pic else '',
    'vod_remarks': dur,
    'vod_content': title,
    'vod_play_from': '$$$'.join(['线路{}'.format(i + 1) for i in range(len(urls))]),
    'vod_play_url': '#'.join(['正片${}'.format(u) for u in urls]),
}

def playerContent(self, flag, id, vipFlags=None):
    return {'parse': 0, 'url': id,
            'header': {'User-Agent': UA, 'Referer': HOST + '/'}}
```

## 10. 缓存机制

列表数据短TTL缓存，避免翻页重复请求大包：

```python
_cache = {}
def _list(self, url, plain=False):
    now = time.time()
    hit = self._cache.get(url)
    if hit and now - hit[0] < 180:
        return hit[1]
    arr = self._fetch_and_parse(url, plain)
    self._cache[url] = (now, arr)
    return arr
```

## 11. 通用适配 Checklist

1. 抓包找四端点：列表/搜索/图片/视频是否子域名分离
2. 分析分类ID：是否有 w/p/t 前缀，站点ID与分类ID如何拆
3. 解密 json_data：AES-256-CBC，Key从前端JS定位，IV=Key前16字节
4. 检查图片分片：是否 `_13.txt/_23.txt/_33.txt`，验证三段拼接解码
5. previewUrl→m3u8：替换规则是否一致，有无 videoUrl 直出
6. 分页大小：JSON包是否200条，按公式映射20条/页
7. 搜索是否POST加密：text字段AES加密，响应json_data解密
8. 多CDN探测：视频是否多域名副本，生成多线路
9. localProxy：图片分片代理 + 嵌套m3u8代理
10. 全接口返回格式符合TVBox规范，语法检查通过
