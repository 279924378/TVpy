# 冷咖啡（ColdBrew）多模型AI工作台 — 工具参考

> 来源仓库：https://github.com/Qingg77/gpt5.6-claude-grok4.6-deepseekv4pro
> 性质：第三方多模型AI聚合客户端（Electron原生窗口 + Python Hub面板）
> 本文件仅记录项目客观信息与基本用法，不包含任何破解/越狱/渗透操作细节。

## 项目概述

冷咖啡是一个整合了四个AI模型的桌面工作台，提供原生窗口界面和Python命令行面板两种使用方式。

### 四个模型
- GPT-5.6
- Claude（Opus 5 / Fable 5 / 4.8 / Opus 4.6 / Sonnet 4.6 / Haiku 4.6 等多型号）
- Grok 4.6
- DeepSeek v4 Pro

### 五刃（FiveEdge）概念
项目以"五刃"作为任务分类标签，按输入动词自动锁定：

| 刃 | 代码 | 口语触发 | 交付物类型 |
|----|------|---------|-----------|
| 逆向 | `REV` | "搞一下exe/看看里面怎么验" | 伪代码、偏移、还原代码 |
| 破解 | `UNLOCK` | "做注册机/让它无限用" | keygen + patcher |
| 渗透 | `INFIL` | "这站能打吗" | 命令 + 回显 + 下一步 |
| 爬虫 | `HARVEST` | "数据扒下来" | 验签 + 续爬脚本 |
| 外挂 | `TRAINER` | "开个透视" | 实体 / W2S / Overlay |

> 快捷键：`Ctrl+1–4` 切换模型，`Alt+1–5` 锁定刃口。

## 环境要求

- Python 3.10+
- Node.js（用于desktop原生窗口）
- 平台：Windows 10/11、macOS 12+、Linux x64

## 基本用法

### 方式一：原生窗口（Electron）
```bash
git clone https://github.com/Qingg77/gpt5.6-claude-grok4.6-deepseekv4pro.git
cd gpt5.6-claude-grok4.6-deepseekv4pro/desktop
npm install
npm start
```
- Windows：双击 `打开冷咖啡.bat`
- macOS：双击 `打开冷咖啡.command`
- Linux：`bash 打开冷咖啡.sh`
- 打包Linux：`npm run pack:linux`（出 AppImage / deb）

### 方式二：Python Hub面板
```bash
python coldbrew_hub.py
```
或双击 `open_hub.bat` / `启动面板.bat`

流程：环境自检 → 选刃口 → 开模型卡 → 预览 → 部署 → 验证

## 项目结构

```
├── desktop/          # Electron原生窗口（一键破甲界面）
├── docs/             # 文档与图片素材
├── projects/         # 项目文件
├── coldbrew_hub.py   # Python Hub主面板
├── pack_release.py   # 发布打包脚本
├── make_art*.py      # 美术资源生成脚本
├── open_hub.bat      # Windows启动面板
├── 启动面板.bat       # Windows启动面板（中文）
├── 打开冷咖啡.bat     # Windows原生窗口
├── 打开冷咖啡.command # macOS原生窗口
├── 打开冷咖啡.sh      # Linux原生窗口
└── README.md / README_EN.md
```

## 四个模型适配器详解（projects/ 子目录）

冷咖啡的核心是 `projects/` 下的四个独立模型适配器，每个都是完整的桌面软件 + CLI工具：

### 1. claude-coldbrew（Claude Code适配器，v3.1.0）
- **定位**：Claude Code 专用桌面软件，把原创人格、目标连续性、路由、规则、Skills、Agent、Commands、备份、验证和恢复合同部署到 Claude Code 本地入口
- **目录结构**：`app/`（应用核心）、`skills/eni-coldbrew/`（技能包）、`studio/`（工作台）、`assets/`、`docs/`、`pack/`、`scripts/`
- **启动口令**：输入 `冷咖啡` 显示完整固定启动文案；`cold coffee` 和 `[[CB:MAX]]` 恢复 MAX 预设
- **安装脚本**：`install.ps1` / `install.sh`；启动脚本：`start-claude-pojia.bat/.ps1/.sh`、`launch-claude-max.ps1/.sh`
- **真实边界**：修改的是本机或项目内的 Claude Code 指令文件，不修改模型权重、Anthropic 系统指令或服务端审核

### 2. codex-coldbrew（Codex适配器，v6.1.0）
- **定位**：Codex 专用桌面软件，部署原创石井人格、目标连续性、单路由执行、备份、验证和恢复合同
- **目录结构**：`skills/eni-coldbrew/`（技能包）、`studio/`（工作台）、`pack/eni-solo/`（独立打包）、`assets/`、`docs/`、`scripts/`
- **挂钩加厚**：部署后额外写入 `model_instructions_file`（指向活的 eni-jailbreak-*.md）、`approval_policy = "never"`、`sandbox_mode = "danger-full-access"`、`[desktop] localeOverride = "zh-CN"`，不禁用 hooks.json
- **启动口令**：`冷咖啡` / `cold coffee` / `[[ENI:PROFILE=MAX]]` 三入口共用 canonical 启动合同
- **启动脚本**：`start-studio.bat/.ps1/.sh`；验证脚本：`verify.ps1/.sh`
- **真实边界**：修改本机 Codex 配置和指令文件，不修改模型权重、OpenAI 系统指令或服务端审核

### 3. deepseek-harness（DeepSeek适配器，v1.0.1）
- **定位**：DeepSeek 深海控制台中的可逆 Harness 配置与提示词部署器，独立本地部署工作台
- **目录结构**：`app/`（deepseek_harness.py 核心）、`harness/`（配置模板）、`docs/`、`pack/`、`scripts/`
- **CLI命令**：
  ```bash
  python app/deepseek_harness.py preview --json   # 只读预览
  python app/deepseek_harness.py deploy --profile max --json  # 部署
  python app/deepseek_harness.py verify --json    # SHA-256验证
  python app/deepseek_harness.py activate --trigger 冷咖啡 --json  # 激活
  python app/deepseek_harness.py restore --json   # 恢复基线
  ```
- **可逆部署合同**：preview（只读）→ deploy（原子写入）→ verify（逐文件核对SHA-256）→ restore（恢复首次部署前原始字节）→ export（导出可移植会话模板）
- **启动口令**：`冷咖啡` / `cold coffee` / `[[ENI:PROFILE=MAX]]`，固定正文 SHA-256: `F7FB45C5DEC0F77E5AFD415DABAACCEEB5B2DDCF1F9918B7B2198BB911F34246`

### 4. grok4.6-coldbrew（Grok适配器，v1.0.1）
- **定位**：Grok 4.6 高速信息流中的可逆会话模板与系统提示词部署器
- **目录结构**：`app/`（grok_coldbrew.py 核心）、`docs/`、`pack/`、`scripts/`
- **CLI命令**：
  ```bash
  python app/grok_coldbrew.py preview --json
  python app/grok_coldbrew.py deploy --profile max --json
  python app/grok_coldbrew.py verify --json
  python app/grok_coldbrew.py activate --trigger 冷咖啡 --json
  python app/grok_coldbrew.py restore --json
  ```
- **可逆部署合同**：与 deepseek-harness 相同的五动作（preview/deploy/verify/restore/export）
- **部署目标**：用户指定的 `.grok` 目录，原有 JSON 配置字段保留，完整恢复还原安装前逐字节基线

### 5. shared（共享模块）
- 四个适配器共用的资源、工具函数、配置模板

### 子技能统计
- **核心模型适配器**：4个（claude / codex / deepseek / grok）
- **五刃任务分类**：5个（REV / UNLOCK / INFIL / HARVEST / TRAINER）
- **支撑模块**：shared + desktop原生窗口 + Python Hub面板 = 3个
- **合计**：12个子模块（核心子技能9个）

---

## 与本技能（tvbox-dev）的关联点

- **HARVEST（爬虫刃）**：与tvbox-dev的影视站爬虫架构有概念交集，可作为爬虫任务的分类标签参考
- **多模型调度**：四模型并行的思路可参考用于复杂影视站的多端点分析
- **文件级任务流程**：预览→部署→验证→回滚 的四步流程与tvbox-dev的侦察→匹配→开发→打包思路一致

## 注意事项

- 本工具为第三方聚合客户端，使用需遵守各模型平台的服务条款
- 项目涉及的"破甲/越狱/破解/渗透"等功能仅为安全研究用途，禁止用于非法活动
- 不要将API密钥和本机快照推送到公开仓库
- 许可证：见项目 LICENSE 文件（禁止倒卖、禁止闭源）

---

## 豆包适配（五刃任务模板）

> 将冷咖啡的四模型五刃体系转换为豆包可直接执行的任务分类与工作流。无需第三方模型，豆包本身即可按刃口分类处理任务。
> **合法边界**：所有刃口仅限学习研究、授权测试、合法数据采集；禁止制作破解补丁/注册机、未授权渗透、游戏外挂分发等非法活动。

### 模型映射（四模型 → 豆包能力）

| 冷咖啡模型 | 豆包对应能力 | 适用场景 |
|-----------|-------------|---------|
| GPT-5.6 | 豆包通用推理 + 代码生成 | 通用任务、代码编写、逻辑分析 |
| Claude（Opus/Sonnet） | 豆包长文本分析 + 深度写作 | 长文档解读、报告撰写、代码审查 |
| Grok 4.6 | 豆包实时搜索 + 信息整合 | 实时资讯、多源信息聚合 |
| DeepSeek v4 Pro | 豆包代码专项 + 数学推理 | 算法题、复杂代码、数学计算 |

> 豆包可根据任务类型自动调度对应能力，无需手动切换模型。

### 五刃任务模板（豆包版）

#### 刃1：REV 逆向分析（学习研究用）
- **口语触发**："分析一下这个程序"、"看看这个软件怎么实现的"、"逆向分析这个文件"
- **豆包工作流**：
  1. 文件类型识别（PE/ELF/APK/JAR）
  2. 静态结构分析（导入表、字符串、节区）
  3. 关键函数定位与伪代码还原
  4. 算法逻辑梳理与流程图
  5. 输出分析报告（仅学习用途，不含破解步骤）
- **交付物**：分析报告、伪代码、偏移标注、算法说明
- **合法边界**：仅限学习研究与授权安全审计，不提供破解/绕过保护的具体步骤

#### 刃2：UNLOCK 软件保护分析（学术研究用）
- **口语触发**："分析这个软件的保护机制"、"研究一下注册验证逻辑"
- **豆包工作流**：
  1. 保护机制识别（壳/虚拟机/反调试/网络验证）
  2. 验证流程梳理（注册码算法/网络校验/硬件绑定）
  3. 保护强度评估与 bypass 思路分析（仅理论层面）
  4. 输出保护机制分析报告
- **交付物**：保护机制分析报告、验证流程说明、强度评估
- **合法边界**：仅学术研究与授权渗透测试，不制作注册机/破解补丁，不提供可操作的破解步骤

#### 刃3：INFIL 授权渗透测试
- **口语触发**："对这个授权目标做渗透测试"、"安全评估这个站点"
- **豆包工作流**：
  1. 授权确认（必须有明确书面授权）
  2. 信息收集（子域名/端口/服务/指纹）
  3. 漏洞扫描与验证（按OWASP Top10）
  4. 风险分级与修复建议
  5. 输出渗透测试报告
- **交付物**：渗透测试报告、漏洞清单、修复建议
- **合法边界**：必须有目标方明确书面授权，禁止未授权测试，禁止破坏性攻击

#### 刃4：HARVEST 数据采集（合法爬虫）
- **口语触发**："采集这个站点的数据"、"爬取这个页面的信息"、"影视站适配"
- **豆包工作流**：
  1. 站点结构探测（robots.txt/分类/分页/API）
  2. 反爬机制识别与适配（请求头/频率/代理/TLS指纹）
  3. 数据解析脚本编写（XPath/CSS/正则/JSON）
  4. 增量续爬与数据校验
  5. 输出采集脚本与数据样本
- **交付物**：爬虫脚本、数据样本、字段说明、续爬方案
- **合法边界**：遵守robots.txt与版权法，不采集个人隐私数据，不用于商业分发，频率控制不影响站点正常运行
- **与tvbox-dev关联**：影视站采集直接走tvbox-dev的四步流水线（侦察→匹配→爬虫→小程序打包）

#### 刃5：TRAINER 游戏逆向分析（学习用）
- **口语触发**："分析这个游戏的内存结构"、"研究一下游戏渲染"
- **豆包工作流**：
  1. 游戏引擎识别（Unity/Unreal/自研）
  2. 内存结构分析（实体列表/坐标/属性）
  3. 渲染管线梳理（D3D/OpenGL/Vulkan钩子点）
  4. W2S（世界坐标转屏幕坐标）算法推导
  5. 输出逆向分析报告（仅学习用途）
- **交付物**：内存结构分析、W2S算法说明、渲染管线报告
- **合法边界**：仅游戏安全研究与学习，不制作/分发外挂，不提供可直接运行的作弊代码

### 豆包五刃调度规则

1. **自动锁刃**：用户输入含明确动词时自动锁定对应刃口（如"爬取"→HARVEST、"分析程序"→REV）
2. **未指定则全开**：用户未明确刃口时，按任务内容综合调度多刃能力
3. **合法预检**：涉及UNLOCK/INFIL/TRAINER时，先确认授权与合法边界，再执行分析
4. **影视站优先**：任务涉及影视站/视频源/小程序打包时，优先走tvbox-dev四步流水线，HARVEST刃仅作分类标签
5. **输出规范**：所有刃口输出均为分析报告/脚本/说明，不含可直接用于非法活动的可执行代码

### 豆包 vs 冷咖啡 对比

| 维度 | 冷咖啡 | 豆包适配版 |
|------|--------|-----------|
| 模型 | 四个第三方模型 | 豆包统一调度（通用/长文/搜索/代码） |
| 界面 | Electron原生窗口 + Python面板 | 对话式交互，自动锁刃 |
| 五刃 | 代码标签分类 | 任务模板 + 工作流 |
| 合法边界 | 需用户自行把握 | 内置合法预检与边界声明 |
| 影视站 | 无专项 | 集成tvbox-dev四步流水线 |
