# drpy-node Coder 综合参考

> 来源：drpy-node-coder.zip（SKILL.md + 22个references + CLI工具链）
> 定位：drpy-node（TVBox/影视仓 JS爬虫源）全生命周期一体化开发工具链——建源、诊断、修复、测试、播放调试、仓库发布
> 与本技能关系：补充 JS/QuickJS 爬虫源的模板系统、API函数库、播放lazy机制、async陷阱、L1/L2/L3评估体系，与 `js-spider-and-catpaw-guide.md`（猫源JS/CatPawOpen）互补

---

## 一、架构总览

### 1.1 核心特性

| 特性 | 说明 |
|------|------|
| 全生命周期 | 建源→诊断→修复→测试→播放调试→仓库发布，5步闭环 |
| 自带CLI | `scripts/cli.js`，无需安装MCP，AI直接调用 |
| 零npm依赖 | localDsCore测试引擎bundle（14M，全内联cheerio/axios/drpyS/htmlParser）+ sqlite + 编码wasm |
| DS加密源支持 | `fs read` 自动解密，勿用IDE直接改加密文件 |
| 多引擎源 | php/hipy/cat（hipy改源需kill t4_daemon重载） |

### 1.2 CLI 高频命令

```bash
node cli.js doctor                          # 自检
node cli.js fetch <url> [--method POST --header k=v --data]  # 抓取
node cli.js analyze <url> | guess <url>    # 清洗DOM | 探模板
node cli.js debug --rule 'a&&href' --mode pdfh --url <url>  # 规则调试
node cli.js fs read <path> | fs write <path> --content ...   # 读写(.js自动DS解密)
node cli.js syntax <path> | validate <path> | resolved <path>
node cli.js test <src> <home|category|detail|search|play> [--class-id/--ids/--keyword/--play-url/--flag]
node cli.js evaluate <src> [--keyword 斗罗大陆]  # 全流程评分(满分100)
node cli.js house verify | house upload <path> --tags .. | house info <cid>
```

---

## 二、5步闭环工作流

```
用户输入
  │
Step1 识别输入 ──仅 URL──→ 分析站点 → 建源路线
  │（已有源名/文件）
Step2 评估现状：syntax+validate(L1) → test 单接口(L2) → evaluate 全流程(L3)
  │
Step3 判断失败类型：A规则不通 / B评估串联 / C播放链
  │  🛑 检查点1：确认诊断结论
Step4 分流执行：本 skill 修 / 转播放调试 / 转仓库
  │
Step5 收束：evaluate 复评 → 🛑 检查点2 → 上传建议 / 结束
```

**核心原则**：先评估→再分流→再修复→再验证→最后给上传建议。不要一上来就重写。

---

## 三、L1/L2/L3 证据链

| 等级 | 命令 | 能下结论 | 不能下结论 |
|------|------|---------|-----------|
| L1 | `syntax` + `validate` | 非语法残档、rule结构合法，可拆测 | 可用、已修好、可上传 |
| L2 | `test <src> <iface>` 单接口 | 某接口真实通/断（须带真实上游返回值） | 全链稳定、可发布 |
| L3 | `evaluate <src>` 全流程 | 首页→一级→二级→播放→搜索串联评分 | 站点长期稳定 |

**结论必须带等级**，例"L2显示detail通、play断"，不要说成"整个源不通"。

**evaluate丢分映射**：
- 首页20+一级20丢 → `class_parse` 未命中
- 仅首页20丢 → `double` 不匹配
- 搜索10丢 → 已按源名后缀选默认词，仍丢则换词查 `searchUrl`
- 二级25丢 → `detailUrl`/二级字典
- 播放25丢 → 先看 `test detail` 的 `play_url_diagnosis`：detail有数据但 `vod_play_url` 空属二级选择器/detailUrl问题（非play层）；仅当detail完整且play真失败才转Playwright嗅探
- 常见误判：detail返回列表项（只有vod_id/vod_name/vod_pic）而非完整详情 = 缺 `detailUrl`

---

## 四、建源30秒路线（仅URL入口）

**Step0 alive check**：`fetch <url>` 确认可达；`guess <url>` 探模板；`analyze <url>` 看HTML/SPA。遇 `broken_site`/`hard_anti_bot`/`missing_credentials` 停手。

**站型分派**（先 `guess`）：

| 路线 | 条件 | 处理 |
|------|------|------|
| A 模板继承 | 命中模板 | 最小覆盖 host/url/searchUrl/class_parse，勿急重写 |
| B1 字符串规则 | 未命中+DOM完整 | +二级字典 |
| B2 async签名接口 | 未命中+签名接口 | async 一级/搜索 |
| C 全async | body空+JSON API | 全async函数 |
| D 特殊内容 | 漫画/小说/音乐/网盘 | 特殊协议 |
| 停手 | 403/登录/验证码 | 停手回报 |

---

## 五、7条必背规则（含async的源必过）

1. **`this.input` 是URL不是响应**，须 `await request(this.input)`
2. **纯数字vod_id必设 `detailUrl`**（只要vod_id不是完整详情页URL就必须设）
3. **POST用 `body` 非 `data`**（`body: JSON.stringify(...)`，data会被当成form-data）
4. **`searchUrl` 必带 `**`**（不带则 `this.KEY` 为空）
5. **推荐要全量聚合去重**（精选+最新+热门+各分类，按vod_id去重）
6. **async用 `this.input`/`this.MY_CATE`/`this.MY_PAGE`**，勿手拼URL（例外：class_parse/外部搜索服务）
7. **不写重复同名属性**（JS对象后者覆盖前者，删掉空占位）

---

## 六、12个内置模板速查

| 模板名 | CMS类型 | URL模式 | double | 二级lazy |
|--------|---------|---------|--------|----------|
| **mx** | 苹果CMS旧版 | `/vodshow/fyclass--------fypage---/` | true | common_lazy |
| **mxpro** | 苹果CMS Pro | `/vodshow/fyclass--------fypage---.html` | true | common_lazy |
| **mxone5** | One5主题 | `/show/fyclass--------fypage---.html` | true | common_lazy |
| **首图** | 首图CMS | `/vodshow/fyclass--------fypage---/` | true | common_lazy |
| **首图2** | 首图CMS v2 | `/list/fyclass-fypage.html` | true | common_lazy |
| **vfed** | VFed CMS | `/index.php/vod/show/id/fyclass/page/fypage.html` | true | common_lazy |
| **海螺3** | 海螺CMS v3 | `/vod_____show/fyclass--------fypage---.html` | true | common_lazy |
| **海螺2** | 海螺CMS v2 | `/index.php/vod/show/id/fyclass/page/fypage/` | true | common_lazy |
| **短视** | 短视频 | `/channel/fyclass-fypage.html` | true | common_lazy |
| **短视2** | 短视频v2 | `/index.php/api/vod#type=fyclass&page=fypage` | true | common_lazy |
| **采集1** | 采集站 | `/api.php/provide/vod/?ac=detail&pg=fypage&t=fyclass` | false | cj_lazy |
| **默认** | 通用兜底 | 空 | false | def_lazy |

### double机制
`double: true` 的模板，推荐规则使用两层解析：先取外层容器（如 `.tab-list.active`），再从内层列表提取数据。首页推荐为空且用了模板继承，优先设 `double: false` 重新测试。

### 模板修改函数
```js
模板修改: async function(muban) {
    muban.mxpro.一级 = '自定义选择器';
}
```

### 自动模板匹配
```js
rule = { 模板: '自动', host: 'https://example.com' }
// 框架自动请求host页面，用每个模板的class_parse尝试解析
// 第一个成功解析出分类的模板被选中
```

---

## 七、drpy API 函数库（沙箱全局注入）

> DS源运行在drpy注入沙箱中，不是普通Node.js模块。可使用以下全局函数，但不要假设原生fs/process/Node require可用。

### 7.1 核心请求

| 函数 | 说明 |
|------|------|
| `request(url, options?)` | 主HTTP请求，返回响应体(string)。options: `{headers, method, data/body, timeout, encoding}` |
| `post(url, options?)` | POST请求快捷方式 |
| `req(url, options?)` | 底层请求封装，返回 `{content, headers, code}` |
| `fetch(url, options?)` | fetch兼容的请求 |
| `reqs(urls, options?)` | 批量请求 |

### 7.2 HTML/XML 解析

| 函数 | 说明 |
|------|------|
| `pdfh(htmlOrNode, rule)` | 提取节点文本/属性。rule: `a&&Text` / `img&&src` / `.title&&Text` |
| `pd(htmlOrNode, rule, baseUrl?)` | 提取并标准化URL（自动解析相对路径） |
| `pdfa(htmlOrNode, selector)` | 获取节点列表（纯CSS选择器） |
| `pdfl(htmlOrNode, rule)` | 选集列表解析 |
| `jsp(baseUrl?)` | 创建jsoup解析器实例 |

### 7.3 JSON 解析

| 函数 | 说明 |
|------|------|
| `pjfh(json, rule)` | JSON模式pdfh |
| `pjfa(json, rule)` | JSON模式pdfa |
| `pj(json, rule)` | JSON模式pd |

### 7.4 加密与编解码

| 函数/库 | 说明 |
|---------|------|
| `base64Encode/Decode` | Base64 |
| `md5/md5X` | MD5 |
| `aesX/aes` | AES加解密 |
| `desX/des` | DES |
| `rsaX/RSA` | RSA |
| `rc4Encrypt/Decrypt` | RC4 |
| `gzip/ungzip` | Gzip压缩 |
| `CryptoJS` | 完整CryptoJS库 |
| `JSEncrypt/NODERSA` | RSA库 |
| `forge` | node-forge库 |

### 7.5 UA 常量

`MOBILE_UA` / `PC_UA` / `UC_UA` / `IOS_UA` / `UA` / `randomUa.generateUa()`

### 7.6 async 函数 this 上下文

```js
let { input, MY_URL, HOST, MY_CATE, MY_PAGE, MY_FL, KEY,
      pdfa, pdfh, pd, pjfa, pjfh, pj } = this;
```

| 变量 | 含义 |
|------|------|
| `input` | 渲染后的完整URL，**不是响应体** |
| `MY_URL` | 当前请求的完整URL |
| `MY_CATE` | 分类ID |
| `MY_PAGE` | 当前页码 |
| `MY_FL` | 筛选条件对象 |
| `KEY` | 搜索关键词 |

### 7.7 结果格式化

`setResult(d)`：`d` 是 `{title, url, desc, pic_url, content}[]`，内部映射 title→vod_name, url→vod_id, desc→vod_remarks, pic_url→vod_pic, content→vod_content。

### 7.8 其他工具

`log/print` / `sleep(ms)` / `deepCopy` / `computeHash` / `jsonToCookie/cookieToJson` / `toBeijingTime` / `fixAdM3u8Ai(url, content, headers?)`（修复带广告的m3u8）/ `ENV.get/set` / `local.get/set`（本地持久化）/ `OcrApi` / `simplecc`（简繁转换）/ `DataBase/database`（SQLite）/ `batchFetch`（批量并发）

---

## 八、播放 lazy 三类型

### 8.1 common_lazy（通用免嗅探，mx/mxpro/首图/海螺/短视等）

核心逻辑：
```js
let html = await request(input);
let hconf = html.match(/r player_.*?=(.*?)</)[1];
let json = JSON5.parse(hconf);
let url = json.url;
if (json.encrypt == '1') url = unescape(url);
else if (json.encrypt == '2') url = unescape(base64Decode(url));
if (/\.(m3u8|mp4|m4a|mp3)/.test(url)) return {parse:0, jx:0, url};
if (tellIsJx(url)) return {parse:0, jx:1, url};
return input;
```

| 条件 | 返回 | 说明 |
|------|------|------|
| 解析到m3u8/mp4/m4a/mp3 | `{parse:0, jx:0, url}` | 直链 |
| 解析到站外解析链接 | `{parse:0, jx:1, url}` | 站外解析器 |
| 都不满足 | `input` | 回退原链接交默认嗅探 |

**加密处理**：encrypt='1' → unescape(url)；encrypt='2' → base64Decode(url) → unescape()

### 8.2 def_lazy（默认嗅探）

```js
return { parse: 1, url: input, js: '' }
```
完全交由嗅探系统，`parse:1` 不一定是错。

### 8.3 cj_lazy（采集站）

- 直链m3u8/mp4 → `parse:0`
- `parse_url` 以 `json:` 开头 → 先请求JSON解析接口再取 `json.url`
- 否则拼接 `rule.parse_url + input`

### 8.4 playParseAfter 后处理机制

lazy返回后，框架调用 `playParseAfter()` 做最终判断：
```js
parse = SPECIAL_URL.test(playUrl) || /^(push:)/.test(playUrl) || 
        /\.(m3u8|mp4|m4a|mp3)/.test(playUrl) ? 0 : 1;
jx = tellIsJx(playUrl);
```
**含义**：即使lazy返回 `{parse:1, url}`，如果url以m3u8/mp4结尾→框架自动覆盖为parse:0。

### 8.5 特殊协议

| 内容类型 | 协议 | lazy返回格式 |
|---------|------|-------------|
| 漫画 | `pics://` | `{parse:0, url: 'pics://url1&&url2&&url3'}` |
| 小说 | `novel://` | `{parse:0, url: 'novel://' + JSON.stringify({title, content})}` |
| 投屏 | `push://` | `{parse:0, url: 'push://...'}` |

### 8.6 多线路混合处理

```js
lazy: async function () {
    let {input} = this;
    if (/\.(m3u8|mp4)/.test(input)) return {parse: 0, url: input};  // 直链线路
    if (/webplay/.test(input)) {
        let html = await request(input);
        let iframe = pdfh(html, 'iframe&&src');
        return {parse: 0, url: iframe};
    }
    return {parse: 1, url: input};  // 需解析线路
}
```

### 8.7 假通过识别

`play` success≠真实可播，返回url仍是play.html/API/普通页时继续验扩展名/content-type/网络请求。

---

## 九、async 函数八大陷阱

| # | 陷阱 | 正确做法 |
|---|------|---------|
| 1 | `this.input` 是URL不是响应 | `await request(this.input)`，不要 `JSON.parse(this.input)` |
| 2 | 纯数字vod_id必须设detailUrl | `detailUrl: '/api/videos/fyid'`，引擎替换fyid |
| 3 | POST用body非data | `body: JSON.stringify(...)`，data会被当成form-data |
| 4 | searchUrl必须带** | `searchUrl: '/api/search?q=**&page=fypage'` |
| 5 | 推荐要全量聚合去重 | 精选+最新+热门+各分类，按vod_id去重 |
| 6 | async用this.input勿手拼URL | url/homeUrl/detailUrl/searchUrl已定义模板，引擎自动替换 |
| 7 | 不写重复同名属性 | JS对象后者覆盖前者，删掉空占位 |
| 8 | 外部API可能需要额外Header | 从浏览器Network抓取Authorization/Origin/Referer |

**排障速查**：
| 症状 | 优先检查 |
|------|---------|
| JSON.parse报URL不是JSON | this.input是URL不是响应 |
| 二级全部为空 | detailUrl是否设置了占位符 |
| 搜索始终空但没报错 | searchUrl带** / POST用body / Authorization |
| 推荐只有几条 | 是否只取了一个推荐字段 |
| POST请求服务端不认 | data改成body: JSON.stringify(...) |

---

## 十、工作流分诊（4种失败情况）

| 情况 | 优先检查 |
|------|---------|
| A 首页class为空 | 模板残留class_parse / class_name/class_url是否被覆盖 |
| B 首页list为空但页面有推荐卡片 | 模板默认double / 推荐是单层还是双层（先测double:false） |
| C 一级不通 | 分类url是否真实 / 是否该删手写一级回模板内置 / 分类页节点是否存在 |
| D 搜索不通 | searchUrl是否真实 / 是否该删手写搜索回模板内置 / 搜索页容器是否不同 |

**模板内置优先判断表**：
| 场景 | 优先动作 |
|------|---------|
| 一级不通且明显命中模板 | 先删手写一级测模板内置 |
| 搜索不通且明显命中模板 | 先删手写搜索测模板内置 |
| 首页推荐为空但真实节点存在 | 先测double:false |
| 首页class为空但规则里写了分类 | 先测class_parse:'' |

---

## 十一、多引擎源（php/hipy/cat）

| 引擎 | 说明 | 注意事项 |
|------|------|---------|
| php | Python爬虫源 | `?do=py&extend=` 必须带extend |
| hipy | 高性能Python（daemon模式） | 改 `spider/py/*.py` 或 `base/spider.py` 后必须kill `t4_daemon` 重载（daemon缓存module），否则改动不生效 |
| cat | CatPawOpen（Node.js） | `?do=cat&extend=`，改了直接生效无daemon问题 |

---

## 十二、仓库发布守门

上传前必跑：`house verify` + `syntax` + `validate` + 源metadata自洽。给出A/B/C档+L1/L2/L3证据：

| 档位 | 条件 | 建议 |
|------|------|------|
| A 建议上传 | 至少L2，最终版/自主要求L3=100 | 上传 |
| B 技术可传不建议 | L1/L2 | 用户坚持才传 |
| C 暂不传 | 触红线（语法错/结构无效/metadata不一致/详情空/播放假通过/特殊内容无对应协议） | 不传 |

**上传**：`house upload <path> --tags <逗号分隔> --is-public true --auto-replace true`（默认同名自动替换）。上传后 `house info <cid>` 核验。

**标签规则**：不脑补、不因文件名带`[优]`就加`优`，严格按用户明确要求。

---

## 十三、与 tvbox-dev 现有架构的融合点

| drpy-node-coder | tvbox-dev 现有 | 融合建议 |
|-----------------|---------------|---------|
| 12内置模板（mx/mxpro/海螺/首图等） | 站点类型判定（4类：聚合/CMS/CF/eval） | 补充CMS子类型速查表，建源时先guess模板 |
| 7条必背规则（async源） | 爬虫代码铁律（部分覆盖） | 补充到代码铁律，async源必过 |
| lazy三类型（common/def/cj） | eval解包/播放地址转换 | 补充播放lazy机制，player_aaaa提取对应common_lazy |
| playParseAfter后处理 | 无 | 补充框架自动覆盖parse的机制 |
| L1/L2/L3评估体系 | 全链路自测（逐接口验证） | 补充分级评估，结论必须带等级 |
| drpy API函数库（pdfh/pdf/pd/pj等） | Python四壳协议（BS4/requests） | JS源开发时查阅，与Python函数对应 |
| async八大陷阱 | 无（主要Python） | JS源开发必避，已炼入代码铁律7条 |
| 多引擎源（php/hipy/cat） | 无 | 补充多引擎支持，hipy改源需kill daemon |
| 仓库发布守门（A/B/C档） | 无 | 补充源发布质量标准 |
| 工作流分诊（4种失败） | 适配工作流10步 | 补充快速分诊，模板内置优先 |
| 特殊协议（pics/novel/push） | 无 | 补充漫画/小说/投屏源支持 |
| DS加密源（fs read自动解密） | 无 | 补充加密源处理 |
| CLI工具链（test/evaluate/house） | 源构工坊（辅助工具） | 互补，drpy CLI专用于JS源测试评估 |

---

*本文件记录drpy-node-coder完整工具链体系，与tvbox-dev现有Python四壳协议架构互补，专门覆盖JS/QuickJS爬虫源的模板系统、API函数、播放lazy、async陷阱、分级评估和仓库发布。*
