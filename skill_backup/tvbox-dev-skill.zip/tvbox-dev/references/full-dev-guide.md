# TVBox二次开发完整文档（WebHTV / webhtv）
> 仓库：https://github.com/Silent1566/webhtv
> 基于鱼佬FongMi TVBox + 默影视WebHome合体壳
> 本文档为分阶段完整学习路线，循序渐进掌握整套技能

## 目录
1. [技能概述与掌握目标](#1-技能概述与掌握目标)
2. [前置技术栈](#2-前置技术栈)
3. [项目源码结构解析](#3-项目源码结构解析)
4. [阶段1：基础使用与配置理解](#阶段1基础使用与配置理解)
5. [阶段2：WebHome网页首页开发](#阶段2webhome网页首页开发)
6. [阶段3：Spider爬虫开发](#阶段3spider爬虫开发)
7. [阶段4：HTTP服务与多设备同步](#阶段4http服务与多设备同步)
8. [阶段5：源码编译打包全流程](#阶段5源码编译打包全流程)
9. [阶段6：播放器底层进阶](#阶段6播放器底层进阶)
10. [阶段7：实战项目训练](#阶段7实战项目训练)
11. [高频报错排查清单](#高频报错排查清单)
12. [项目文档与资源定位](#项目文档与资源定位)

---

## 1. 技能概述与掌握目标
**技能名称**：TVBox影视壳二次开发（WebHTV 鱼佬FongMi+默影视WebHome合体版本）
**技能分类**：Android应用二次开发 | WebView混合开发 | 爬虫脚本开发 | 多媒体播放器定制 | 局域网服务开发

**掌握目标**：
1. 独立搭建整套源码编译环境，从源码编译、打包、签名发布APK
2. 掌握WebHome体系，独立开发自定义网页首页、Web扩展注入脚本，实现网页和TVBox原生App双向调用
3. 掌握3套爬虫方案：Java Jar爬虫、QuickJS JS爬虫、Chaquo Python爬虫，能独立编写站点解析脚本
4. 理解内置局域网HTTP服务API，可调用接口读写观看历史、收藏，部署远程中转同步服务实现多端数据同步
5. 理解MPV/IJK/Media3多播放器底层原理，能够编译原生so库，调试HDR、杜比视界、音视频硬解策略
6. 读懂项目源码结构，可修改壳内原生逻辑，新增设置项、UI模块、API接口

**项目核心亮点**：
1. 原生FongMi（鱼佬）TVBox内核
2. WebHome网页首页：HTML+JS自定义首页，WebView和App双向通信
3. Web扩展脚本：给站点注入JS/CSS，自定义页面逻辑
4. 内置局域网HTTP服务，提供管理页面 `/m`
5. 多设备一键同步：配置、收藏、观看历史、登录Cookie
6. QuickJS / Chaquo Python双脚本爬虫引擎，无需编译Jar
7. MPV + IJK + Media3多播放器切换，支持HDR、杜比视界

---

## 2. 前置技术栈
> 不需要全部精通，但必须看得懂基础代码

### Android开发基础
- Kotlin为主，少量Java代码阅读能力
- Gradle项目构建原理，依赖管理
- Android TV开发基础，遥控器焦点、Leanback电视UI适配
- JNI基础概念，理解Java和C/C++原生库交互（不用精通C，但看得懂so库报错）

### 前端Web基础（WebHome核心依赖）
- HTML、CSS、原生JavaScript基础语法
- WebView通信原理，JS调用Android原生方法
- 浏览器调试，Console控制台、Network网络面板
- 跨域CORS原理，了解跨域请求限制与代理解决方案
- TV端网页焦点导航，键盘方向键选中元素开发

### 脚本语言
- JavaScript基础（QuickJS爬虫、Web扩展脚本都使用JS）
- Python基础语法，用于Chaquo Python爬虫开发

### 网络基础
- HTTP请求、GET/POST、请求头、Cookie会话
- WebSocket长连接原理
- 接口代理、反向代理基础

### 构建工具版本硬性要求
> 版本不能随便更换，错版本直接编译失败
- JDK：21
- Python：3.10（3.11及以上版本Chaquo会报错，不支持）
- Android SDK Platform：37；Build-Tools：37.0.0
- NDK：MPV编译使用 r29；IJK播放器编译使用 r28c

---

## 3. 项目源码结构解析
```
webhtv
├── app/                # Android主程序模块，产出两个版本：mobile手机版 / leanback电视版
├── catvod/             # CatVod核心抽象层：爬虫Spider基础抽象类、网络请求封装、站点解析核心逻辑
├── quickjs/            # QuickJS JS爬虫运行时，JS脚本执行引擎
├── chaquo/             # Chaquo Python爬虫运行时，在Android App内运行Python脚本
├── webhome-devkit/     # WebHome全套开发套件【项目最重要目录】
│   ├── docs/           # 项目官方完整开发文档
│   ├── examples/       # 首页开发示例、Web扩展示例源码
│   └── templates/      # WebHome网页基础HTML模板
├── scripts/            # 自动化构建shell脚本，MPV、IJK、FFmpeg原生库编译脚本
├── third_party/        # 第三方依赖源码、Media3补丁文件、播放器补丁
└── Release/            # APK打包输出目录，Debug/Release包输出位置
```

---

## 阶段1：基础使用与配置理解
**学习目标**：把项目编译出Debug APK，完整跑通APP；熟悉全部增强功能，读懂站点JSON配置，理解WebHTV对比原版FongMi新增的所有特性。

### 学习任务
1. 克隆源码，搭建基础编译环境，编译Debug APK，安装到手机或者电视设备
2. 完整浏览APP设置页面，逐个熟悉所有增强功能：
   - WebHome自定义网页首页、站点网页注入
   - Web扩展脚本管理模块
   - 局域网后台管理页面 `/m`
   - 多设备一键同步功能
   - Cookie登录态捕获、跨设备登录信息同步
   - 网盘链接批量有效性检测
   - 站点健康状态检测、自动排序
   - 播放记录Webhook远端上报
   - 内置网络代理、应用调试日志面板
3. 学习站点JSON完整规范，读懂点播站点、直播站点、解析站点全部字段含义

### 站点JSON示例
```json
{
 "key": "demo",
 "name": "演示站点",
 "type": 3,
 "api": "csp_demo",
 "homePage": "https://xxx/demo.html"
}
```
> `homePage`字段作用：为当前CSP站点绑定WebHome网页首页，这是本项目区别原版TVBox的标志性核心功能。

---

## 阶段2：WebHome网页首页开发
> 传统原版TVBox首页使用Android XML布局写死；WebHTV的WebHome可以直接用HTML开发首页页面，网页JS可以调用App原生能力，实现混合开发。

### 学习任务
1. 学习 `window.fm` 原生SDK，掌握网页JS 和 Android App之间双向通信原理
2. 学习电视端网页开发：HTML页面适配遥控器方向键焦点导航，处理选中状态、按键事件
3. 学习跨域解决方案：使用 `fm.req()` 内置代理发起网络请求，绕过浏览器CORS跨域限制
4. WebHome扩展脚本开发：编写JS/CSS注入脚本，匹配指定站点，修改站点页面渲染、劫持页面交互逻辑
5. 使用webhome-devkit自带HTML模板，本地调试页面，学会控制台查看日志、排查网页报错
6. 独立修改模板页面，调整布局、样式，熟悉网页资源加载、图片代理 `fm.res` 使用

### WebHome核心原理
- 网页运行在App内置WebView中
- App向WebView注入 `window.fm` 对象，网页JS调用该对象的方法
- App原生层接收调用，执行对应操作（网络请求、播放、跳转等）
- 结果通过回调或Promise返回给网页JS

### TV焦点适配要点
- 所有可交互元素设置 `tabindex` 属性
- 监听 `keydown` 事件，处理方向键（ArrowUp/ArrowDown/ArrowLeft/ArrowRight）
- 维护当前焦点元素，方向键时移动焦点到相邻元素
- 焦点元素添加高亮样式（outline、背景色变化等）
- 回车键（Enter）触发点击事件

---

## 阶段3：Spider爬虫开发
WebHTV兼容三套爬虫实现方案，全部学习，按需选用。

### 1. Java Jar爬虫（传统经典TVBox方案）
- 掌握Spider基类核心回调方法：`homeContent`、`categoryContent`、`detailContent`、`searchContent`
- Jar包编写、编译打包、远程加载机制
- MD5校验、ext扩展参数配置

### 2. QuickJS JS爬虫
- QuickJS引擎运行原理
- 直接编写JS解析脚本，**不需要编译Jar包**，热加载调试

### 3. Chaquo Python爬虫
- Chaquo在Android中嵌入Python环境原理
- Python脚本解析网页接口、提取视频信息

### 4. CSP XPath规则解析
- 使用 `csp_XPath` 系列配置，不用写代码，快速配置简单站点

### 四核心方法说明
| 方法 | 作用 | 返回内容 |
|------|------|----------|
| homeContent | 首页 | 分类列表 + 首页推荐视频列表 |
| categoryContent | 分类页 | 按分类、分页返回视频列表 |
| detailContent | 详情页 | 视频详情 + 播放线路（多线路用$$$分隔） |
| searchContent | 搜索 | 按关键词搜索返回视频列表 |

---

## 阶段4：HTTP服务与多设备同步
### 学习任务
1. 访问局域网后台页面：`http://设备IP:端口/m`，熟悉网页后台的站点管理、历史记录、收藏操作
2. 掌握内置HTTP API接口：
   - GET `/api/playback/current` 获取当前正在播放的视频信息
   - POST `/api/playback/progress` 写入播放进度，批量新增、删除观看历史记录
3. Webhook机制：配置Webhook地址，播放进度自动推送到远端服务器
4. 远程托管中转后端部署：支持Go、Deno、Vercel、Cloudflare多种后端
   - WebSocket实时通信，网络异常自动降级为HTTP轮询
   - 设备绑定逻辑，远程推送搜索指令到TVBox客户端
5. 多设备一键同步底层原理：局域网内设备之间同步配置文件、观看历史、收藏列表、Cookie登录态、WebHome页面缓存数据

---

## 阶段5：源码编译打包全流程
> 版本约束严格，所有环境版本必须严格匹配，是学习中踩坑最多的环节。

### 基础克隆与编译命令
```bash
git clone https://github.com/Silent1566/webhtv
# 在项目根目录新建 local.properties 文件，写入 sdk.dir=你的AndroidSDK路径
./gradlew :app:assembleMobileArm64_v8aDebug
```

### 学习任务
1. 理解产物输出规则：Release目录输出，区分手机arm64、电视arm64、电视armv7a架构包
2. 快速测试打包参数：`-PfastRelease=true` 开启fastRelease快速打包，节省编译时间
3. GitHub Actions CI自动打包流程：配置工作流，自动编译构建APK
4. Release正式包签名：生成keystore签名文件，配置gradle签名；CI流水线需要keystore转base64存入密钥secrets
5. 学会修改模块依赖、新增资源、新增配置项，重新编译验证修改效果

### 编译产物变体
| 变体 | 命令 | 适用设备 |
|------|------|----------|
| 手机arm64 Debug | `:app:assembleMobileArm64_v8aDebug` | Android手机 |
| 手机arm64 Release | `:app:assembleMobileArm64_v8aRelease` | Android手机正式版 |
| 电视arm64 Debug | `:app:assembleLeanbackArm64_v8aDebug` | Android TV/电视盒子 |
| 电视armv7a Debug | `:app:assembleLeanbackArmeabi_v7aDebug` | 老旧电视盒子 |

---

## 阶段6：播放器底层进阶
> 基础二开不需要编译so原生库；只有修改播放器底层逻辑时才需要。

### 学习任务
1. 两套播放器：MPV（默认主力播放器）、IJK播放器（兼容老旧流媒体协议）；支持Media3作为备选播放内核
2. MPV-JNI编译脚本：`scripts/build_mpv_player_jni.sh`，编译libplayer.so桥接库
3. 完整编译MPV+FFmpeg：`scripts/build_mpv_native.sh`；版本锁文件 `mpv-native-lock.json`，保证所有ABI架构so库版本统一，不能混用不同编译版本的so
4. IJK播放器原生库编译流程
5. Media3补丁体系：`third_party/patches/media3-*.patch`；补丁实现弹幕渲染、杜比DV7、AV3A音频软解能力
6. HDR、杜比视界播放调试；硬解自动回退策略：硬解失败自动切换软解播放

### NDK版本区分
| 播放器 | NDK版本 | 编译脚本 |
|--------|---------|----------|
| MPV | r29 | `scripts/build_mpv_native.sh` |
| MPV-JNI桥接 | r29 | `scripts/build_mpv_player_jni.sh` |
| IJK | r28c | IJK专属编译脚本 |

---

## 阶段7：实战项目训练
全部理论学习完成后，依次完成下面实战项目，完成即代表技能掌握。

1. **实战1**：开发一套独立WebHome HTML首页，替换APP原生首页，完整适配电视遥控器焦点导航
2. **实战2**：开发WebHome扩展脚本，对目标站点页面进行样式修改、元素隐藏、交互劫持
3. **实战3**：编写QuickJS爬虫脚本，新增一个影视站点，实现首页、分类、详情、搜索播放完整链路
4. **实战4**：部署Go语言远程中转后端，实现跨局域网远程推送搜索、多设备播放进度同步
5. **实战5**：修改壳源码，新增APP设置页面配置项，新增自定义HTTP接口
6. **实战6**：调用内置HTTP API，独立开发外部工具，读取、写入TVBox观看历史数据

---

## 高频报错排查清单
1. `Unsupported class file major version`：JDK版本不是21，更换JDK21
2. Chaquo Python相关异常：本机Python版本不是3.10，升级/降级Python到3.10
3. `SDK location not found`：项目根目录local.properties文件不存在，或者sdk.dir路径配置错误
4. `dlopen libplayer.so` 失败：混用不同commit版本编译的so库，ABI库版本不一致，需要全部原生库统一重新编译
5. Release打包签名失败：keystore文件路径、密码配置错误；CI自动打包需要将keystore转base64填入仓库secrets
6. Web网页遥控器焦点失效：HTML页面没有编写TV焦点导航逻辑，没有监听方向键事件、元素tabindex焦点
7. WebSocket连接失败：网络环境限制，会自动降级使用HTTP轮询模式，属于正常降级策略
8. 编译native脚本提示NDK路径错误：环境变量NDK路径配置错误，核对r29/r28c版本区分
9. 网页跨域CORS报错：网页直接fetch第三方接口被拦截，改用 `fm.req()` 内置代理请求
10. 图片加载403：CDN图片对壳的TLS指纹校验，使用 `fm.res()` 资源代理或本地代理中转

---

## 项目文档与资源定位
1. 项目核心文档：`webhome-devkit/docs/应用完整开发文档.md`
2. WebHome扩展开发文档：`webhome-devkit/README.md`
3. WebHome首页示例源码：`webhome-devkit/examples/homepages/`
4. Web扩展示例源码：`webhome-devkit/examples/extensions/`
5. HTML网页基础模板：`webhome-devkit/templates/`
6. MPV/IJK/FFmpeg原生库编译脚本：`scripts/*.sh`
7. Media3补丁文件：`third_party/patches/media3-*.patch`
8. MPV版本锁文件：`mpv-native-lock.json`
