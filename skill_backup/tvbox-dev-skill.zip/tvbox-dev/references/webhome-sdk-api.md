# WebHome window.fm 原生SDK完整接口手册
> WebHTV网页首页与App原生双向通信核心能力
> 网页JS中通过 `window.fm`（或 `window.fongmi`）调用App原生功能

## 目录
1. [SDK概述](#sdk概述)
2. [网络请求类接口](#网络请求类接口)
3. [资源代理类接口](#资源代理类接口)
4. [播放控制类接口](#播放控制类接口)
5. [页面跳转类接口](#页面跳转类接口)
6. [数据读写类接口](#数据读写类接口)
7. [网盘工具类接口](#网盘工具类接口)
8. [UI交互类接口](#ui交互类接口)
9. [TV焦点适配指南](#tv焦点适配指南)
10. [Web扩展脚本开发](#web扩展脚本开发)

---

## SDK概述
WebHome是WebHTV的核心特色，允许使用HTML+JavaScript开发TVBox首页页面。
网页运行在App内置WebView中，App向WebView注入 `window.fm` 全局对象，网页JS调用该对象的方法与App原生层通信。

### 通信原理
```
网页JS → window.fm.xxx() → App原生层执行 → 结果返回(Promise/回调)
```

### 基础调用示例
```javascript
// 所有接口返回Promise，使用async/await或.then()
async function example() {
  try {
    const result = await fm.req({ url: "https://api.example.com/list" });
    console.log(result);
  } catch (e) {
    console.error("请求失败", e);
  }
}
```

---

## 网络请求类接口

### fm.req()
使用App内置代理发起网络请求，**绕过浏览器CORS跨域限制**。
这是WebHome网页最核心的接口，所有第三方API请求都应通过此接口发起。

**参数**：
```javascript
{
  url: "https://api.example.com/data",  // 必填，请求地址
  method: "GET",                          // 可选，GET/POST，默认GET
  headers: {                              // 可选，请求头
    "User-Agent": "Mozilla/5.0",
    "Referer": "https://example.com"
  },
  body: "key=value&key2=value2",         // 可选，POST请求体（表单）
  // 或 JSON body:
  // body: JSON.stringify({key: "value"}),
  // headers中加 "Content-Type": "application/json"
  timeout: 10000                          // 可选，超时毫秒
}
```

**返回**：Promise，resolve为响应体文本（JSON需自行JSON.parse）

**示例**：
```javascript
// GET请求
const data = await fm.req({ url: "https://api.example.com/list?page=1" });
const json = JSON.parse(data);

// POST JSON请求
const result = await fm.req({
  url: "https://api.example.com/search",
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ keyword: "电影", page: 1 })
});
```

**注意**：
- 禁止网页直接使用 `fetch()` 请求第三方接口，CORS会被浏览器拦截
- 所有跨域请求必须通过 `fm.req()` 走App代理
- App代理会自动处理Cookie、TLS指纹等问题

---

## 资源代理类接口

### fm.res()
资源代理接口，中转图片、视频等资源，解决防盗链、CORS、TLS指纹403问题。

**参数**：
```javascript
{
  url: "https://cdn.example.com/cover.jpg",  // 必填，资源地址
  headers: {                                    // 可选，请求头（Referer/Cookie等）
    "Referer": "https://example.com"
  }
}
```

**返回**：Promise，resolve为代理后的本地URL字符串，可直接用于 `<img src>` 或 `<video src>`

**示例**：
```javascript
// 代理图片
const imgUrl = await fm.res({
  url: "https://cdn.example.com/cover.jpg",
  headers: { "Referer": "https://example.com" }
});
document.querySelector("img").src = imgUrl;

// 批量代理封面
const covers = document.querySelectorAll(".cover");
for (const img of covers) {
  const original = img.dataset.src;
  img.src = await fm.res({ url: original });
}
```

**使用场景**：
- CDN图片防盗链返回403
- 图片域名不支持CORS，网页canvas无法绘制
- 视频资源需要特定Referer/Cookie

---

## 播放控制类接口

### fm.play()
调用App原生播放器，传入视频直链开始播放。

**参数**：
```javascript
{
  url: "https://cdn.example.com/video/index.m3u8",  // 必填，视频直链
  title: "视频标题",                                    // 可选，显示在播放器的标题
  headers: {                                            // 可选，播放请求头
    "Referer": "https://example.com",
    "User-Agent": "Mozilla/5.0"
  }
}
```

**返回**：Promise，播放器启动后resolve

**示例**：
```javascript
// 直接播放m3u8
fm.play({
  url: "https://cdn.example.com/video/index.m3u8",
  title: "测试视频",
  headers: { "Referer": "https://example.com" }
});
```

**注意**：
- 传入的必须是视频直链（m3u8/mp4等），不能是网页播放页URL
- 需要解析播放页获取真实地址时，先用 `fm.req()` 请求播放页解析出直链，再调用 `fm.play()`
- 播放器使用App当前选中的播放内核（MPV/IJK/Media3）

---

## 页面跳转类接口

### fm.vod(siteKey, vodId)
跳转指定站点的视频详情页面（App原生详情页）。

**参数**：
- `siteKey`：站点JSON配置中的 `key` 字段值
- `vodId`：视频在该站点的唯一ID

**返回**：Promise

**示例**：
```javascript
// 跳转到key为"demo"的站点，ID为"12345"的视频详情页
fm.vod("demo", "12345");

// 卡片点击事件
card.addEventListener("click", () => {
  fm.vod(card.dataset.siteKey, card.dataset.vodId);
});
```

### fm.search(keyword)
在App内执行关键词搜索，打开搜索结果页。

**参数**：
- `keyword`：搜索关键词字符串

**返回**：Promise

**示例**：
```javascript
// 搜索框回车
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    fm.search(searchInput.value.trim());
  }
});
```

---

## 数据读写类接口

### fm.history()
获取本机全部观看历史记录。

**返回**：Promise，resolve为历史记录数组
```javascript
[
  {
    siteKey: "demo",
    vodId: "12345",
    title: "视频标题",
    cover: "https://.../cover.jpg",
    progress: 1234,        // 播放进度（秒）
    duration: 3600,         // 总时长（秒）
    updateTime: 1699999999  // 更新时间戳
  }
]
```

**示例**：
```javascript
const history = await fm.history();
// 渲染"继续观看"区域
history.slice(0, 10).forEach(item => {
  console.log(item.title, item.progress);
});
```

### 收藏相关接口
> 具体接口名以项目文档 `webhome-devkit/docs/应用完整开发文档.md` 为准，常见包括：
- `fm.favorite.list()` — 获取收藏列表
- `fm.favorite.add(siteKey, vodId)` — 添加收藏
- `fm.favorite.remove(siteKey, vodId)` — 移除收藏
- `fm.favorite.check(siteKey, vodId)` — 检查是否已收藏

### 设置读取接口
> 读取App配置项，具体接口名查阅项目文档。
- 常见用途：读取当前主题色、播放器设置、站点列表等，用于网页样式适配

---

## 网盘工具类接口

### fm.pan.check()
批量检测网盘链接有效性。

**参数**：
```javascript
{
  urls: ["https://pan.baidu.com/s/xxx", "https://www.aliyundrive.com/s/xxx"],
  // 网盘链接数组
}
```

**返回**：Promise，resolve为检测结果数组
```javascript
[
  { url: "...", valid: true,  name: "文件名", size: "1.2G" },
  { url: "...", valid: false, reason: "链接已失效" }
]
```

**示例**：
```javascript
const results = await fm.pan.check({
  urls: ["https://pan.baidu.com/s/abc123", "https://www.aliyundrive.com/s/def456"]
});
results.forEach(r => {
  console.log(r.url, r.valid ? "有效" : "失效");
});
```

---

## UI交互类接口
> 以下为常见UI接口，具体接口名和参数以项目文档为准。

### 弹窗提示
```javascript
fm.toast("提示文字");  // 短暂Toast提示
fm.dialog({ title: "标题", message: "内容" });  // 弹窗对话框
```

### 本地存储
```javascript
fm.storage.set("key", "value");   // 写入本地存储
const value = await fm.storage.get("key");  // 读取本地存储
fm.storage.remove("key");          // 删除
```

---

## TV焦点适配指南
WebHome网页运行在电视/电视盒子上，主要输入设备是遥控器，必须适配焦点导航。

### 核心要点
1. **所有可交互元素设置 `tabindex`**：
   ```html
   <div class="card" tabindex="0" data-vod-id="123">...</div>
   ```

2. **监听方向键事件**：
   ```javascript
   document.addEventListener("keydown", (e) => {
     const current = document.activeElement;
     switch (e.key) {
       case "ArrowUp":    /* 移动焦点到上方元素 */ break;
       case "ArrowDown":  /* 移动焦点到下方元素 */ break;
       case "ArrowLeft":  /* 移动焦点到左侧元素 */ break;
       case "ArrowRight": /* 移动焦点到右侧元素 */ break;
       case "Enter":      /* 触发当前元素点击 */ current.click(); break;
     }
   });
   ```

3. **焦点高亮样式**：
   ```css
   .card:focus {
     outline: 3px solid #4a9eff;
     outline-offset: 2px;
     transform: scale(1.05);
     transition: all 0.15s ease;
   }
   ```

4. **网格布局焦点移动**：
   - 记录每行元素数量，方向键时计算相邻元素索引
   - 边界处理：第一行按Up不移动，最后一行按Down不移动
   - 滚动联动：焦点移动到视口边缘时自动滚动容器

5. **初始焦点**：
   - 页面加载完成后，自动聚焦到第一个可交互元素
   ```javascript
   window.addEventListener("load", () => {
     document.querySelector(".card").focus();
   });
   ```

### 常见焦点问题
| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 方向键无反应 | 未监听keydown或焦点在body上 | 确保页面有元素获得焦点，监听document级keydown |
| 焦点丢失 | 动态渲染的元素未设置tabindex | 元素创建后立即设置tabindex |
| 滚动后焦点不可见 | 未联动滚动 | 焦点变化时调用 scrollIntoView() |
| 点击无响应 | 未监听Enter键触发click | Enter键时调用 activeElement.click() |

---

## Web扩展脚本开发
Web扩展脚本是注入到指定CSP站点网页中的JS/CSS代码，用于修改站点页面行为。

### 脚本结构
```javascript
// ==UserScript==
// @name         站点扩展名称
// @match        *://*.example.com/*    // 匹配的站点URL
// @run-at       document-end            // 注入时机
// ==/UserScript==

(function() {
  'use strict';
  
  // 你的注入代码
  // 可以修改DOM、添加样式、劫持事件等
  
  // 示例：隐藏广告元素
  const ads = document.querySelectorAll('.ad, .advertisement');
  ads.forEach(el => el.remove());
  
  // 示例：修改页面样式
  const style = document.createElement('style');
  style.textContent = `
    body { background: #1a1a1a !important; }
    .video-player { width: 100% !important; }
  `;
  document.head.appendChild(style);
  
})();
```

### 开发流程
1. 分析目标站点页面结构（浏览器F12）
2. 编写注入脚本，确定匹配URL规则
3. 在App的Web扩展管理中添加脚本
4. 打开对应站点页面，验证注入效果
5. 调试：使用 `console.log()` 输出，在WebHome调试工作台查看

### 常用注入场景
- 隐藏页面广告、弹窗、推荐位
- 修改页面布局，优化TV端显示
- 自动点击"展开"、"关闭弹窗"等按钮
- 劫持视频播放器事件，调用App原生播放器
- 注入自定义CSS，适配深色模式
