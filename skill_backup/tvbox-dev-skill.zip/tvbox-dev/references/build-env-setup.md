# WebHTV编译环境搭建完整步骤
> 仓库：https://github.com/Silent1566/webhtv
> 环境版本硬性约束，错一个版本直接编译失败

## 目录
1. [环境版本总览](#环境版本总览)
2. [JDK 21 安装配置](#jdk-21-安装配置)
3. [Python 3.10 安装配置](#python-310-安装配置)
4. [Android SDK 安装配置](#android-sdk-安装配置)
5. [NDK 安装配置（r29 / r28c）](#ndk-安装配置r29--r28c)
6. [项目克隆与初始化](#项目克隆与初始化)
7. [编译Debug APK](#编译debug-apk)
8. [Release签名打包](#release签名打包)
9. [GitHub Actions CI自动打包](#github-actions-ci自动打包)
10. [常见编译错误排查](#常见编译错误排查)

---

## 环境版本总览
| 工具 | 强制版本 | 用途 | 错误版本后果 |
|------|----------|------|--------------|
| JDK | 21 | Gradle构建、Kotlin编译 | `Unsupported class file major version` |
| Python | 3.10 | Chaquo Python运行时 | Chaquo构建失败，3.11+不支持 |
| Android SDK Platform | 37 | 编译目标SDK | 编译报错 |
| Android Build-Tools | 37.0.0 | 构建工具 | 编译报错 |
| NDK (MPV) | r29 | MPV/FFmpeg原生库编译 | native编译失败 |
| NDK (IJK) | r28c | IJK播放器原生库编译 | native编译失败 |

> 注意：普通二开（修改Java/Kotlin/前端代码）不需要安装NDK，NDK仅在重新编译原生so库时需要。

---

## JDK 21 安装配置

### Windows
1. 下载 JDK 21：https://adoptium.net/temurin/releases/?version=21
2. 选择 `.msi` 安装包，运行安装
3. 安装时勾选 "Set JAVA_HOME variable" 和 "Add to PATH"
4. 验证：打开cmd，执行 `java -version`，应显示 `openjdk version "21.x.x"`

### macOS
```bash
# 使用Homebrew安装
brew install openjdk@21

# 配置环境变量
echo 'export JAVA_HOME=$(/usr/libexec/java_home -v 21)' >> ~/.zshrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.zshrc
source ~/.zshrc

# 验证
java -version
```

### Linux (Ubuntu/Debian)
```bash
# 使用apt安装
sudo apt update
sudo apt install openjdk-21-jdk

# 配置JAVA_HOME
echo 'export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64' >> ~/.bashrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.bashrc
source ~/.bashrc

# 验证
java -version
```

### 多版本切换
如果机器上有多个JDK版本，确保项目使用JDK21：
- **Android Studio**：File → Project Structure → SDK Location → Gradle JDK → 选择JDK21
- **命令行**：编译前执行 `export JAVA_HOME=/path/to/jdk-21`
- **Gradle配置**：在 `gradle.properties` 中指定（不推荐，应使用环境变量）

---

## Python 3.10 安装配置

### Windows
1. 下载 Python 3.10：https://www.python.org/downloads/release/python-31011/
2. 选择 `Windows installer (64-bit)`，运行安装
3. 安装时勾选 "Add Python 3.10 to PATH"
4. 验证：cmd执行 `python --version`，应显示 `Python 3.10.x`

### macOS
```bash
# 使用Homebrew安装
brew install python@3.10

# 链接到PATH
brew link python@3.10 --force

# 验证
python3.10 --version
```

### Linux (Ubuntu/Debian)
```bash
# Ubuntu 22.04 默认Python3.10，直接安装
sudo apt update
sudo apt install python3.10 python3.10-venv python3-pip

# 验证
python3.10 --version
```

### 验证Chaquo所需
Chaquo需要Python可执行文件在PATH中，且版本为3.10：
```bash
python3.10 --version
# 输出 Python 3.10.x
```

> 注意：不要使用Python 3.11或更高版本，Chaquo不支持，会直接构建失败。
> 如果系统默认Python是3.11+，需要确保 `python3.10` 命令可用，Chaquo会自动查找。

---

## Android SDK 安装配置

### 方式一：Android Studio（推荐）
1. 下载安装 Android Studio：https://developer.android.com/studio
2. 首次启动时，SDK Setup向导会自动下载Android SDK
3. 打开 SDK Manager（Tools → SDK Manager）
4. **SDK Platforms** 标签：勾选 "Android 14 (API 37)" 或对应最新平台
5. **SDK Tools** 标签：勾选：
   - Android SDK Build-Tools 37.0.0
   - Android SDK Command-line Tools (latest)
   - Android SDK Platform-Tools
6. 点击 Apply 安装
7. 记录SDK路径（显示在SDK Manager顶部），后续配置 `local.properties` 需要

### 方式二：命令行安装（无GUI环境）
```bash
# 下载 command-line tools
mkdir -p ~/android-sdk/cmdline-tools
cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip
mv cmdline-tools latest

# 配置环境变量
echo 'export ANDROID_HOME=$HOME/android-sdk' >> ~/.bashrc
echo 'export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH' >> ~/.bashrc
source ~/.bashrc

# 安装SDK组件
sdkmanager --install "platforms;android-37" "build-tools;37.0.0" "platform-tools" "cmdline-tools;latest"

# 接受许可
sdkmanager --licenses
```

### 验证SDK安装
```bash
# 检查平台
ls $ANDROID_HOME/platforms/
# 应看到 android-37 目录

# 检查构建工具
ls $ANDROID_HOME/build-tools/
# 应看到 37.0.0 目录
```

---

## NDK 安装配置（r29 / r28c）
> 仅在需要重新编译MPV/IJK原生so库时安装。普通二开不需要。

### NDK r29（MPV用）
```bash
# 下载NDK r29
wget https://dl.google.com/android/repository/android-ndk-r29-linux.zip
unzip android-ndk-r29-linux.zip -d ~/android-sdk/ndk/

# 配置环境变量（编译MPV时使用）
export NDK_R29=$HOME/android-sdk/ndk/android-ndk-r29
```

### NDK r28c（IJK用）
```bash
# 下载NDK r28c
wget https://dl.google.com/android/repository/android-ndk-r28c-linux.zip
unzip android-ndk-r28c-linux.zip -d ~/android-sdk/ndk/

# 配置环境变量（编译IJK时使用）
export NDK_R28C=$HOME/android-sdk/ndk/android-ndk-r28c
```

### 通过SDK Manager安装
Android Studio SDK Manager → SDK Tools → 勾选 "Show Package Details" → 找到NDK → 选择对应版本安装

---

## 项目克隆与初始化

### 1. 克隆源码
```bash
git clone https://github.com/Silent1566/webhtv
cd webhtv
```

### 2. 创建 local.properties
在项目根目录创建 `local.properties` 文件，指定Android SDK路径：

**Windows**：
```properties
sdk.dir=C:\\Users\\YourName\\AppData\\Local\\Android\\Sdk
```
> 注意：Windows路径中反斜杠需要双写 `\\`，或使用正斜杠 `/`

**macOS / Linux**：
```properties
sdk.dir=/home/yourname/Android/Sdk
```

### 3. 验证环境
```bash
# 检查JDK版本
java -version
# 应显示 21.x.x

# 检查Python版本
python3.10 --version
# 应显示 3.10.x

# 检查local.properties
cat local.properties
# sdk.dir路径应存在且包含 platforms/android-37
```

### 4. Gradle初始化
```bash
# 下载Gradle wrapper依赖（首次运行会自动下载）
./gradlew --version

# Windows使用 gradlew.bat
gradlew.bat --version
```

---

## 编译Debug APK

### 手机版（mobile）
```bash
# arm64-v8a 架构（绝大多数现代手机）
./gradlew :app:assembleMobileArm64_v8aDebug

# 编译成功后，APK路径：
# Release/mobile/arm64-v8a/debug/*.apk
```

### 电视版（leanback）
```bash
# arm64-v8a 架构（现代电视盒子）
./gradlew :app:assembleLeanbackArm64_v8aDebug

# armeabi-v7a 架构（老旧电视盒子）
./gradlew :app:assembleLeanbackArmeabi_v7aDebug
```

### 快速编译（fastRelease）
跳过部分优化，加快编译速度，用于快速测试：
```bash
./gradlew :app:assembleMobileArm64_v8aDebug -PfastRelease=true
```

### 编译产物位置
```
Release/
├── mobile/
│   └── arm64-v8a/
│       └── debug/
│           └── app-mobile-arm64-v8a-debug.apk
└── leanback/
    ├── arm64-v8a/
    │   └── debug/
    └── armeabi-v7a/
        └── debug/
```

### 安装到设备
```bash
# 确保设备已连接（USB调试或adb connect）
adb devices

# 安装APK
adb install -r Release/mobile/arm64-v8a/debug/app-mobile-arm64-v8a-debug.apk
```

---

## Release签名打包

### 1. 生成签名密钥
```bash
keytool -genkeypair -v \
  -keystore my-release-key.jks \
  -alias my-key-alias \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```
按提示输入密钥库密码、别名密码、姓名、组织等信息。

### 2. 配置签名
在项目根目录创建 `keystore.properties` 文件：
```properties
storeFile=my-release-key.jks
storePassword=你的密钥库密码
keyAlias=my-key-alias
keyPassword=你的别名密码
```

> 注意：`keystore.properties` 和 `.jks` 文件包含敏感信息，**不要提交到Git仓库**，确保 `.gitignore` 中已排除。

### 3. 编译Release包
```bash
# 手机arm64 Release
./gradlew :app:assembleMobileArm64_v8aRelease

# 电视arm64 Release
./gradlew :app:assembleLeanbackArm64_v8aRelease
```

### 4. 验证签名
```bash
# 检查APK签名信息
apksigner verify --print-certs Release/mobile/arm64-v8a/release/*.apk
```

---

## GitHub Actions CI自动打包

### 1. 配置Secrets
在GitHub仓库 Settings → Secrets and variables → Actions 中添加：
- `KEYSTORE_BASE64`：keystore文件的base64编码
  ```bash
  # 生成base64
  base64 -i my-release-key.jks -o keystore-base64.txt
  # 复制文件内容到Secrets
  ```
- `KEYSTORE_PASSWORD`：密钥库密码
- `KEY_ALIAS`：密钥别名
- `KEY_PASSWORD`：别名密码

### 2. 工作流文件
在 `.github/workflows/build.yml` 创建工作流（项目可能已自带，检查后使用）：
```yaml
name: Build APK
on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up JDK 21
        uses: actions/setup-java@v4
        with:
          java-version: '21'
          distribution: 'temurin'
      
      - name: Set up Python 3.10
        uses: actions/setup-python@v5
        with:
          python-version: '3.10'
      
      - name: Decode keystore
        run: |
          echo "${{ secrets.KEYSTORE_BASE64 }}" | base64 -d > my-release-key.jks
          echo "storeFile=my-release-key.jks" > keystore.properties
          echo "storePassword=${{ secrets.KEYSTORE_PASSWORD }}" >> keystore.properties
          echo "keyAlias=${{ secrets.KEY_ALIAS }}" >> keystore.properties
          echo "keyPassword=${{ secrets.KEY_PASSWORD }}" >> keystore.properties
      
      - name: Build Release APK
        run: ./gradlew :app:assembleMobileArm64_v8aRelease
      
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-release
          path: Release/mobile/arm64-v8a/release/*.apk
```

---

## 常见编译错误排查

### 1. `Unsupported class file major version`
- **原因**：JDK版本不是21
- **解决**：
  ```bash
  java -version  # 检查当前版本
  # 切换到JDK21
  export JAVA_HOME=/path/to/jdk-21
  export PATH=$JAVA_HOME/bin:$PATH
  ```

### 2. `SDK location not found`
- **原因**：项目根目录缺少 `local.properties` 文件，或 `sdk.dir` 路径错误
- **解决**：
  - 确认 `local.properties` 存在于项目根目录
  - 确认 `sdk.dir` 路径正确，且该目录下有 `platforms/android-37`
  - Windows路径使用双反斜杠 `\\` 或正斜杠 `/`

### 3. Chaquo Python构建失败
- **原因**：Python版本不是3.10，或Python未安装
- **解决**：
  ```bash
  python3.10 --version  # 确认3.10可用
  # 如果没有，安装Python3.10
  # Ubuntu: sudo apt install python3.10
  ```

### 4. `dlopen failed: library "libplayer.so" not found`
- **原因**：原生so库缺失或版本不匹配
- **解决**：
  - 普通编译不需要重新编译so，项目应自带预编译so
  - 如果自行编译过so，确保 `libmpv.so` 和 `libplayer.so` 是同一commit编译的
  - 检查 `app/src/main/jniLibs/arm64-v8a/` 下so库是否完整

### 5. Gradle下载依赖超时
- **原因**：网络问题，Maven仓库访问慢
- **解决**：
  - 配置国内镜像源（在 `settings.gradle` 或 `build.gradle` 中添加阿里云镜像）
  - 使用代理：`./gradlew -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=7890`

### 6. `NDK not configured`
- **原因**：编译native代码时NDK路径未配置
- **解决**：
  - 普通二开不需要NDK，如果报错说明触发了native编译
  - 安装对应版本NDK，在 `local.properties` 中添加 `ndk.dir=/path/to/ndk`
  - 或在 `local.properties` 中添加 `android.ndkVersion=29.0.0`

### 7. Release打包签名失败
- **原因**：keystore配置错误
- **解决**：
  - 确认 `keystore.properties` 文件存在且路径正确
  - 确认 `storeFile` 路径是相对于项目根目录的相对路径或绝对路径
  - 确认密码、别名正确
  - CI环境确认Secrets配置正确，base64编码无换行符问题

### 8. 编译成功但安装失败（INSTALL_FAILED_UPDATE_INCOMPATIBLE）
- **原因**：设备上已安装不同签名的同名应用
- **解决**：
  ```bash
  adb uninstall com.github.tvbox.osc  # 卸载旧版本
  adb install new.apk
  ```
