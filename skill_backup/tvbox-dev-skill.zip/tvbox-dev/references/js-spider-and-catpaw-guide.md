# JS Spider 与 CatPawOpen 综合开发指南

> 融合《爬虫编写手册.md》（CatPawOpen Node.js爬虫框架）与《猫源js脚本开发文档.md》（本地JS Spider规范）
> 适用场景：TVBox/影视仓/OK影视/PickTV 四壳的 JS/QuickJS 爬虫开发、CatPawOpen 服务端爬虫、网盘源接入

---

## 一、CatPawOpen 架构（Node.js 服务端爬虫）

### 1.1 技术栈

| 组件 | 用途 | 版本 |
|------|------|------|
| Node.js | 运行时 | >=18 |
| Fastify | HTTP 服务器/路由 | 4.x |
| Axios | HTTP 请求（自动Cookie管理） | 1.x |
| Cheerio | HTML 解析（jQuery 语法） | 1.x |
| Crypto-JS | 加密解密（AES/DES/MD5/SHA等） | 4.x |

### 1.2 项目结构

```
CatPawOpen/
├── server.js              # 入口，启动Fastify
├── package.json
├── spiders/               # 爬虫源目录
│   ├── kanav.js           # 单个爬虫源
│   └── ...
├── util/
│   ├── req.js             # 封装axios，自动Cookie管理
│   └── ...
└── data/                  # 运行时数据
```

### 1.3 Spider 导出格式（CatPawOpen）

```javascript
module.exports = {
  meta: {
    key: 'kanav',           // 唯一标识，URL路径用
    name: 'KanAV',          // 显示名称
    type: 3,                // 类型：1=视频 3=影视
  },
  api: function(fastify) {  // 注册Fastify路由
    fastify.post('/init', async (request, reply) => { ... });
    fastify.post('/home', async (request, reply) => { ... });
    // ... 6个接口
  }
};
```

---

## 二、6 接口规范（CatPawOpen 与 猫源JS 通用）

| 接口 | 方法 | 入参 | 返回 | 说明 |
|------|------|------|------|------|
| /init | POST | extend（配置JSON字符串） | { class, filters } | 初始化，返回分类和筛选器 |
| /home | POST | 无 | { class, list } | 首页，分类+推荐列表 |
| /category | POST | tid, pg, f, extend | { page, pagecount, limit, total, list } | 分类页 |
| /detail | POST | ids | { list: [ { vod_id, vod_name, vod_pic, vod_play_from, vod_play_url, ... } ] } | 详情页 |
| /play | POST | flag, id, vipFlags | { parse, url, header, format } | 播放地址 |
| /search | POST | wd, quick | { page, pagecount, limit, total, list } | 搜索 |

### 2.1 关键返回格式

**home 返回**：
```json
{
  "class": [{"type_id":"1","type_name":"电影"}],
  "filters": {"1": [{"key":"sort","name":"排序","value":[{"n":"最新","v":"new"}]}]},
  "list": [{"vod_id":"123","vod_name":"片名","vod_pic":"https://...","vod_remarks":"HD"}]
}
```

**detail 返回（关键坑：ids 是 list/tuple，不是单个字符串！）**：
```json
{
  "list": [{
    "vod_id": "123",
    "vod_name": "片名",
    "vod_pic": "https://...",
    "vod_play_from": "线路1$$$线路2",
    "vod_play_url": "第1集$url1#第2集$url2$$$第1集$url3"
  }]
}
```

**play 返回**：
```json
{
  "parse": 0,
  "jx": 0,
  "url": "https://.../index.m3u8",
  "header": {"User-Agent": "...", "Referer": "..."},
  "format": "application/x-mpegURL"
}
```

---

## 三、猫源 JS Spider 规范（本地 QuickJS 加载）

### 3.1 固定导出格式

```javascript
export default function createSpider(name, config) {
  return {
    meta: {
      key: 'mysite',
      name: '我的源',
      type: 3,
    },
    api: function(fastify) {
      // 注册6个标准路由 + 可选路由
    },
    check: async function() {
      // 健康检查，返回 { ok: true, message: '...' }
    }
  };
}
```

### 3.2 依赖白名单（只能导入以下包，其他会被沙箱拦截）

**Node 内置模块**：fs, path, url, querystring, crypto, zlib, buffer, stream, http, https, net, tls, dns, os, util, events, string_decoder, punycode, assert

**9 个裸包名**：
| 包名 | 用途 |
|------|------|
| axios | HTTP 请求 |
| cheerio | HTML 解析 |
| crypto-js | 加密解密 |
| iconv-lite | 编码转换（GBK等） |
| http2 | HTTP/2 请求 |
| jpeg-js | JPEG 编解码 |
| qs | querystring 解析 |
| crypto | Node 内置 crypto（别名） |

**10 个项目内部模块**：
| 模块 | 用途 |
|------|------|
| util/req.js | 封装 axios，自动 Cookie 管理 |
| util/htmlParser.js | HTML 解析封装 |
| util/home-cache.js | 首页短 TTL 缓存 |
| util/pan.js | 网盘解析（夸克/UC/阿里/百度/天翼/115/123/迅雷/磁力） |
| util/concurrency-limiter.js | 并发控制 |
| util/misc.js | 杂项工具 |
| util/lru-cache.js | LRU 缓存 |
| core/runtime-context.js | 运行时上下文 |
| core/config.js | 配置管理 |
| core/logger.js | 日志 |

### 3.3 可选路由

| 路由 | 用途 |
|------|------|
| /homeVod | 首页视频列表（独立于/home的class） |
| /proxy/* | 本地代理（图片/m3u8/嵌套请求） |
| /check | 健康检查 |

---

## 四、网盘源接入（util/pan.js）

### 4.1 支持的网盘

夸克网盘、UC网盘、阿里网盘、百度网盘、天翼云盘、115网盘、123网盘、迅雷网盘、磁力链接

### 4.2 普通网盘源

```javascript
// vod_id 编码：pan_type::pan_id::file_id
// 例：quark::abc123::def456
const pan = require('util/pan.js');

fastify.post('/detail', async (request, reply) => {
  const ids = request.body.ids; // list/tuple
  const list = ids.map(id => {
    const [panType, panId, fileId] = id.split('::');
    return {
      vod_id: id,
      vod_name: pan.getTitle(panType, panId),
      vod_pic: pan.getCover(panType, panId),
      vod_play_from: panType,
      vod_play_url: `在线播放$${fileId}`
    };
  });
  return { list };
});

fastify.post('/play', async (request, reply) => {
  const { flag, id } = request.body;
  const realUrl = await pan.parse(flag, id); // 解析出直链
  return { parse: 0, url: realUrl, header: {}, format: 'application/x-mpegURL' };
});
```

### 4.3 网盘分组源（分层 vod_id 设计）

三层结构：**show（展示层）→ group（分组层）→ resource（资源层）**

```
vod_id 编码：
  show:     pan_group::show_id              （详情页展示，含多个分组）
  group:    pan_group::show_id::group_id    （点击分组后，展示该组所有资源）
  resource: pan_group::show_id::group_id::res_id  （最终播放资源）
```

**detail 接口处理**：
- 收到 show 级 id → 返回 vod_play_from 为多个分组名，vod_play_url 为每个分组的"查看全部"入口
- 收到 group 级 id → 返回该分组下所有资源的播放列表
- 收到 resource 级 id → 直接返回单个资源

**play 接口处理**：
- 解析 resource 级 id，调用 pan.parse() 获取直链

---

## 五、本地 proxy 动态 URL 构建（关键技巧）

**不要硬编码 127.0.0.1:port**，从 `request.server.prefix` 推导：

```javascript
fastify.post('/detail', async (request, reply) => {
  const prefix = request.server.prefix; // 如 /spider/kanav
  const proxyBase = `${prefix}/proxy`;
  
  // 封面代理
  const coverUrl = `${proxyBase}/cover?url=${encodeURIComponent(originalCoverUrl)}`;
  
  // m3u8 代理
  const m3u8Url = `${proxyBase}/m3u8?url=${encodeURIComponent(originalM3u8Url)}`;
  
  return {
    list: [{
      vod_id: '123',
      vod_name: '片名',
      vod_pic: coverUrl,  // 使用代理URL
      vod_play_from: '线路1',
      vod_play_url: `正片$${m3u8Url}`
    }]
  };
});

// 注册 proxy 路由
fastify.get('/proxy/cover', async (request, reply) => {
  const { url } = request.query;
  const resp = await req.get(url, { responseType: 'arraybuffer' });
  reply.header('Content-Type', resp.headers['content-type']);
  return resp.data;
});
```

---

## 六、KanAV 实战案例（player_aaaa 提取 + 双层解码）

### 6.1 站点特征
- 普通 CMS 站，详情页含 `player_aaaa` JSON
- 播放地址经过 Base64 + URL 双层编码
- 分类：电影/电视剧/综艺/动漫

### 6.2 关键代码片段

```javascript
const cheerio = require('cheerio');
const req = require('util/req.js');
const CryptoJS = require('crypto-js');

// detail 接口
fastify.post('/detail', async (request, reply) => {
  const ids = request.body.ids; // list/tuple
  const list = [];
  
  for (const id of ids) {
    const html = await req.get(`https://kanav.example.com/vod/detail/${id}.html`);
    const $ = cheerio.load(html);
    
    // 提取 player_aaaa
    const playerAaaa = $('script').text().match(/player_aaaa\s*=\s*({.*?});/);
    const playerData = JSON.parse(playerAaaa[1]);
    
    // 双层解码：URL decode → Base64 decode
    const urlEncoded = decodeURIComponent(playerData.url);
    const realUrl = Buffer.from(urlEncoded, 'base64').toString('utf-8');
    
    // 提取播放列表
    const playFrom = playerData.play_from || '线路1';
    const playUrl = playerData.play_url || `正片$${realUrl}`;
    
    list.push({
      vod_id: id,
      vod_name: $('h1').text(),
      vod_pic: $('.vod_pic img').attr('src'),
      vod_play_from: playFrom,
      vod_play_url: playUrl
    });
  }
  
  return { list };
});

// play 接口
fastify.post('/play', async (request, reply) => {
  const { flag, id } = request.body;
  // id 已经是解码后的 m3u8 直链
  return {
    parse: 0,
    jx: 0,
    url: id,
    header: { 'User-Agent': req.defaults.headers.common['User-Agent'], 'Referer': 'https://kanav.example.com/' },
    format: 'application/x-mpegURL'
  };
});
```

---

## 七、缓存与并发控制

### 7.1 首页短 TTL 缓存（util/home-cache.js）

```javascript
const homeCache = require('util/home-cache.js');

fastify.post('/home', async (request, reply) => {
  const cached = homeCache.get('home');
  if (cached) return cached;
  
  const data = await fetchHome();
  homeCache.set('home', data, 60); // 60秒TTL
  return data;
});
```

### 7.2 并发控制（util/concurrency-limiter.js）

```javascript
const limiter = require('util/concurrency-limiter.js');

// 限制并发数为5
const limitedFetch = limiter.wrap(fetchUrl, 5);

const results = await Promise.all(urls.map(url => limitedFetch(url)));
```

### 7.3 LRU 缓存（util/lru-cache.js）

```javascript
const LRU = require('util/lru-cache.js');
const cache = new LRU({ max: 100, ttl: 300 }); // 最多100条，5分钟TTL

cache.set('key', value);
const value = cache.get('key');
```

---

## 八、常见问题与技巧

| 问题 | 解决方案 |
|------|---------|
| 详情页 ids 是 list/tuple 不是字符串 | 遍历 ids 数组，逐个请求详情 |
| GBK 编码页面乱码 | 用 iconv-lite 转换：`iconv.decode(buffer, 'gbk')` |
| 图片 CDN 403 | 本地 proxy 代理，带 Referer 和 UA |
| m3u8 嵌套（m3u8 里还有 m3u8） | 本地 proxy 递归解析，重写相对路径 |
| 分类筛选 filters 为空数组 | 必须返回 dict，空 dict 也行 `{}`，不能返回 `[]` |
| play 返回 header 不是 dict | 必须返回 `{}` 或具体 header，不能返回 None |
| QuickJS 无 fetch/Promise | 用 util/req.js（同步封装），不要用原生 fetch |
| 多线路 flag 名重复 | 用 `线路1$$$线路2` 分隔，每个 flag 唯一 |
| 分页 pagecount 计算错误 | `pagecount = ceil(total / limit)`，从实际响应提取 |
| 搜索 quick=1 时只返回1条 | quick=1 是快速搜索，返回第一条匹配；quick=0 返回完整列表 |

---

## 九、与 tvbox-dev Python 爬虫的对应关系

| JS Spider (CatPawOpen/猫源) | Python Spider (tvbox-dev 四壳协议) |
|------------------------------|-------------------------------------|
| meta.key / meta.name | 配置 JSON 的 key / name |
| 6 接口（init/home/category/detail/play/search） | 13 接口（含 getDependence/localProxy/isVideoFormat 等） |
| fastify.post('/init') | init(extend) |
| fastify.post('/home') | homeContent() |
| fastify.post('/category') | categoryContent(tid, pg, filter, extend) |
| fastify.post('/detail') | detailContent(ids) |
| fastify.post('/play') | playerContent(flag, id, vipFlags) |
| fastify.post('/search') | searchContent(wd, quick) |
| /proxy/* 路由 | localProxy(param) |
| util/req.js（自动Cookie） | requests.Session（自动Cookie） |
| cheerio | BeautifulSoup / lxml |
| crypto-js | pycryptodome / hashlib |
| util/pan.js（网盘解析） | 需自行实现网盘解析 |
| util/home-cache.js（短TTL缓存） | 页面短TTL缓存（内存LRU） |
| 依赖白名单（沙箱限制） | 无沙箱限制，可自由 import |
| QuickJS（无fetch/Promise） | CPython（完整标准库） |

**选择建议**：
- 目标宿主是 TVBox/影视仓/OK影视/PickTV（Python 运行时）→ 用 tvbox-dev 的 Python 四壳协议
- 目标宿主是 CatPawOpen / 猫源（Node.js/QuickJS 运行时）→ 用本指南的 JS Spider 规范
- 网盘源优先用 JS Spider（util/pan.js 已封装8种网盘）
- 复杂加密/逆向优先用 Python（库更丰富，调试更方便）

---

*本指南融合 CatPawOpen 爬虫手册与猫源 JS 脚本开发文档，适用于四壳 JS/QuickJS 爬虫开发与网盘源接入。*
