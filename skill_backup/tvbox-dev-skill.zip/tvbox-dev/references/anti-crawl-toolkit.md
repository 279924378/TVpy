# 网页穿透反爬与爬虫工具选型

> 目标站被 Cloudflare/WAF/JS加密/跳转拦截时的策略库，以及爬虫/浏览器自动化工具选型。

## 网页穿透十一策（按成本从低到高尝试）

1. **UA轮换**：真实浏览器UA池，移动端/PC端分开
2. **伪造请求头**：Referer、Origin、Accept、Accept-Language、Sec-Fetch-* 系列补齐
3. **SSL跳过**：`verify=False`，必要时定制 TLS 指纹
4. **cookie/session 维持**：先访问首页拿Set-Cookie再请求数据接口
5. **cloudscraper**：`cloudscraper.create_scraper()` 过基础Cloudflare JS挑战
6. **curl_cffi 指纹模拟**：`impersonate="chrome131"` 复刻TLS/JA3指纹
7. **JS渲染**：playwright / camoufox 跑真实浏览器
8. **FlareSolverr 网关**：起本地FlareSolverr，POST目标URL返回渲染后HTML
9. **备用域名回退**：同内容多域名，成功域名记忆缓存（`_preferred_origin`）
10. **代理IP轮换**：HTTP/HTTPS/SOCKS5，配合总时长预算 `total_budget` 控制
11. **APP/小程序接口逆向**：网页被封时改抓APP的API（通常更宽松）

## 防跳转八法

1. 禁止 `allow_redirects`，手动逐跳判断
2. 校验每跳 Location 是否仍在目标域，跳出即丢弃
3. meta refresh / JS location 跳转用正则提取真实地址
4. 移除页面中的跳转JS片段后再解析
5. cookie 写入后重放原URL
6. 移动端/PC端UA切换对比跳转差异
7. 直接请求数据API绕过落地页
8. 短链/加密跳转先解码（base64/hex/URL编码多层剥）

## 智能解密七步（json_data/播放地址加密时按序尝试）

1. **AES**：找Key/IV（前端JS硬编码、localStorage、固定字符串），CBC/ECB，PKCS7
2. **DES/3DES**：8字节Key，同上思路
3. **RC4**：Key即密码，流加密
4. **RSA**：公钥加密的请求参数，找JS里的公钥；响应一般不用RSA
5. **Base64/Base64URL**：注意去 `=` 填充、URL安全字符表
6. **混淆/eval解包**：`eval(p,a,c,k,e,d)` 本地解包；字符串数组轮转混淆需还原映射
7. **WASM**：定位导出函数，用 wasmtime/pywasm 本地调用或抠出算法用Python重写

> 定位密钥技巧：搜JS关键词 `key`/`iv`/`CryptoJS`/`encrypt`/`decrypt`/`0x`十六进制串；用playwright在页面上下文直接调用站点自带的加解密函数。

## Cloudflare 专项绕过（MissAV类）

### X25519 TLS 指纹适配
`CloudflareTLSAdapter` 改写 `supported_groups`（含X25519）+ `ALPN` + `OP_NO_COMPRESSION`。

### curl_cffi 指纹轮换优先级
`safari17_2_ios` → `chrome131` → `chrome124` → `chrome`

### 请求头规范
- 必带 `Upgrade-Insecure-Requests: 1` + `Sec-Fetch-Mode: navigate`
- `Accept-Encoding` **不得声明 `br`**（宿主环境可能缺brotli）

### 网关回退链
直连 → curl_cffi → cloudscraper → FlareSolverr `/v1` → 普通代理网关 → 备用域名。
成功后短TTL缓存（页面缓存+init预热），封面403时走本地代理 `local://cover/<b64slug>`。

## 爬虫工具选型

### AI-Native 四件套（需要LLM理解/非结构化页面）
| 工具 | 适用 |
|------|------|
| crawl4ai | 整站转Markdown/JSON喂RAG，BM25去噪，浏览器池 |
| firecrawl | 搜索/抓取/交互API，Map发现URL，MCP集成 |
| scrapegraph-ai | 提示词驱动提取管道（SmartScraper/Search） |
| browser-use | AI控制浏览器点击/输入/过验证码 |

### 生产级框架（结构化大规模采集）
| 工具 | 语言 | 特点 |
|------|------|------|
| scrapy | Python | 中间件/管道/分布式/异步，TVBox外的主力 |
| crawlee | JS/Py | HTTP+浏览器混合，内置指纹代理轮换 |
| colly | Go | 高性能 >1k req/s，自动cookie |
| webmagic | Java | 注解驱动，多线程分布式 |

### 浏览器自动化与反检测
| 工具 | 特点 |
|------|------|
| playwright | 跨浏览器，MCP server，优先选用 |
| puppeteer | CDP协议控制Chrome |
| Scrapling | 自适应DOM变化，过Turnstile |
| camoufox | Firefox反检测，C++层指纹注入，强反爬站点用 |

### 大规模/安全侦察
katana（Go侦察爬虫，标准/Headless双模式）、nutch（Hadoop分布式）、heritrix3（WARC归档级）。

## 汉堡菜单/响应式适配
移动端站点导航折叠在 `navbar-toggler` 按钮里：playwright点击展开 → 提取导航链接 → 再逐栏目采集，避免漏掉只在展开态出现的分类。

## 输出脱敏约定
产出文档/报告中对敏感词做脱敏（如成人内容相关词汇替换为中性表述），密钥标注风险等级，所有外部请求目标限定在用户授权样本范围内。
