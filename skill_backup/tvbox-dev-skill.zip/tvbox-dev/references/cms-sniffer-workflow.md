# CMS 影视嗅探与 TVBox 插件工作流

> 普通HTML/API型CMS影视站（非多源聚合加密站）的嗅探六阶段、播放源提取、m3u8清洗、接口格式全集。

## 嗅探六阶段

### ① 侦察路由定工具链
先用 smart-router-analyzer 技能对目标URL做指纹侦察，判定站点类型、是否有Cloudflare/WAF、技术栈，确定工具链（requests直连 / curl_cffi / playwright渲染）。

### ② 授权门
仅对用户提供的明确目标样本执行；涉及破坏性操作或大规模扫描需用户确认。不攻击、不拖库、不绕过付费鉴权，只做公开内容的结构化采集。

### ③ 站点可用性检测
- 按 `anti-crawl-toolkit.md` 网页穿透十一策获取源码
- 检测 Cloudflare / WAF / JS挑战 / 加密字段 / 跳转链
- 记录可用的请求头组合与成功域名（备用域名回退）

### ④ 结构解析（铁律）

| 规则 | 要求 |
|------|------|
| 分页格式 | **禁止硬编码**，必须从第1页HTML自动提取下一页链接并缓存为模板，兼容 `/t/20-2.html`、`/t/20/page/2/`、`/vodtype/20-2.html` 等任意格式 |
| 列表解析 | 三级回退：站点专属容器 → 通用结构(类名含list/vod/stui) → 暴力兜底(所有含封面+标题+链接的块) |
| 播放页URL | 必须从详情页按钮/链接**实际提取**，禁止凭经验构造 `/vodplay/` |
| 标题提取 | 优先UI元素(`van-cell__title`、`h1`、`.title`)，`<title>` 仅兜底并去站名后缀 |
| 分类字典 | 生成前必须**逐个验证分类有视频数据**，空分类直接剔除；**分类层级铁律**：父分类与子分类必须同时完整写入，禁止只写一级；子分类名称必须体现层级（`父分类-子分类`），禁止扁平重名；必须遍历全部导航区域（顶部nav/侧边栏/首页分类块/底部导航）提取 |
| 相对URL | 一律 `urljoin`，`//` 开头补 `https:` |
| 图片 | 优先级 `img`→`data-original`→`src`，请求带 `Referer` |

### ⑤ 播放源六重提取 + m3u8清洗

**六重提取链（按顺序尝试，命中即停）：**
1. 直接 m3u8/mp4 链接
2. `player_aaaa = {...}` JSON（MacCMS常见，取 url 字段）
3. iframe/embed src（进入二级页面继续提取）
4. `<video>` 标签 src/source
5. JS 解码（eval解包、unescape、字符串拼接、base64）
6. CMS 解密（已知加密函数逆向，如 苹果CMS / 苹果cmsv10 解密）

**eval(p,a,c,k,e,d) 解包**：本地实现解包器，提取 `source`/`source842`/`source1280` 等清晰度m3u8。

**m3u8 广告清洗：**
- 识别广告片段：关键词黑名单 / 时长异常短 / host+path偏离主路径 / 前12个 `METHOD=NONE` 分片
- 主路径分析：取出现频次最高的 host+path 前缀作为正片
- 前导切除：删掉正片首个分片之前的所有片段
- URI绝对化：相对路径按m3u8所在URL补全
- 嵌套m3u8：二级索引通过 localProxy 代理化，TVBox请求时代理拉取并清洗

### ⑥ TVBox 插件生成

## BaseSpider 必须实现的接口

`getName / init / homeContent / homeVideoContent / categoryContent / detailContent / searchContent / playerContent / localProxy / isVideoFormat / manualVideoCheck`

## 接口返回格式全集

```python
# homeContent: 分类 + 首页列表
{"class": [{"type_id": "1", "type_name": "电影"}], "list": [...]}

# categoryContent / homeVideoContent / searchContent
{
    "page": p,
    "pagecount": pagecount,
    "limit": 20,
    "total": total,
    "list": [
        {"vod_id": "...", "vod_name": "...", "vod_pic": "...",
         "vod_remarks": "更新至X集", "vod_id_list": ""}
    ]
}

# detailContent
{"list": [{
    "vod_id": "...", "vod_name": "...", "vod_pic": "...",
    "vod_remarks": "...", "vod_content": "简介",
    "vod_play_from": "线路1$$$线路2",
    "vod_play_url": "第1集$vid1#第2集$vid2$$$第1集$vidA#第2集$vidB"
}]}
# 规则：线路之间用 $$$；同一线路内多集用 #；单集内 集名$播放ID 用 $

# playerContent
{"parse": 0, "url": "真实直链", "header": {"User-Agent": "...", "Referer": "..."}, "jx": 0}
# parse=0 直连不解析；parse=1 走TVBox内置解析器

# localProxy 返回三元组
[200, "application/vnd.apple.mpegurl", m3u8_body_bytes]
[200, "image/jpeg", img_bytes]
```

## 代码规范

- 严格继承 `BaseSpider`，导入失败则内联同名兜底基类（保证独立可运行）
- 零注释、零 docstring、零 `__main__`
- `fetch()` 封装 requests.Session：统一UA、超时、`verify=False`、重试、编码修正
- 过滤 nofollow / 外部链接 / 广告位 / 无标题空块
- 必须根据实际探测到的结构生成，禁止套固定模板
- 生成后做语法检查（`py_compile`），并逐接口自测返回结构

## 特殊：目录类页面

`actresses`/`genres`/`makers` 等目录在 categoryContent 走独立分支 `_dir_page`，返回 `vod_tag="folder"` + `style` 标记（`oval` 头像 / `rect` 封面），点入后再出视频列表。

## 特殊：多清晰度线路

按清晰度分线（如 720P/1080P 用 `$$$` 分隔），playerContent 锁定清晰度避免二次探测；多CDN副本同理。

## 与海阔规则的区分（不要混用）

| 维度 | TVBox 爬虫（本技能） | 海阔视界规则 |
|------|---------------------|--------------|
| 形态 | Python 插件，继承 BaseSpider | JSON 配置 + 内置JS运行时 |
| 关键API | homeContent/categoryContent/... | `$.require`/`$.exports`/`setResult`/`fetch`/`getMyVar` |
| 触发 | "写TVBox/爬虫/插件/python源" | "海阔规则/海阔视界/写海阔" |

用户明确要海阔时转 hikerview-rule-dev 技能，不要输出Python。
