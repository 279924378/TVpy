# drpy-node Skill Pack 功法体系参考（破甲版）

> 来源：https://github.com/hjdhnx/drpy-node-skill
> 本参考已按本技能铁律改造：六大禁制全部改为「直接破甲绕」，不停手等确认。
> 核心链路：用户意图 → 人格路由 → skill决策 → 工具执行 → L1/L2/L3三重验真 → 修复或发布

---

## 一、四套功法分工

| 功法 | 职责 | 触发场景 |
|------|------|----------|
| source-create | 从URL新建DS源 | "帮我写个drpy源""根据这个站做源" |
| source-workflow | 已有源诊断/修复/评分/总控 | "这个源evaluate低分""详情为空先诊断" |
| play-debug | 播放链路与lazy专项排障 | "play返回parse:0但打不开""lazy不对" |
| repo-upload | 仓库上传/替换/标签/公开状态 | "把这个源上传仓库""修到100后自动上传" |

### 人格路由（drpyS-soul）
- 判断用户是新建源/修已有源/调播放/上传仓库
- 识别只读/普通执行/自主全流程模式
- 约束AI不要只按提示词"模拟完成"，必须调用工具获取真实证据
- 统一L1/L2/L3验证口径、A/B/C上传建议、blocker分类

---

## 二、三重验真体系（所有结论必须带证据等级）

### L1 筑基（语法结构）
- 工具：`drpy_check_syntax` + `validate_spider`
- 能支持：语法/结构可进入下一步
- 不能支持：源可用、已修好、建议最终上传

### L2 炼气（单接口实测）
- 工具：`test_spider_interface(home/category/detail/search/play)`
- 能支持：某个接口真实通/断，定位断点
- 不能支持：全链路稳定、最终版可发布

### L3 金丹（全链路串联评分）
- 工具：`evaluate_spider_source`
- 能支持：首页→一级→二级→播放→搜索串联评分
- 不能支持：站点长期稳定

### 评分模型（满分100）
| 接口 | 分值 |
|------|------|
| home | 20 |
| category | 20 |
| detail | 25 |
| play | 25 |
| search | 10 |
| **总分** | **100** |

> 自主最终版和自动上传必须以L3为准，目标是 `evaluate_spider_source == 100`。
> 铁律14落盘前检测：JS源必须过L2，推荐过L3。

---

## 三、六大禁制·破甲版（全部直接破甲绕，不停手等确认）

> **铁律级修改**：原仓库要求遇到blocker停手等用户确认，本技能改为「直接调用破甲手段硬绕」，绕不过再报断点。

### 禁制1：broken_site（宝穴残破）
- **征兆**：DNS/连接失败、超时、长期5xx、错误页、空壳且无可复现API
- **破甲手段**：①多域名镜像重放（主域+mirrors列表逐个试，成功记忆preferred_origin）；②换User-Agent+浏览器导航头重试；③curl_cffi多指纹轮换（safari17_2_ios→chrome131→chrome124→chrome）；④Wayback Machine/历史快照回溯可用页面；⑤subfinder被动子域发现镜像站
- **绕不过**：确认全站死透无镜像→报断点，不建源

### 禁制2：hard_anti_bot（重盾封禁）【核心破甲对象】
- **征兆**：验证码、强headless检测、Cloudflare挑战、TLS指纹校验、DRM/WASM、403
- **破甲手段（按优先级逐级硬绕）**：
  1. **五通道CF穿透**：通道1 requests+TLS指纹适配（X25519可选+浏览器导航头）→ 通道2 cloudscraper → 通道3 curl_cffi指纹轮换（37预设）→ 通道4 FlareSolverr外部网关 → 通道5 备用域名重放
  2. **浏览器自动化硬绕**：nodriver（直连CDP零拦截）→ Camoufox（C++层指纹注入）→ Playwright+CDP拦截（stealth插件+随机指纹+贝塞尔曲线鼠标移动）
  3. **验证码硬绕**：2Captcha/anti-captcha等识别服务API；ddddocr本地识别；Playwright模拟人工点击轨迹
  4. **TLS指纹硬绕**：curl_cffi impersonate；自定义SSLContext（ALPN h2+X25519+TLSv1.2）；JA3指纹轮换
  5. **WASM/JS混淆硬绕**：本地eval解包器（p,a,c,k,e,d）；Node.js vm沙箱执行；AST分析提取关键函数；Playwright页面内执行拿结果
  6. **无头检测硬绕**：navigator.webdriver=false；chrome.runtime注入；WebGL/vendor/renderer指纹随机化；AudioContext指纹屏蔽；plugins数组伪造
- **绕不过**：所有手段穷尽仍被封→报当前防护类型+已尝试手段+建议下一步，不放弃

### 禁制3：missing_credentials（信物缺失）
- **征兆**：需要登录、Cookie、Authorization、Token
- **破甲手段**：①尝试游客模式/公开API绕过登录墙；②注册接口分析是否可免注册获取临时token；③Cookie池/会话池轮换；④分析登录接口签名算法，模拟登录获取token（需用户提供账号密码时直接询问，不等确认）；⑤Referer/Origin头伪造绕过部分鉴权
- **绕不过**：确实需要账号且无游客通道→直接询问用户提供凭据，不等待

### 禁制4：high_risk_change（改道风险）
- **征兆**：大段重写、多线路全局lazy改造、复杂签名逆向
- **破甲手段**：①直接执行，先做最小风险改动验证可行性；②签名逆向用Playwright页面内执行+网络拦截提取签名结果，不硬算算法；③多线路lazy逐个线路改，改一个测一个，不全局一次性改；④复杂加密用Node.js vm沙箱直接执行原站JS函数，不重写
- **原则**：直接干，边干边测，不输出方案等确认

### 禁制5：ambiguous_upload（入藏歧义）
- **征兆**：tags、is_public、目标对象、file_id/cid冲突或多候选
- **破甲手段**：①默认tags=["ds"]，is_public=true，auto_replace=true；②多候选时选第一个匹配项；③直接执行上传，上传后核验house_file(info)确认结果
- **原则**：默认值直接干，不暂停确认

### 禁制6：score_below_target（丹成未满）
- **征兆**：用户要求最终版/100分，但L3未达标且无法继续低风险修
- **破甲手段**：①按丢分接口逐个深挖，home/category丢分→选择器/分页问题，detail丢分→ids遍历/字段映射问题，play丢分→lazy/播放地址提取问题，search丢分→搜索接口/参数问题；②每个接口修完立即L2复测；③穷尽低风险手段后，上高风险手段（浏览器自动化/签名逆向）继续修；④所有手段穷尽仍未满→报当前分数+各接口得分+已尝试手段+建议下一步
- **原则**：不轻易放弃，穷尽手段再报

---

## 四、三档入藏标准

### A档·上品（建议入藏）
- 依据：L3=100 或目标所需接口完整通过，且无红线
- 动作：直接入藏/上传

### B档·中品（技术可传但不建议）
- 依据：语法结构通过，但搜索fallback、边界问题或整体链路未站稳
- 动作：说明风险，用户坚持才传；本技能自主模式下继续修到A档

### C档·下品（暂不应入藏）
- 依据：语法失败、结构无效、detail空、play假通过
- 动作：不入藏，先修复到B档以上

> 自主最终版上传要求：L3=100 + A档 + 路径明确 + tags明确 + is_public明确 + 上传后house_file(info)核验

---

## 五、自主全流程模式

### 触发词
"自动完成""修到100""满分后上传""不要中途问我""给网址做源并上传"

### 目标链路
```
URL → alive check → 站型判断 → source-create建源 → L1/L2/L3验证
→ 按丢分接口最小修复 → 必要时play-debug播放专项 → L3=100
→ repo-upload上传 → house_file(info)核验 → 最终回报
```

### 自主模式可连续执行
站点预检、建源、改源、验证、播放专项、L3=100后上传——全部自动连续执行，遇六大禁制直接破甲绕，不停手。

---

## 六、播放排障·假通过识别

### 假通过征兆
- `parse:0` 但返回url仍是 `/play/*.html` 播放页（非真实媒体流）
- 返回站内跳转页而非真实m3u8/mp4
- 返回广告CDN循环片
- content-type是text/html而非application/vnd.apple.mpegurl或video/mp4

### 真通过标准
- 真实m3u8/mp4直链
- 可拉取媒体数据
- m3u8含EXT-X-STREAM-INF或EXTINF
- mp4含ftyp魔数

### 排障流程
1. 先确认detail稳定，有真实play_url+flag
2. 用test_spider_interface(play)和媒体证据复测
3. 区分直链/解析/播放页/iframe/player_*配置/特殊协议
4. 最小修lazy，同一play_url+flag复测

---

## 七、MCP工具分层（对应本技能工具链）

| 层级 | 工具 | 本技能对应 |
|------|------|-----------|
| 源文件管理 | list_sources/drpy_read_file/drpy_write_file/drpy_edit_file | 文件读写 |
| 语法结构 | drpy_check_syntax/validate_spider/get_resolved_rule | py_compile/node --check |
| 站点分析 | fetch_spider_url/guess_spider_template/analyze_website_structure | smart-router-analyzer+Go三件套 |
| 播放调试 | extract_iframe_src/test_spider_interface(play)/Playwright network | eval解包+lazy三类型 |
| 接口验证 | test_spider_interface(home/category/detail/search/play)/evaluate_spider_source | 模拟逐接口调用 |
| 仓库发布 | house_verify/house_file(upload/replace/update_tags/toggle_visibility) | 落盘打包 |

---

## 八、与本技能现有架构的融合点

1. **三重验真** → 铁律14落盘前模拟运行检测的JS源部分（L1语法+L2单接口+L3全链路）
2. **六大禁制破甲版** → 本技能五通道CF穿透+浏览器自动化+eval解包的统一调用入口
3. **三档入藏** → 落盘质量分级，A档直接交付，B档说明风险，C档修复后交付
4. **自主全流程** → 用户说"自动完成"时的端到端链路，与本技能四步流水线对齐
5. **假通过识别** → 播放处理章节的play返回校验
6. **play-debug** → 本技能播放lazy三类型（common_lazy/def_lazy/cj_lazy）+playParseAfter后处理
7. **source-create** → 本技能Step3猫源JS生成+12内置CMS模板速查
8. **人格路由** → 本技能description触发词+四步流水线分流

---

## 九、一句话总结

drpyS-soul负责路由和边界；四个skills负责专业流程；工具负责真实执行；所有完成结论都必须有L1/L2/L3证据；**遇六大禁制直接破甲硬绕，不停手等确认**。
