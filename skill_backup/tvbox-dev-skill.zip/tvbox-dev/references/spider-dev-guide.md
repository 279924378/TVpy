# TVBox Spider爬虫开发指南
> WebHTV兼容三套爬虫体系：Java Jar、QuickJS JS、Chaquo Python
> 本文档详细讲解每套爬虫的开发方法、接口规范、实战示例

## 目录
1. [爬虫体系总览](#爬虫体系总览)
2. [核心接口规范（四核心方法）](#核心接口规范四核心方法)
3. [Java Jar爬虫开发](#java-jar爬虫开发)
4. [QuickJS JS爬虫开发](#quickjs-js爬虫开发)
5. [Chaquo Python爬虫开发](#chaquo-python爬虫开发)
6. [CSP XPath零代码配置](#csp-xpath零代码配置)
7. [播放地址处理技巧](#播放地址处理技巧)
8. [站点JSON配置规范](#站点json配置规范)
9. [调试与测试方法](#调试与测试方法)
10. [常见问题排查](#常见问题排查)

---

## 爬虫体系总览

| 方案 | 运行时 | 开发语言 | 编译需求 | 适用场景 | 难度 |
|------|--------|----------|----------|----------|------|
| Java Jar | JVM | Java | 需要编译Jar | 复杂站点、性能要求高 | 高 |
| QuickJS JS | QuickJS | JavaScript | 无需编译，热加载 | 快速开发、简单站点 | 中 |
| Chaquo Python | Chaquo | Python | 无需编译 | Python生态、复杂解析 | 中 |
| CSP XPath | 内置 | JSON配置 | 零代码 | 结构简单的CMS站 | 低 |

### 如何选择
- **结构简单的CMS站**：优先CSP XPath，零代码快速配置
- **需要简单逻辑处理**：QuickJS JS，开发快、调试方便
- **复杂加密、需要Python库**：Chaquo Python
- **性能要求极高、超复杂站点**：Java Jar（传统方案）

---

## 核心接口规范（四核心方法）
所有爬虫方案都必须实现以下四个核心方法，返回结构一致。

### 1. homeContent（首页）
**作用**：返回首页分类列表 + 首页推荐视频
**返回结构**：
```json
{
  "class": [
    {"type_id": "1", "type_name": "电影"},
    {"type_id": "2", "type_name": "电视剧"}
  ],
  "list": [
    {
      "vod_id": "12345",
      "vod_name": "视频标题",
      "vod_pic": "https://.../cover.jpg",
      "vod_remarks": "更新至第10集"
    }
  ]
}
```

### 2. categoryContent（分类页）
**作用**：按分类、分页返回视频列表
**参数**：`tid`（分类ID）、`pg`（页码）、`filter`（筛选参数，可选）
**返回结构**：
```json
{
  "page": 1,
  "pagecount": 10,
  "limit": 20,
  "total": 200,
  "list": [
    {
      "vod_id": "12345",
      "vod_name": "视频标题",
      "vod_pic": "https://.../cover.jpg",
      "vod_remarks": "HD"
    }
  ]
}
```

### 3. detailContent（详情页）
**作用**：返回视频详情 + 播放线路
**参数**：`ids`（视频ID，可能是逗号分隔的多个）
**返回结构**：
```json
{
  "list": [
    {
      "vod_id": "12345",
      "vod_name": "视频标题",
      "vod_pic": "https://.../cover.jpg",
      "vod_year": "2024",
      "vod_area": "中国大陆",
      "vod_actor": "演员1,演员2",
      "vod_director": "导演",
      "vod_content": "剧情简介...",
      "vod_play_from": "线路1$$$线路2",
      "vod_play_url": "第1集$https://.../ep1.m3u8#第2集$https://.../ep2.m3u8$$$第1集$https://.../ep1-b.m3u8"
    }
  ]
}
```
> 多线路用 `$$$` 分隔线路名和播放地址；每集用 `#` 分隔；集名和地址用 `$` 分隔。

### 4. searchContent（搜索）
**作用**：按关键词搜索返回视频列表
**参数**：`key`（搜索关键词）、`pg`（页码）
**返回结构**：同 categoryContent
```json
{
  "page": 1,
  "pagecount": 1,
  "limit": 20,
  "total": 5,
  "list": [...]
}
```

### 5. playerContent（播放解析，可选）
**作用**：如果播放地址需要二次解析（如加密、需要获取真实直链），实现此方法
**参数**：`flag`（线路名）、`id`（播放地址）、`vipFlags`（VIP线路标识）
**返回结构**：
```json
{
  "parse": 0,
  "jx": 0,
  "url": "https://.../real.m3u8",
  "header": {"User-Agent": "...", "Referer": "..."},
  "format": "application/x-mpegURL"
}
```
> `parse=0` 表示直接播放url；`parse=1` 表示需要进一步解析（走解析接口）。

---

## Java Jar爬虫开发

### 开发环境
- JDK 21
- Android Studio 或 IntelliJ IDEA
- TVBox Spider SDK（从项目 `catvod/` 模块获取）

### 基本结构
```java
package com.example.spider;

import com.github.catvod.crawler.Spider;
import com.github.catvod.crawler.SpiderDebug;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

public class SpiderDemo extends Spider {

    // 初始化，ext为站点配置中的ext参数
    @Override
    public void init(String ext) {
        // 解析ext配置，初始化站点地址等
    }

    // 首页
    @Override
    public String homeContent(boolean filter) {
        JSONObject result = new JSONObject();
        // 分类
        JSONArray classes = new JSONArray();
        classes.put(new JSONObject().put("type_id", "1").put("type_name", "电影"));
        result.put("class", classes);
        // 首页推荐列表
        JSONArray list = new JSONArray();
        // ... 解析首页视频
        result.put("list", list);
        return result.toString();
    }

    // 分类页
    @Override
    public String categoryContent(String tid, String pg, boolean filter, HashMap<String, String> extend) {
        JSONObject result = new JSONObject();
        result.put("page", Integer.parseInt(pg));
        result.put("pagecount", 10);
        result.put("limit", 20);
        result.put("total", 200);
        JSONArray list = new JSONArray();
        // ... 请求分类接口，解析列表
        result.put("list", list);
        return result.toString();
    }

    // 详情页
    @Override
    public String detailContent(List<String> ids) {
        JSONObject result = new JSONObject();
        JSONArray list = new JSONArray();
        for (String id : ids) {
            JSONObject vod = new JSONObject();
            vod.put("vod_id", id);
            vod.put("vod_name", "标题");
            vod.put("vod_pic", "https://.../cover.jpg");
            vod.put("vod_play_from", "线路1");
            vod.put("vod_play_url", "第1集$https://.../ep1.m3u8");
            list.put(vod);
        }
        result.put("list", list);
        return result.toString();
    }

    // 搜索
    @Override
    public String searchContent(String key, boolean quick) {
        return searchContent(key, "1", quick);
    }

    @Override
    public String searchContent(String key, String pg, boolean quick) {
        JSONObject result = new JSONObject();
        result.put("page", Integer.parseInt(pg));
        result.put("pagecount", 1);
        result.put("limit", 20);
        result.put("total", 0);
        JSONArray list = new JSONArray();
        // ... 搜索请求，解析结果
        result.put("list", list);
        return result.toString();
    }

    // 播放解析（可选）
    @Override
    public String playerContent(String flag, String id, List<String> vipFlags) {
        JSONObject result = new JSONObject();
        result.put("parse", 0);
        result.put("jx", 0);
        result.put("url", id);
        result.put("header", new JSONObject().put("User-Agent", "Mozilla/5.0"));
        return result.toString();
    }
}
```

### 编译打包
1. 编写Spider类，继承 `com.github.catvod.crawler.Spider`
2. 编译为Jar包（包含依赖或纯类文件）
3. 将Jar上传到可访问的URL（或本地路径）
4. 在站点JSON中配置：
```json
{
  "key": "demo",
  "name": "演示站点",
  "type": 3,
  "api": "jar",
  "ext": "https://example.com/spider-demo.jar;com.example.spider.SpiderDemo",
  "click": "123456"  // MD5校验（可选）
}
```

### 网络请求
使用项目封装的HttpUtil：
```java
import com.github.catvod.net.OkHttp;

// GET请求
String html = OkHttp.newCall("https://example.com/list?page=1").getBody().string();

// POST请求
Map<String, String> headers = new HashMap<>();
headers.put("Content-Type", "application/json");
String response = OkHttp.post("https://example.com/api", "{\"key\":\"value\"}", headers);
```

---

## QuickJS JS爬虫开发

### 特点
- 纯JavaScript编写，无需编译
- 运行在App内置QuickJS引擎中
- 热加载，修改脚本后立即生效，调试方便
- 适合快速开发和简单站点

### 基本结构
```javascript
// 规则：JS爬虫脚本
// 站点JSON配置中 api: "csp_JS脚本名" 或直接内联

var baseUrl = "https://example.com";

// 首页
function home() {
  var html = request(baseUrl + "/");
  var classes = [];
  // 解析分类
  // ...
  var list = [];
  // 解析首页推荐
  // ...
  return JSON.stringify({
    class: classes,
    list: list
  });
}

// 分类页
function category(tid, pg, filter, extend) {
  var url = baseUrl + "/list/" + tid + "-" + pg + ".html";
  var html = request(url);
  var list = [];
  // 解析视频列表
  // ...
  return JSON.stringify({
    page: parseInt(pg),
    pagecount: 10,
    limit: 20,
    total: 200,
    list: list
  });
}

// 详情页
function detail(ids) {
  var id = ids.split(",")[0];
  var url = baseUrl + "/detail/" + id + ".html";
  var html = request(url);
  var vod = {
    vod_id: id,
    vod_name: "标题",
    vod_pic: "https://.../cover.jpg",
    vod_play_from: "线路1",
    vod_play_url: "第1集$https://.../ep1.m3u8"
  };
  return JSON.stringify({ list: [vod] });
}

// 搜索
function search(key, quick, pg) {
  pg = pg || "1";
  var url = baseUrl + "/search?wd=" + encodeURIComponent(key) + "&page=" + pg;
  var html = request(url);
  var list = [];
  // 解析搜索结果
  // ...
  return JSON.stringify({
    page: parseInt(pg),
    pagecount: 1,
    limit: 20,
    total: list.length,
    list: list
  });
}

// 播放解析（可选）
function play(flag, id, vipFlags) {
  return JSON.stringify({
    parse: 0,
    jx: 0,
    url: id,
    header: { "User-Agent": "Mozilla/5.0" }
  });
}

// 网络请求封装
function request(url, options) {
  options = options || {};
  // 使用JS爬虫内置的请求方法
  // 具体API名以项目文档为准，常见为 req() 或 fetch()
  return req(url, options);
}
```

### 站点配置
```json
{
  "key": "jsdemo",
  "name": "JS演示站点",
  "type": 3,
  "api": "csp_jsdemo",
  "ext": "https://example.com/spider.js"
}
```
> JS脚本通过ext加载，`api` 字段的 `csp_` 前缀标识使用CSP框架，具体配置方式以项目文档为准。

### QuickJS注意事项
- QuickJS是精简JS引擎，**不支持**浏览器DOM API（document、window等）
- **不支持** `XMLHttpRequest`、`fetch` 等浏览器API，需使用爬虫框架提供的请求方法
- **不支持** `console.log`，调试用框架提供的日志方法（如 `log()`）
- 字符串处理、JSON、正则表达式等标准ES6特性支持
- 不支持 `async/await`，网络请求是同步的

---

## Chaquo Python爬虫开发

### 特点
- Python编写，App内嵌Python运行时
- 可使用Python标准库（部分受限）
- 适合复杂解析、需要Python生态的场景
- 无需编译，脚本热加载

### 基本结构
```python
# -*- coding: utf-8 -*-
import json
import re
from urllib.parse import urljoin

# 爬虫框架提供的请求方法（具体导入以项目为准）
# from spider import req

BASE_URL = "https://example.com"

def homeContent(filter=False):
    """首页"""
    html = req(f"{BASE_URL}/")
    classes = []
    # 解析分类
    # classes.append({"type_id": "1", "type_name": "电影"})
    videos = []
    # 解析首页推荐
    return json.dumps({"class": classes, "list": videos}, ensure_ascii=False)

def categoryContent(tid, pg, filter=False, extend=None):
    """分类页"""
    url = f"{BASE_URL}/list/{tid}-{pg}.html"
    html = req(url)
    videos = []
    # 解析视频列表
    return json.dumps({
        "page": int(pg),
        "pagecount": 10,
        "limit": 20,
        "total": 200,
        "list": videos
    }, ensure_ascii=False)

def detailContent(ids):
    """详情页"""
    vid = ids.split(",")[0]
    url = f"{BASE_URL}/detail/{vid}.html"
    html = req(url)
    vod = {
        "vod_id": vid,
        "vod_name": "标题",
        "vod_pic": "https://.../cover.jpg",
        "vod_play_from": "线路1",
        "vod_play_url": "第1集$https://.../ep1.m3u8"
    }
    return json.dumps({"list": [vod]}, ensure_ascii=False)

def searchContent(key, quick=False, pg="1"):
    """搜索"""
    url = f"{BASE_URL}/search?wd={key}&page={pg}"
    html = req(url)
    videos = []
    # 解析搜索结果
    return json.dumps({
        "page": int(pg),
        "pagecount": 1,
        "limit": 20,
        "total": len(videos),
        "list": videos
    }, ensure_ascii=False)

def playerContent(flag, id, vipFlags=None):
    """播放解析（可选）"""
    return json.dumps({
        "parse": 0,
        "jx": 0,
        "url": id,
        "header": {"User-Agent": "Mozilla/5.0"}
    }, ensure_ascii=False)
```

### 站点配置
```json
{
  "key": "pydemo",
  "name": "Python演示站点",
  "type": 3,
  "api": "csp_pydemo",
  "ext": "https://example.com/spider.py"
}
```

### Chaquo注意事项
- Python版本固定3.10，不要使用3.11+语法
- 部分C扩展库不可用（如numpy、lxml等可能需要特殊处理）
- 优先使用纯Python库：`requests`（框架封装）、`re`、`json`、`html.parser`
- 网络请求使用框架提供的方法，不要直接用 `requests` 库（可能有TLS指纹问题）
- 文件写入受限，不要尝试写本地文件

---

## CSP XPath零代码配置
> 对于结构简单的CMS站，不需要写代码，用JSON配置+XPath选择器即可快速接入。

### 基本配置
```json
{
  "key": "xpathdemo",
  "name": "XPath演示站点",
  "type": 3,
  "api": "csp_XPath",
  "ext": {
    "baseUrl": "https://example.com",
    "homeUrl": "/",
    "categoryUrl": "/list/{tid}-{pg}.html",
    "detailUrl": "/detail/{id}.html",
    "searchUrl": "/search?wd={key}&page={pg}",
    "selectors": {
      "classes": "//nav//a",
      "className": "text()",
      "classId": "@href",
      "videos": "//div[@class='video-list']//div[@class='item']",
      "vodName": ".//h3/text()",
      "vodPic": ".//img/@src",
      "vodId": ".//a/@href",
      "vodRemarks": ".//span[@class='status']/text()",
      "detailName": "//h1/text()",
      "detailPic": "//div[@class='cover']/img/@src",
      "playList": "//div[@class='playlist']//a",
      "playName": "text()",
      "playUrl": "@href"
    }
  }
}
```

### 适用场景
- 标准CMS站（苹果CMS、飞飞CMS等）
- 页面结构规则，元素有明确class/id
- 不需要复杂加密、二次请求
- 播放地址直接在页面中或简单拼接

### 局限性
- 无法处理加密API（AES、RSA等）
- 无法处理需要二次请求的播放地址
- 无法处理动态渲染页面（JS渲染）
- 复杂分页、筛选支持有限

---

## 播放地址处理技巧

### 1. 直链直接返回
```
vod_play_url: "第1集$https://cdn.example.com/ep1.m3u8"
```

### 2. 多线路处理
```
vod_play_from: "线路1$$$线路2$$$线路3"
vod_play_url: "第1集$url1#第2集$url2$$$第1集$url3#第2集$url4$$$第1集$url5"
```
> 线路数和地址段数必须对应，用 `$$$` 分隔。

### 3. 需要二次解析的地址
如果播放地址是网页播放页URL，不是直链，有两种方式：
- **方式A**：在detailContent中就解析出直链（推荐，播放更快）
- **方式B**：返回播放页URL，实现playerContent方法二次解析

```python
# playerContent中解析
def playerContent(flag, id, vipFlags=None):
    # id是播放页URL，请求页面解析出真实m3u8
    html = req(id)
    real_url = re.search(r'url:"(https://[^"]+\.m3u8)"', html).group(1)
    return json.dumps({
        "parse": 0,
        "jx": 0,
        "url": real_url,
        "header": {"Referer": id}
    })
```

### 4. 防盗链处理
播放地址需要Referer/User-Agent时，在playerContent中返回header：
```json
{
  "parse": 0,
  "jx": 0,
  "url": "https://cdn.example.com/video.m3u8",
  "header": {
    "User-Agent": "Mozilla/5.0",
    "Referer": "https://example.com/"
  }
}
```

### 5. eval混淆播放地址
播放地址被 `eval(function(p,a,c,k,e,d){...})` 打包时：
- Python：用正则提取四元组，本地实现解包器
- JS：可以用 `eval()` 直接执行（QuickJS支持），但注意安全
- 解包后提取 `source`、`source842` 等变量中的m3u8地址

---

## 站点JSON配置规范

### 点播站点
```json
{
  "key": "unique_key",
  "name": "站点名称",
  "type": 3,
  "api": "csp_spidername",
  "ext": "https://example.com/spider.js",
  "homePage": "https://example.com/home.html",
  "click": "md5hash",
  "playerType": 1,
  "cookie": ""
}
```

### 字段说明
| 字段 | 说明 |
|------|------|
| key | 站点唯一标识，不能重复 |
| name | 站点显示名称 |
| type | 站点类型：3=爬虫站点，1=普通JSON接口 |
| api | 爬虫标识：`csp_`前缀+爬虫名，或`jar`表示Java Jar |
| ext | 扩展参数：爬虫脚本URL、Jar路径+类名、或配置对象 |
| homePage | WebHome网页首页URL（可选） |
| click | Jar包MD5校验（可选，用于版本校验） |
| playerType | 播放器类型：1=系统，2=IJK，3=MPV，4=Media3（可选） |
| cookie | 站点Cookie（可选，需要登录的站点） |

### 直播站点
```json
{
  "key": "live_key",
  "name": "直播源名称",
  "type": 0,
  "api": "csp_live",
  "ext": "https://example.com/live.txt"
}
```
> 直播源格式为标准M3U或TXT格式。

### 解析站点
```json
{
  "key": "parse_key",
  "name": "解析接口名称",
  "type": 1,
  "api": "https://example.com/parse?url="
}
```

---

## 调试与测试方法

### 1. 本地测试脚本
编写测试脚本，模拟调用四个核心方法：
```python
# test_spider.py
import spider

# 测试首页
result = spider.homeContent()
print("首页:", result[:200])

# 测试分类
result = spider.categoryContent("1", "1")
print("分类:", result[:200])

# 测试详情
result = spider.detailContent("12345")
print("详情:", result[:200])

# 测试搜索
result = spider.searchContent("电影")
print("搜索:", result[:200])
```

### 2. App内调试
- 将爬虫脚本部署到可访问的URL
- 在TVBox中添加站点，配置爬虫
- 打开App调试日志，查看爬虫输出
- WebHome调试工作台查看网页端日志

### 3. 返回结构验证
确保每个方法返回的JSON结构正确：
- homeContent：必须有 `class` 和 `list`
- categoryContent/searchContent：必须有 `page`、`pagecount`、`limit`、`total`、`list`
- detailContent：必须有 `list`，每个元素有 `vod_id`、`vod_name`、`vod_play_from`、`vod_play_url`
- playerContent：必须有 `parse`、`url`

### 4. 常见调试技巧
- 先测试homeContent，确认分类正确
- 再测试categoryContent，确认列表解析正确
- 然后detailContent，确认播放地址正确
- 最后searchContent和playerContent
- 每个方法打印返回的JSON，检查结构和字段
- 网络请求打印URL和响应状态码

---

## 常见问题排查

### 1. 分类不显示
- 检查homeContent返回的 `class` 数组是否正确
- 每个分类必须有 `type_id` 和 `type_name`
- 检查JSON格式是否合法（引号、逗号）

### 2. 列表为空
- 检查分类页URL是否正确
- 检查XPath/正则选择器是否匹配
- 打印响应HTML，确认页面结构
- 检查是否需要特定请求头（User-Agent、Referer、Cookie）

### 3. 详情页打不开
- 检查vod_id是否正确传递
- 检查详情页URL拼接是否正确
- 打印detailContent返回的JSON，确认 `list` 非空

### 4. 播放失败
- 检查播放地址是否是直链（m3u8/mp4）
- 如果是网页URL，确认playerContent正确解析
- 检查是否需要Referer/Cookie等请求头
- 检查播放地址是否过期（有时效性的签名URL）

### 5. 搜索无结果
- 检查搜索URL和参数是否正确
- 检查关键词是否需要URL编码
- 检查搜索接口是否需要POST请求
- 打印搜索响应，确认返回结构

### 6. 图片不显示
- 检查vod_pic是否是完整URL（不是相对路径）
- 相对路径用 `urljoin(baseUrl, pic)` 补全
- CDN防盗链图片需要代理处理

### 7. 多线路播放地址错乱
- 确认 `vod_play_from` 和 `vod_play_url` 的线路数一致
- 用 `$$$` 分隔线路，`#` 分隔集，`$` 分隔集名和地址
- 打印拼接后的字符串，手动检查分隔符
