# -*- coding: utf-8 -*-
# 浪巢福地 四壳通用Python Spider
# 站点: https://dzf.lcfd3.lat/lcfd/
# 类型: 苹果CMS v10 (HTML解析, WAF防护需Safari指纹)
import re
import json

try:
    from base.spider import Spider
except Exception:
    class Spider:
        def __init__(self):
            self.extend = {}
        def init(self, extend):
            self.extend = extend if extend else {}

# 优先使用curl_cffi（Safari指纹穿透WAF），失败则降级requests
try:
    from curl_cffi import requests as curl_requests
    HAS_CURL_CFFI = True
except Exception:
    HAS_CURL_CFFI = False
    import requests as std_requests

class Spider(Spider):
    def __init__(self):
        super().__init__()
        self.rawSite = "https://dzf.lcfd3.lat"
        self.siteUrl = "https://dzf.lcfd3.lat"
        self.sitePath = "/cn/home/web"
        self.HOST = self.siteUrl
        self.safari_headers = {
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh-Hans;q=0.9",
            "Referer": "https://dzf.lcfd3.lat/lcfd/",
        }
        self.minor_keywords = ["萝莉", "幼女", "少女", "童", "teen", "loli", "schoolgirl", "豆蔻", "玉蕊", "碧玉", "稚子"]

    def getName(self):
        return "浪巢福地"

    def init(self, extend=""):
        if extend and isinstance(extend, str) and extend.startswith("{"):
            try:
                self.extend = json.loads(extend)
            except Exception:
                self.extend = {}
        elif isinstance(extend, dict):
            self.extend = extend
        else:
            self.extend = {}
        # 支持ext.proxy / ext.siteUrl覆盖
        if isinstance(self.extend, dict):
            if self.extend.get("siteUrl"):
                self.siteUrl = self.extend["siteUrl"]
                self.HOST = self.siteUrl
            if self.extend.get("proxy"):
                self.siteUrl = self.extend["proxy"]
                self.HOST = self.siteUrl
            if self.extend.get("direct") is True:
                self.siteUrl = self.rawSite
                self.HOST = self.rawSite

    def isVideoFormat(self, url):
        return any(url.endswith(ext) for ext in [".m3u8", ".mp4", ".avi", ".mkv", ".flv", ".wmv"])

    def homeContent(self, filter=False):
        classes = [
            {"type_id": "1", "type_name": "乱伦"},
            {"type_id": "2", "type_name": "出轨"},
            {"type_id": "3", "type_name": "制服"},
            {"type_id": "4", "type_name": "自慰"},
            {"type_id": "5", "type_name": "偷拍"},
            {"type_id": "20", "type_name": "自拍"},
            {"type_id": "21", "type_name": "国产"},
            {"type_id": "22", "type_name": "同性"},
            {"type_id": "23", "type_name": "日韩"},
            {"type_id": "24", "type_name": "欧美"},
            {"type_id": "25", "type_name": "三级"},
            {"type_id": "26", "type_name": "动漫"},
        ]
        classes = [c for c in classes if not self._is_minor(c["type_name"])]
        filters = {}
        for c in classes:
            filters[c["type_id"]] = [
                {"key": "by", "name": "排序", "value": [
                    {"n": "最新", "v": "time"},
                    {"n": "热门", "v": "hits"},
                ]}
            ]
        result = {"class": classes, "filters": filters, "list": []}
        try:
            cat_data = self.categoryContent("21", "1")
            result["list"] = cat_data.get("list", [])[:12]
        except Exception:
            pass
        return result

    def categoryContent(self, tid, pg, filter=False, extend=None):
        if extend is None:
            extend = {}
        sort_by = extend.get("by", "time") if isinstance(extend, dict) else "time"
        if sort_by == "hits":
            url = f"{self.siteUrl}{self.sitePath}/index.php/vod/show/by/hits/id/{tid}.html"
            if int(pg) > 1:
                url = f"{self.siteUrl}{self.sitePath}/index.php/vod/show/by/hits/id/{tid}/page/{pg}.html"
        else:
            url = f"{self.siteUrl}{self.sitePath}/index.php/vod/type/id/{tid}.html"
            if int(pg) > 1:
                url = f"{self.siteUrl}{self.sitePath}/index.php/vod/type/id/{tid}/page/{pg}.html"
        html = self._get(url)
        videos = self._parse_video_list(html)
        videos = [v for v in videos if not self._is_minor(v.get("vod_name", ""))]
        total = 0
        pagecount = 1
        limit = 24
        total_match = re.search(r"共有\s*(\d+)\s*个视频", html)
        if total_match:
            total = int(total_match.group(1))
            pagecount = (total + limit - 1) // limit
        return {
            "page": int(pg),
            "pagecount": pagecount,
            "limit": limit,
            "total": total,
            "list": videos,
        }

    def detailContent(self, ids):
        if not isinstance(ids, (list, tuple)):
            ids = [ids]
        result_list = []
        for vod_id in ids:
            vod_id = str(vod_id).strip()
            if not vod_id:
                continue
            play_url = f"{self.siteUrl}{self.sitePath}/index.php/vod/play/id/{vod_id}/sid/1/nid/1.html"
            html = self._get(play_url)
            player_data = self._parse_player_data(html)
            play_url_m3u8 = player_data.get("url", "")
            title = ""
            title_match = re.search(r"<title>([^<]+)</title>", html)
            if title_match:
                title = title_match.group(1)
                title = title.replace("_浪巢福地", "").replace(" - 浪巢福地", "").replace("在线播放", "").strip()
            pic = ""
            pic_match = re.search(r'<meta[^>]*property="og:image"[^>]*content="([^"]+)"', html)
            if pic_match:
                pic = pic_match.group(1)
            if self._is_minor(title):
                continue
            vod = {
                "vod_id": vod_id,
                "vod_name": title,
                "vod_pic": pic,
                "vod_remarks": "浪巢福地",
                "vod_actor": "",
                "vod_director": "",
                "vod_content": "",
                "vod_area": "",
                "vod_year": "",
                "vod_type": "",
                "vod_play_from": "ckplayer",
                "vod_play_url": f"第1集{play_url_m3u8}" if play_url_m3u8 else "",
            }
            result_list.append(vod)
        return {"list": result_list}

    def searchContent(self, key, quick=False, pg="1"):
        try:
            encoded_key = __import__("urllib.parse").quote(key)
        except Exception:
            encoded_key = key
        url = f"{self.siteUrl}{self.sitePath}/index.php/vod/search/wd/{encoded_key}.html"
        if int(pg) > 1:
            url = f"{self.siteUrl}{self.sitePath}/index.php/vod/search/page/{pg}/wd/{encoded_key}.html"
        html = self._get(url)
        videos = self._parse_video_list(html)
        videos = [v for v in videos if not self._is_minor(v.get("vod_name", ""))]
        total = len(videos)
        return {
            "page": int(pg),
            "pagecount": 1,
            "limit": 24,
            "total": total,
            "list": videos,
        }

    def playerContent(self, flag, id, vipFlags=False):
        url = id
        header = dict(self.safari_headers)
        header["Referer"] = f"{self.rawSite}/"
        header["Origin"] = self.rawSite
        return {
            "parse": 0,
            "jx": 0,
            "url": url,
            "header": header,
        }

    def localProxy(self, params):
        return [404, "text/plain", ""]

    def getDependence(self):
        return ""

    # ============ 内部工具 ============

    def _get(self, url):
        if HAS_CURL_CFFI:
            try:
                resp = curl_requests.get(url, impersonate="safari17_2_ios", timeout=15, allow_redirects=True)
                if resp.status_code == 200:
                    return resp.text
            except Exception:
                pass
        # 降级requests
        try:
            resp = std_requests.get(url, headers=self.safari_headers, timeout=15, allow_redirects=True)
            if resp.status_code == 200 and len(resp.text) > 2000:
                return resp.text
        except Exception:
            pass
        return ""

    def _parse_video_list(self, html):
        videos = []
        if not html:
            return videos
        # 结构1: ul.img-list > li > a[title] > img
        lis = re.findall(r'<li>\s*<a[^>]*href="[^"]*vod/play/id/(\d+)[^"]*"[^>]*title="([^"]*)"[^>]*>(.*?)</a>\s*</li>', html, re.DOTALL)
        if lis:
            for vod_id, title, block in lis:
                pic = ""
                pic_match = re.search(r'<img[^>]*src="([^"]+)"', block)
                if pic_match:
                    pic = pic_match.group(1)
                if vod_id and title:
                    videos.append({"vod_id": vod_id, "vod_name": title.strip(), "vod_pic": pic, "vod_remarks": "浪巢福地"})
            return videos
        # 结构2: div.video_B
        blocks = re.findall(r'<div class="video_B[^"]*"[^>]*>(.*?)</div>\s*</div>', html, re.DOTALL)
        if blocks:
            for block in blocks:
                vod_id = ""
                title = ""
                pic = ""
                id_match = re.search(r'vod/play/id/(\d+)', block)
                if id_match:
                    vod_id = id_match.group(1)
                title_match = re.search(r'title="([^"]+)"', block)
                if title_match:
                    title = title_match.group(1).strip()
                pic_match = re.search(r'<img[^>]*src="([^"]+)"', block)
                if pic_match:
                    pic = pic_match.group(1)
                if vod_id and title:
                    videos.append({"vod_id": vod_id, "vod_name": title, "vod_pic": pic, "vod_remarks": "浪巢福地"})
            return videos
        # 结构3: 通用正则
        items = re.findall(
            r'<a[^>]*href="[^"]*vod/play/id/(\d+)[^"]*"[^>]*title="([^"]*)"[^>]*>.*?<img[^>]*src="([^"]+)"',
            html, re.DOTALL
        )
        for vod_id, title, pic in items:
            videos.append({"vod_id": vod_id, "vod_name": title.strip(), "vod_pic": pic, "vod_remarks": "浪巢福地"})
        return videos

    def _parse_player_data(self, html):
        data = {}
        if not html:
            return data
        match = re.search(r'var\s+player_data\s*=\s*(\{.*?\})', html, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
            except Exception:
                url_match = re.search(r'"url"\s*:\s*"([^"]+)"', match.group(1))
                if url_match:
                    data["url"] = url_match.group(1).replace("\\/", "/")
        return data

    def _is_minor(self, text):
        if not text:
            return False
        text_lower = text.lower()
        for kw in self.minor_keywords:
            if kw.lower() in text_lower:
                return True
        return False
