# -*- coding: utf-8 -*-
"""
A片银行 TVBox四壳通用Python Spider
站点: https://azj.apyh3.mom/apyh/
类型: 苹果CMS酷黑模板（特殊结构：仅首页+播放页可用）
"""

import re
import json
import urllib.request
import urllib.parse
import urllib.error

try:
    from base.spider import Spider
except Exception:
    class Spider:
        def __init__(self):
            self.extend = {}

        def init(self, extend):
            self.extend = extend or {}

        def homeContent(self, *args):
            return {}

        def categoryContent(self, *args):
            return {}

        def detailContent(self, *args):
            return {}

        def searchContent(self, *args):
            return {}

        def playerContent(self, *args):
            return {}

        def localProxy(self, *args):
            return [404, "text/plain", ""]

        def isVideoFormat(self, url):
            return True

        def manualVideoCheck(self):
            return False

        def getDependence(self):
            return ""

        def getName(self):
            return "A片银行"

        def getApp(self):
            return "apianhang"


UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
BASE = "https://azj.apyh3.mom/apyh"


def _fetch(url, timeout=15):
    """带UA和Referer的请求"""
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Referer": BASE + "/",
        "Accept-Language": "zh-CN,zh;q=0.9",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="ignore")
    except Exception:
        return ""


def _parse_home_videos(html):
    """从首页解析视频列表"""
    videos = []
    # 匹配播放页链接 + title + data-original封面
    pattern = re.compile(
        r'href="(/cn/home/web/index\.php/vod/play/id/(\d+)/sid/\d+/nid/\d+\.html)"[^>]*'
        r'(?:title="([^"]*)")?[^>]*'
        r'(?:data-original="([^"]*)")?',
        re.DOTALL
    )
    seen = set()
    for m in pattern.finditer(html):
        play_url, vid, title, pic = m.groups()
        if vid in seen:
            continue
        seen.add(vid)
        if not title:
            # 尝试从相邻的a标签取标题
            title_m = re.search(
                r'href="' + re.escape(play_url) + r'"[^>]*title="([^"]*)"',
                html
            )
            title = title_m.group(1) if title_m else vid
        videos.append({
            "vod_id": vid,
            "vod_name": title.strip(),
            "vod_pic": pic or "",
            "vod_remarks": "",
            "play_url": play_url,
        })
    return videos


class Spider(Spider):
    def __init__(self):
        super().__init__()
        self.extend = {}

    def init(self, extend=""):
        if isinstance(extend, str) and extend.strip():
            try:
                self.extend = json.loads(extend)
            except Exception:
                self.extend = {}
        elif isinstance(extend, dict):
            self.extend = extend
        else:
            self.extend = {}

    def homeContent(self, *args):
        """首页内容：从首页提取推荐视频"""
        html = _fetch(BASE + "/")
        videos = _parse_home_videos(html)

        classes = [
            {"type_id": "home", "type_name": "首页推荐"},
            {"type_id": "hot", "type_name": "热门排行"},
            {"type_id": "new", "type_name": "最新更新"},
        ]

        filters = {
            "home": [{"key": "pg", "name": "分页", "value": ["1", "2", "3"]}],
            "hot": [{"key": "pg", "name": "分页", "value": ["1", "2", "3"]}],
            "new": [{"key": "pg", "name": "分页", "value": ["1", "2", "3"]}],
        }

        return {
            "class": classes,
            "list": videos[:30],
            "filters": filters,
        }

    def categoryContent(self, tid, pg, *args):
        """分类内容：该站分类页404，统一从首页提取"""
        html = _fetch(BASE + "/")
        videos = _parse_home_videos(html)

        # 根据分类筛选（首页不同区块模拟）
        if tid == "hot":
            videos = videos[10:40] if len(videos) > 10 else videos
        elif tid == "new":
            videos = videos[20:50] if len(videos) > 20 else videos
        else:
            videos = videos[:30]

        page = int(pg) if pg else 1
        page_size = 30
        start = (page - 1) * page_size
        end = start + page_size
        page_videos = videos[start:end]

        return {
            "page": page,
            "pagecount": max(1, (len(videos) + page_size - 1) // page_size),
            "limit": page_size,
            "total": len(videos),
            "list": page_videos,
        }

    def detailContent(self, ids, *args):
        """详情内容：从播放页提取视频信息和播放地址"""
        if not ids:
            return {"list": []}

        vid = ids[0] if isinstance(ids, (list, tuple)) else str(ids)
        play_url = f"/cn/home/web/index.php/vod/play/id/{vid}/sid/1/nid/1.html"
        html = _fetch(BASE + play_url)

        # 提取标题
        title_m = re.search(r"<title>([^<]+?)(?:详情介绍|在线观看|迅雷下载)[^<]*</title>", html)
        if not title_m:
            title_m = re.search(r"<title>([^<]+)</title>", html)
        vod_name = title_m.group(1).strip() if title_m else vid

        # 提取封面
        pic_m = re.search(r'data-original="([^"]+)"', html)
        vod_pic = pic_m.group(1) if pic_m else ""

        # 提取player_data中的播放地址
        play_url_m = re.search(r'player_data=\{[^}]*"url":"([^"]+)"', html)
        m3u8_url = play_url_m.group(1).replace("\\/", "/") if play_url_m else ""

        # 提取视频信息
        year_m = re.search(r'年份[：:]\s*([^<\s]+)', html)
        area_m = re.search(r'地区[：:]\s*([^<\s]+)', html)
        type_m = re.search(r'类型[：:]\s*([^<\s]+)', html)
        desc_m = re.search(r'简介[：:]\s*([^<]{5,200})', html)

        vod = {
            "vod_id": vid,
            "vod_name": vod_name,
            "vod_pic": vod_pic,
            "vod_year": year_m.group(1) if year_m else "",
            "vod_area": area_m.group(1) if area_m else "",
            "vod_remarks": "ckplayer",
            "vod_content": desc_m.group(1).strip() if desc_m else "",
            "vod_play_from": "ckplayer",
            "vod_play_url": f"第1集${m3u8_url}" if m3u8_url else "",
        }

        return {"list": [vod]}

    def searchContent(self, wd, pg, *args):
        """搜索内容：该站搜索页400，返回空"""
        return {
            "page": 1,
            "pagecount": 0,
            "limit": 30,
            "total": 0,
            "list": [],
        }

    def playerContent(self, flag, id, vipFlags, *args):
        """播放内容：返回m3u8播放地址"""
        # id可能是播放地址本身，或者是视频ID
        if id and id.startswith("http"):
            url = id
        else:
            vid = id
            play_url = f"/cn/home/web/index.php/vod/play/id/{vid}/sid/1/nid/1.html"
            html = _fetch(BASE + play_url)
            play_url_m = re.search(r'player_data=\{[^}]*"url":"([^"]+)"', html)
            url = play_url_m.group(1).replace("\\/", "/") if play_url_m else ""

        return {
            "parse": 0,
            "jx": 0,
            "url": url,
            "header": {
                "User-Agent": UA,
                "Referer": BASE + "/",
            },
        }

    def localProxy(self, *args):
        """本地代理：m3u8广告清洗（基础版）"""
        if len(args) >= 1:
            url = args[0]
        else:
            return [404, "text/plain", ""]

        if not url or not url.startswith("http"):
            return [404, "text/plain", ""]

        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": UA,
                "Referer": BASE + "/",
            })
            with urllib.request.urlopen(req, timeout=15) as resp:
                content = resp.read().decode("utf-8", errors="ignore")
            # 基础广告清洗：剔除含ad/gg关键词的ts段
            cleaned = []
            for line in content.split("\n"):
                line_stripped = line.strip()
                if line_stripped.startswith("#"):
                    cleaned.append(line)
                elif line_stripped and not re.search(r'(ad|gg|adv|preroll|片头|广告)', line_stripped, re.I):
                    cleaned.append(line)
            return [200, "application/vnd.apple.mpegurl", "\n".join(cleaned)]
        except Exception:
            return [502, "text/plain", "proxy error"]

    def isVideoFormat(self, url):
        return bool(url and (".m3u8" in url or ".mp4" in url))

    def manualVideoCheck(self):
        return False

    def getDependence(self):
        return ""

    def getName(self):
        return "A片银行"

    def getApp(self):
        return "apianhang"
