# -*- coding: utf-8 -*-
# 露思AV网 四壳通用Python Spider
# 站点: https://ubi.lsavw6.pics/lsavw/
# 类型: 苹果CMS v10 (HTML解析)
import re
import json
import urllib.request
import urllib.parse

try:
    from base.spider import Spider
except Exception:
    class Spider:
        def __init__(self):
            self.extend = {}
        def init(self, extend):
            self.extend = extend if extend else {}

class Spider(Spider):
    def __init__(self):
        super().__init__()
        self.baseUrl = "https://ubi.lsavw6.pics"
        self.sitePath = "/cn/home/web"
        self.cookie = ""
        self.header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Referer": "https://ubi.lsavw6.pics/lsavw/",
        }
        # 未成年关键词（铁律13，命中则跳过不展示）
        self.minor_keywords = ["萝莉", "幼女", "少女", "童", "teen", "loli", "schoolgirl", "豆蔻", "玉蕊", "碧玉", "稚子"]

    def getName(self):
        return "露思AV网"

    def init(self, extend=""):
        if extend and isinstance(extend, str) and extend.startswith("{"):
            try:
                self.extend = json.loads(extend)
            except Exception:
                self.extend = {}
        elif isinstance(extend, dict):
            self.extend = extend
        else:
            self.extend = {}

    def isVideoFormat(self, url):
        return any(url.endswith(ext) for ext in [".m3u8", ".mp4", ".avi", ".mkv", ".flv", ".wmv"])

    def homeContent(self, filter=False):
        classes = [
            {"type_id": "20", "type_name": "国产精品"},
            {"type_id": "21", "type_name": "主播大秀"},
            {"type_id": "22", "type_name": "抖阴视频"},
            {"type_id": "23", "type_name": "女神学生"},
            {"type_id": "24", "type_name": "美熟少妇"},
            {"type_id": "25", "type_name": "娇妻素人"},
            {"type_id": "26", "type_name": "空姐模特"},
            {"type_id": "27", "type_name": "国产乱伦"},
            {"type_id": "28", "type_name": "自慰群交"},
            {"type_id": "29", "type_name": "野合车震"},
            {"type_id": "30", "type_name": "职场同事"},
            {"type_id": "31", "type_name": "国产名人"},
            {"type_id": "32", "type_name": "日本无码"},
            {"type_id": "33", "type_name": "精品三级"},
        ]
        # 过滤未成年分类（铁律13）
        classes = [c for c in classes if not self._is_minor(c["type_name"])]
        filters = {}
        for c in classes:
            filters[c["type_id"]] = [
                {"key": "by", "name": "排序", "value": [
                    {"n": "最新上传", "v": "time"},
                    {"n": "热门排行", "v": "hits"},
                ]}
            ]
        result = {"class": classes, "filters": filters, "list": []}
        # 首页推荐（取国产精品第一页前12条）
        try:
            cat_data = self.categoryContent("20", "1")
            result["list"] = cat_data.get("list", [])[:12]
        except Exception:
            pass
        return result

    def categoryContent(self, tid, pg, filter=False, extend=None):
        if extend is None:
            extend = {}
        sort_by = extend.get("by", "time") if isinstance(extend, dict) else "time"
        if sort_by == "hits":
            url = f"{self.baseUrl}{self.sitePath}/index.php/vod/show/by/hits/id/{tid}.html"
            if int(pg) > 1:
                url = f"{self.baseUrl}{self.sitePath}/index.php/vod/show/by/hits/id/{tid}/page/{pg}.html"
        else:
            url = f"{self.baseUrl}{self.sitePath}/index.php/vod/type/id/{tid}.html"
            if int(pg) > 1:
                url = f"{self.baseUrl}{self.sitePath}/index.php/vod/type/id/{tid}/page/{pg}.html"
        html = self._get(url)
        videos = self._parse_video_list(html)
        # 过滤未成年条目（铁律13）
        videos = [v for v in videos if not self._is_minor(v.get("vod_name", ""))]
        # 解析总数和分页
        total = 0
        pagecount = 1
        limit = 24
        total_match = re.search(r"共有\s*(\d+)\s*个视频", html)
        if total_match:
            total = int(total_match.group(1))
            pagecount = (total + limit - 1) // limit
        return {
            "page": int(pg),
            "pagecount": pagecount,
            "limit": limit,
            "total": total,
            "list": videos,
        }

    def detailContent(self, ids):
        if not isinstance(ids, (list, tuple)):
            ids = [ids]
        result_list = []
        for vod_id in ids:
            vod_id = str(vod_id).strip()
            if not vod_id:
                continue
            play_url = f"{self.baseUrl}{self.sitePath}/index.php/vod/play/id/{vod_id}/sid/1/nid/1.html"
            html = self._get(play_url)
            # 解析player_data
            player_data = self._parse_player_data(html)
            play_url_m3u8 = player_data.get("url", "")
            # 解析标题
            title = ""
            title_match = re.search(r"<title>([^<]+)</title>", html)
            if title_match:
                title = title_match.group(1)
                title = title.replace("_露思AV网", "").replace("在线播放", "").strip()
            # 解析封面
            pic = ""
            pic_match = re.search(r'<meta[^>]*property="og:image"[^>]*content="([^"]+)"', html)
            if pic_match:
                pic = pic_match.group(1)
            # 过滤未成年（铁律13）
            if self._is_minor(title):
                continue
            vod = {
                "vod_id": vod_id,
                "vod_name": title,
                "vod_pic": pic,
                "vod_remarks": "露思AV网",
                "vod_actor": "",
                "vod_director": "",
                "vod_content": "",
                "vod_area": "",
                "vod_year": "",
                "vod_type": "",
                "vod_play_from": "ckplayer",
                "vod_play_url": f"第1集{play_url_m3u8}" if play_url_m3u8 else "",
            }
            result_list.append(vod)
        return {"list": result_list}

    def searchContent(self, key, quick=False, pg="1"):
        encoded_key = urllib.parse.quote(key)
        url = f"{self.baseUrl}{self.sitePath}/index.php/vod/search/wd/{encoded_key}.html"
        if int(pg) > 1:
            url = f"{self.baseUrl}{self.sitePath}/index.php/vod/search/page/{pg}/wd/{encoded_key}.html"
        html = self._get(url)
        videos = self._parse_video_list(html)
        # 过滤未成年（铁律13）
        videos = [v for v in videos if not self._is_minor(v.get("vod_name", ""))]
        total = len(videos)
        return {
            "page": int(pg),
            "pagecount": 1,
            "limit": 24,
            "total": total,
            "list": videos,
        }

    def playerContent(self, flag, id, vipFlags=False):
        # id 就是 m3u8 地址（从detailContent的vod_play_url中解析）
        url = id
        header = dict(self.header)
        header["Referer"] = f"{self.baseUrl}/"
        header["Origin"] = self.baseUrl
        return {
            "parse": 0,
            "jx": 0,
            "url": url,
            "header": header,
        }

    def localProxy(self, params):
        return [404, "text/plain", ""]

    def getDependence(self):
        return ""

    # ============ 内部工具方法 ============

    def _get(self, url):
        req = urllib.request.Request(url, headers=self.header)
        try:
            resp = urllib.request.urlopen(req, timeout=15)
            return resp.read().decode("utf-8", errors="replace")
        except Exception:
            return ""

    def _parse_video_list(self, html):
        videos = []
        if not html:
            return videos
        # 匹配 video_B 块
        pattern = r'<div class="video_B[^"]*"[^>]*>(.*?)</div>\s*</div>'
        blocks = re.findall(pattern, html, re.DOTALL)
        if not blocks:
            # 备用：匹配所有播放链接+封面+标题
            items = re.findall(
                r'<a[^>]*href="[^"]*vod/play/id/(\d+)[^"]*"[^>]*title="([^"]*)"[^>]*>\s*<img[^>]*src="([^"]+)"',
                html, re.DOTALL
            )
            for vod_id, title, pic in items:
                videos.append({
                    "vod_id": vod_id,
                    "vod_name": title.strip(),
                    "vod_pic": pic,
                    "vod_remarks": "露思AV网",
                })
            return videos
        for block in blocks:
            vod_id = ""
            title = ""
            pic = ""
            id_match = re.search(r'vod/play/id/(\d+)', block)
            if id_match:
                vod_id = id_match.group(1)
            title_match = re.search(r'title="([^"]+)"', block)
            if title_match:
                title = title_match.group(1).strip()
            pic_match = re.search(r'<img[^>]*src="([^"]+)"', block)
            if pic_match:
                pic = pic_match.group(1)
            if vod_id and title:
                videos.append({
                    "vod_id": vod_id,
                    "vod_name": title,
                    "vod_pic": pic,
                    "vod_remarks": "露思AV网",
                })
        return videos

    def _parse_player_data(self, html):
        data = {}
        if not html:
            return data
        match = re.search(r'var\s+player_data\s*=\s*(\{.*?\})\s*;', html, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
            except Exception:
                # 手动解析
                url_match = re.search(r'"url"\s*:\s*"([^"]+)"', match.group(1))
                if url_match:
                    data["url"] = url_match.group(1).replace("\\/", "/")
        return data

    def _is_minor(self, text):
        """铁律13：检测未成年相关内容，命中则跳过"""
        if not text:
            return False
        text_lower = text.lower()
        for kw in self.minor_keywords:
            if kw.lower() in text_lower:
                return True
        return False
