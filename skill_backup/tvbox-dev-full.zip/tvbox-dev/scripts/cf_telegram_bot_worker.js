/**
 * 段德机器人 - Cloudflare Worker版本
 * 使用Telegram Webhook模式，无需长期运行进程
 * 
 * 部署步骤：
 * 1. 上传到Cloudflare Workers
 * 2. 设置环境变量: BOT_TOKEN, ADMIN_ID, CHAT_ID
 * 3. 设置Webhook: https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://<your-worker>.workers.dev/webhook
 */

// 环境变量（在CF Workers后台设置）
const BOT_TOKEN = env?.BOT_TOKEN || "YOUR_BOT_TOKEN";
const ADMIN_ID = env?.ADMIN_ID || "8766992921";
const CHAT_ID = env?.CHAT_ID || "-1003795519678";
const API_BASE = `https://api.telegram.org/bot${BOT_TOKEN}`;

// KV命名空间（用于存储用户数据、积分等）
// 需要在CF Workers后台绑定KV，变量名: BOT_KV
const BOT_KV = env?.BOT_KV || null;

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  const url = new URL(request.url);
  
  // Webhook端点
  if (url.pathname === '/webhook' && request.method === 'POST') {
    try {
      const update = await request.json();
      await processUpdate(update);
      return new Response('OK', { status: 200 });
    } catch (e) {
      console.error('Webhook error:', e);
      return new Response('Error', { status: 500 });
    }
  }
  
  // 健康检查
  if (url.pathname === '/health') {
    return new Response(JSON.stringify({
      status: 'running',
      bot: '段德机器人',
      mode: 'webhook',
      time: new Date().toISOString()
    }), { 
      status: 200, 
      headers: { 'Content-Type': 'application/json' } 
    });
  }
  
  // 设置Webhook（手动访问触发）
  if (url.pathname === '/setwebhook') {
    const webhookUrl = `${url.origin}/webhook`;
    const result = await fetch(`${API_BASE}/setWebhook?url=${encodeURIComponent(webhookUrl)}`);
    const data = await result.json();
    return new Response(JSON.stringify(data), { 
      status: 200, 
      headers: { 'Content-Type': 'application/json' } 
    });
  }
  
  return new Response('段德机器人 CF Worker 运行中', { status: 200 });
}

async function processUpdate(update) {
  // 处理消息
  if (update.message) {
    await handleMessage(update.message);
  }
  // 处理回调按钮
  else if (update.callback_query) {
    await handleCallback(update.callback_query);
  }
}

async function handleMessage(message) {
  const chatId = message.chat.id;
  const userId = message.from.id;
  const text = message.text || '';
  const username = message.from.username || '';
  const firstName = message.from.first_name || '';
  
  console.log(`收到消息: chat=${chatId}, user=${userId}, text=${text}`);
  
  // 命令处理
  if (text.startsWith('/')) {
    await handleCommand(chatId, userId, text, username, firstName);
    return;
  }
  
  // 网址检测（自动入队）
  if (isUrl(text)) {
    await handleUrl(chatId, userId, text, firstName);
    return;
  }
  
  // 普通消息回复
  if (chatId.toString() === CHAT_ID) {
    // 群里的普通消息，可以记录或忽略
    return;
  }
}

async function handleCommand(chatId, userId, command, username, firstName) {
  const parts = command.split(' ');
  const cmd = parts[0].toLowerCase();
  
  switch (cmd) {
    case '/start':
      await sendMessage(chatId, 
        `🤖 段德机器人已启动（CF Worker版）\n\n` +
        `📋 可用命令：\n` +
        `/start - 显示帮助\n` +
        `/ping - 测试连通性\n` +
        `/id - 查看你的ID\n` +
        `/subscribe - 获取订阅地址\n` +
        `/account - 账号信息\n` +
        `\n💡 在群里发送网址自动入队爬虫`
      );
      break;
      
    case '/ping':
      await sendMessage(chatId, '🏓 Pong! 机器人运行正常');
      break;
      
    case '/id':
      await sendMessage(chatId, 
        `🆔 你的信息：\n` +
        `用户ID: ${userId}\n` +
        `用户名: @${username}\n` +
        `昵称: ${firstName}\n` +
        `聊天ID: ${chatId}`
      );
      break;
      
    case '/subscribe':
      await handleSubscribe(chatId, userId);
      break;
      
    case '/account':
      await handleAccount(chatId, userId, firstName, username);
      break;
      
    case '/panel':
      await sendPanel(chatId);
      break;
      
    default:
      await sendMessage(chatId, `❓ 未知命令: ${cmd}\n发送 /start 查看帮助`);
  }
}

async function handleUrl(chatId, userId, url, firstName) {
  // 检查是否是群主或管理员
  const isAdmin = userId.toString() === ADMIN_ID;
  
  // 记录到KV（如果有KV）
  if (BOT_KV) {
    const queueKey = 'pending_urls';
    let queue = [];
    try {
      const existing = await BOT_KV.get(queueKey);
      if (existing) queue = JSON.parse(existing);
    } catch (e) {}
    
    queue.push({
      url: url,
      user_id: userId,
      user_name: firstName,
      time: new Date().toISOString(),
      status: 'pending'
    });
    
    await BOT_KV.put(queueKey, JSON.stringify(queue));
  }
  
  await sendMessage(chatId, 
    `✅ 网址已入队：\n${url}\n\n` +
    `投递者: ${firstName}\n` +
    `状态: 待处理\n` +
    `\n⏳ 将按队列顺序执行爬虫任务`
  );
}

async function handleSubscribe(chatId, userId) {
  // 生成订阅地址（需要配置鉴权服务）
  const authUrl = env?.AUTH_WORKER_URL || 'https://tvbox.ystv.top';
  
  await sendMessage(chatId, 
    `📡 订阅地址获取：\n\n` +
    `请访问鉴权服务获取专属订阅地址：\n${authUrl}\n\n` +
    `⚠️ 订阅地址采用Token鉴权，退群后失效`
  );
}

async function handleAccount(chatId, userId, firstName, username) {
  let points = 0;
  let signCount = 0;
  
  // 从KV读取用户数据
  if (BOT_KV) {
    try {
      const userData = await BOT_KV.get(`user_${userId}`);
      if (userData) {
        const data = JSON.parse(userData);
        points = data.points || 0;
        signCount = data.sign_count || 0;
      }
    } catch (e) {}
  }
  
  await sendMessage(chatId, 
    `👤 账号信息\n\n` +
    `昵称: ${firstName}\n` +
    `用户名: @${username}\n` +
    `TG ID: ${userId}\n` +
    `积分: ${points}\n` +
    `签到次数: ${signCount}\n` +
    `系统状态: ✅ 正常`
  );
}

async function sendPanel(chatId) {
  const keyboard = {
    inline_keyboard: [
      [
        { text: '📅 每日签到', callback_data: 'sign' },
        { text: '💰 我的积分', callback_data: 'points' },
        { text: '🤖 机器人控制', callback_data: 'control' }
      ],
      [
        { text: '📊 积分排行', callback_data: 'rank' },
        { text: '📡 订阅源', callback_data: 'subscribe' },
        { text: '👤 账号信息', callback_data: 'account' }
      ]
    ]
  };
  
  await sendMessage(chatId, '🎛️ 机器人控制面板', keyboard);
}

async function handleCallback(callbackQuery) {
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const data = callbackQuery.data;
  
  // 应答回调
  await fetch(`${API_BASE}/answerCallbackQuery`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callback_query_id: callbackQuery.id })
  });
  
  switch (data) {
    case 'sign':
      await sendMessage(chatId, '✅ 签到成功，获得1积分');
      break;
    case 'points':
      await sendMessage(chatId, '💰 当前积分: 0');
      break;
    case 'subscribe':
      await handleSubscribe(chatId, userId);
      break;
    case 'account':
      await handleAccount(chatId, userId, callbackQuery.from.first_name, callbackQuery.from.username);
      break;
    default:
      await sendMessage(chatId, `按钮: ${data}`);
  }
}

async function sendMessage(chatId, text, replyMarkup = null) {
  const body = {
    chat_id: chatId,
    text: text,
    parse_mode: 'HTML'
  };
  
  if (replyMarkup) {
    body.reply_markup = replyMarkup;
  }
  
  const result = await fetch(`${API_BASE}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  
  return result.json();
}

function isUrl(text) {
  const urlPattern = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/i;
  return urlPattern.test(text.trim());
}
