# Telegram机器人部署到Cloudflare Workers指南

## 方案说明

Cloudflare Workers是无服务器的，不支持长期运行的getUpdates轮询。
因此需要改用Telegram Bot的**Webhook模式**：
- Telegram服务器主动推送消息到你的Worker
- Worker处理后调用Telegram API回复

## 部署步骤

### 1. 上传Worker脚本

1. 登录Cloudflare Dashboard → Workers & Pages
2. 点击 "Create application" → "Create Worker"
3. 输入Worker名称（如 `duande-bot`）
4. 点击 "Deploy"
5. 点击 "Edit code"，把 `cf_telegram_bot_worker.js` 的内容粘贴进去
6. 点击 "Save and Deploy"

### 2. 设置环境变量

在Worker设置页面 → Settings → Variables：

| 变量名 | 值 | 说明 |
|--------|-----|------|
| `BOT_TOKEN` | `8851237263:AAFcAx3...` | Bot Token |
| `ADMIN_ID` | `8766992921` | 群主用户ID |
| `CHAT_ID` | `-1003795519678` | 目标群ID |
| `AUTH_WORKER_URL` | `https://tvbox.ystv.top` | 订阅鉴权服务地址 |

### 3. 绑定KV命名空间（可选，用于存储用户数据）

1. 在Cloudflare → Workers & Pages → KV 创建命名空间 `bot-data`
2. 在Worker设置 → Variables → KV Namespace Bindings
3. 变量名填 `BOT_KV`，选择刚创建的命名空间

### 4. 设置Webhook

访问以下URL（替换为你的Worker地址）：

```
https://duande-bot.<你的子域>.workers.dev/setwebhook
```

或者手动调用：

```bash
curl "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://duande-bot.<你的子域>.workers.dev/webhook"
```

### 5. 测试

1. 私聊机器人发送 `/start`
2. 应该收到帮助消息
3. 发送 `/ping` 应该收到 `Pong!`

## 功能限制

CF Worker版本相比完整Python版本：

| 功能 | CF Worker版 | Python版（豆包端） |
|------|------------|-------------------|
| 基础命令 | ✅ | ✅ |
| 网址入队 | ✅（存KV） | ✅（存JSON/DB） |
| 积分系统 | ⚠️（基础） | ✅（完整） |
| 爬虫任务 | ❌ | ✅ |
| 文件推送 | ❌ | ✅ |
| 数据库 | KV | SQLite |
| 长期运行 | ❌ | ✅ |

## 推荐架构

**混合部署方案**（推荐）：
- CF Worker：处理基础命令、网址入队、订阅分发
- 豆包端Python：执行爬虫任务、文件推送、复杂逻辑
- 两者通过KV或API共享数据

## 注意事项

1. **必须先停止豆包端的轮询机器人**，否则会冲突（getUpdates和webhook不能同时用）
2. Webhook设置后，Telegram会立即开始推送消息
3. CF Worker有每日请求次数限制（免费版10万次/天）
4. KV读写有最终一致性，不适合高频更新的数据
