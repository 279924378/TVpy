#!/usr/bin/env python3
"""
tvbox影视 - 一键部署到Cloudflare Workers
用法: python3 deploy_to_cf.py
"""

import json
import sys
import os

try:
    import requests
except ImportError:
    print("安装requests...")
    os.system(f"{sys.executable} -m pip install requests -q")
    import requests

# 配置
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
CONFIG_FILE = os.path.join(PROJECT_DIR, "config", "cf_config.json")
WORKER_FILE = os.path.join(PROJECT_DIR, "worker", "_worker_single.js")

def load_config():
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def deploy_worker(config):
    api_token = config["api_token"]
    account_id = config["account_id"]
    worker_name = config["worker_name"]
    
    print(f"🚀 部署Worker: {worker_name}")
    
    # 读取Worker代码
    with open(WORKER_FILE, "r", encoding="utf-8") as f:
        script_content = f.read()
    print(f"📄 代码大小: {len(script_content)} bytes")
    
    # 构建metadata
    metadata = {
        "main_module": "worker.js",
        "compatibility_date": "2024-01-01",
        "compatibility_flags": ["nodejs_compat"],
    }
    
    # 上传Worker
    url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{worker_name}"
    headers = {"Authorization": f"Bearer {api_token}"}
    
    # multipart/form-data
    files = {
        "metadata": (None, json.dumps(metadata), "application/json"),
        "worker.js": ("worker.js", script_content, "application/javascript+module"),
    }
    
    print("📤 上传到Cloudflare...")
    resp = requests.put(url, headers=headers, files=files, timeout=60)
    
    if resp.status_code in (200, 201):
        data = resp.json()
        if data.get("success"):
            print("✅ Worker上传成功")
            return True
        else:
            print(f"❌ 上传失败: {data.get('errors')}")
            return False
    else:
        print(f"❌ HTTP {resp.status_code}: {resp.text[:500]}")
        return False

def create_subdomain(config):
    """创建workers.dev子域名路由"""
    api_token = config["api_token"]
    account_id = config["account_id"]
    worker_name = config["worker_name"]
    
    print(f"🌐 创建子域名路由: {worker_name}.workers.dev")
    
    url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{worker_name}/subdomain"
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json",
    }
    data = {"subdomain": worker_name}
    
    resp = requests.put(url, headers=headers, json=data, timeout=30)
    
    if resp.status_code in (200, 201):
        result = resp.json()
        if result.get("success"):
            subdomain = result.get("result", {}).get("subdomain", worker_name)
            print(f"✅ 子域名已创建: {subdomain}.workers.dev")
            return f"https://{subdomain}.workers.dev"
    else:
        print(f"⚠️ 子域名创建失败（可能已存在）: HTTP {resp.status_code}")
        # 即使失败也返回默认地址
        return f"https://{worker_name}.workers.dev"
    
    return f"https://{worker_name}.workers.dev"

def test_deploy(worker_url):
    """测试部署是否成功"""
    print(f"\n🧪 测试部署: {worker_url}")
    try:
        resp = requests.get(worker_url, timeout=15)
        if resp.status_code == 200:
            print("✅ 部署成功，Worker正常响应")
            print(f"\n{'='*50}")
            print("📋 部署信息")
            print(f"{'='*50}")
            print(f"Worker地址: {worker_url}")
            print(f"TVBox配置: {worker_url}/tvbox.json")
            print(f"网站列表: {worker_url}/sites")
            print(f"首页测试: {worker_url}/?site=huangguo&action=home")
            print(f"{'='*50}")
            return True
        else:
            print(f"⚠️ HTTP {resp.status_code}")
            return False
    except Exception as e:
        print(f"⚠️ 测试失败: {e}")
        return False

def main():
    print("=" * 50)
    print("  tvbox影视 - 一键部署到Cloudflare Workers")
    print("=" * 50)
    print()
    
    # 加载配置
    if not os.path.exists(CONFIG_FILE):
        print(f"❌ 配置文件不存在: {CONFIG_FILE}")
        sys.exit(1)
    
    config = load_config()
    print(f"📋 配置: Worker名称={config['worker_name']}")
    print()
    
    # 部署Worker
    if not deploy_worker(config):
        print("\n❌ 部署失败")
        sys.exit(1)
    
    print()
    
    # 创建子域名
    worker_url = create_subdomain(config)
    
    # 等待几秒让部署生效
    print("\n⏳ 等待部署生效（5秒）...")
    import time
    time.sleep(5)
    
    # 测试
    test_deploy(worker_url)
    
    print("\n✅ 全部完成！")
    print(f"\n💡 在TVBox中配置地址: {worker_url}/tvbox.json")

if __name__ == "__main__":
    main()
