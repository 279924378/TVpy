/**
 * tvbox影视 - 聚合Worker（单文件版，直接部署）
 * 一个Worker支持多个影视网站，通过 ?site=xxx 参数区分
 * 
 * TVBox标准API：
 *   /?site=huangguo&action=home        首页
 *   /?site=huangguo&action=category&tid=recommend&pg=1  分类
 *   /?site=huangguo&action=detail&ids=123  详情
 *   /?site=huangguo&action=play&id=123#ep1  播放
 *   /?site=huangguo&action=search&wd=关键词  搜索
 *   /tvbox.json                     TVBox配置
 *   /sites                          已支持网站
 */

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ============ 工具函数 ============
async function fetchText(url, headers = {}) {
  const res = await fetch(url, {
    headers: { "User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9", ...headers }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
  return await res.text();
}

async function fetchJson(url, headers = {}) {
  return JSON.parse(await fetchText(url, headers));
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "public, max-age=300",
    },
  });
}

// ============ 网站1：黄果短剧 ============
const huangguo = {
  HOSTS: ["https://huangguoai.com", "https://ediayikma.cc"],
  CATEGORIES: [
    { name: "精选推荐", type: "page", slug: "recommend", pages: 2 },
    { name: "最近上新", type: "page", slug: "newest", pages: 2 },
    { name: "AI成人短剧", type: "api", slug: "ai-duanju", pages: 3 },
    { name: "AI成人漫剧", type: "api", slug: "ai-manju", pages: 3 },
    { name: "AI换脸", type: "api", slug: "ai-huanlian", pages: 3 },
    { name: "AI魔改", type: "api", slug: "ai-mogai", pages: 3 },
  ],

  async home(params) {
    const results = await Promise.all(this.CATEGORIES.map(cat => this._fetchCategory(cat)));
    const classes = this.CATEGORIES.map(cat => ({ type_id: cat.slug, type_name: cat.name }));
    const list = [];
    for (let i = 0; i < this.CATEGORIES.length; i++) {
      for (const item of results[i].slice(0, 12)) {
        list.push({ vod_id: item.id, vod_name: item.title, vod_pic: item.cover, vod_remarks: `全${item.epCount}集`, type_id: this.CATEGORIES[i].slug });
      }
    }
    return { class: classes, list };
  },

  async category(params) {
    const tid = params.get("tid") || "recommend";
    const pg = parseInt(params.get("pg") || "1");
    const cat = this.CATEGORIES.find(c => c.slug === tid) || this.CATEGORIES[0];
    const items = await this._fetchCategory(cat);
    const pageSize = 24, start = (pg - 1) * pageSize;
    return {
      page: pg, pagecount: Math.ceil(items.length / pageSize), limit: pageSize, total: items.length,
      list: items.slice(start, start + pageSize).map(i => ({ vod_id: i.id, vod_name: i.title, vod_pic: i.cover, vod_remarks: `全${i.epCount}集` })),
    };
  },

  async detail(params) {
    const ids = params.get("ids");
    let title = "未知", cover = "", epCount = 1;
    for (const path of [`/video/${ids}/ep-1/`, `/video/${ids}/ep1/`, `/video/${ids}/`]) {
      try {
        const html = await fetchText(`${this.HOSTS[0]}${path}`);
        const t = html.match(/<title>(.*?)<\/title>/); if (t) title = t[1].split("|")[0].trim();
        const c = html.match(/data-src="([^"]+)"/) || html.match(/src="([^"]+\.jpg)"/); if (c) cover = c[1];
        const e = html.match(/全(\d+)集/); if (e) epCount = parseInt(e[1]);
        break;
      } catch (e) { continue; }
    }
    const playList = [];
    for (let ep = 1; ep <= epCount; ep++) playList.push(`第${ep}集$${ids}#ep${ep}`);
    return { list: [{ vod_id: ids, vod_name: title, vod_pic: cover, vod_remarks: `全${epCount}集`, vod_play_from: "huangguo", vod_play_url: playList.join("#") }] };
  },

  async play(params) {
    const id = params.get("id");
    const parts = id.split("#ep");
    const vodId = parts[0], ep = parts[1] || "1";
    for (const path of [`/video/${vodId}/ep-${ep}/`, `/video/${vodId}/ep${ep}/`, `/video/${vodId}/p${ep}/`, `/video/${vodId}/`]) {
      try {
        const html = await fetchText(`${this.HOSTS[0]}${path}`);
        const jm = html.match(/<script id="videoInitialData" type="application\/json">(.*?)<\/script>/s);
        if (jm && jm[1]) {
          try {
            const d = JSON.parse(jm[1]);
            let url = d.videoSrc || d.videoUrl || d.playUrl || d.src;
            if (!url && d.epPlaySrcs) url = d.epPlaySrcs[ep] || d.epPlaySrcs[String(ep)] || Object.values(d.epPlaySrcs)[0];
            if (url) {
              url = url.replace(/\\u0026/g, "&").replace(/&amp;/g, "&").trim();
              return { url: url.startsWith("//") ? "https:" + url : url };
            }
          } catch (e) {}
        }
        const sm = html.match(/data-play-src="(https?:\/\/[^"]+)"/);
        if (sm && sm[1]) return { url: sm[1] };
      } catch (e) { continue; }
    }
    throw new Error("播放地址未找到");
  },

  async search(params) {
    const wd = params.get("wd") || "", pg = parseInt(params.get("pg") || "1");
    try {
      const data = await fetchJson(`${this.HOSTS[0]}/api/search?keyword=${encodeURIComponent(wd)}&page=${pg}`);
      const items = data?.data?.items || data?.items || [];
      return { page: pg, pagecount: 1, limit: 24, total: items.length, list: items.map(i => ({ vod_id: String(i.id), vod_name: i.title, vod_pic: i.cover || "", vod_remarks: i.episode_count ? `全${i.episode_count}集` : "" })) };
    } catch (e) {
      return { page: pg, pagecount: 0, limit: 24, total: 0, list: [] };
    }
  },

  async _fetchCategory(cat) {
    const promises = [];
    for (let p = 1; p <= cat.pages; p++) {
      promises.push(cat.type === "api" ? this._fetchApiPage(cat.slug, p) : this._fetchHtmlPage(cat.slug, p));
    }
    const all = (await Promise.all(promises)).flat();
    const seen = new Set();
    return all.filter(i => { if (!i.id || seen.has(i.id)) return false; seen.add(i.id); return true; });
  },

  async _fetchApiPage(slug, page) {
    try {
      const data = await fetchJson(`${this.HOSTS[0]}/api/videos/category/${slug}?sort=hot&page=${page}&size=24`);
      return (data?.data?.items || []).map(i => ({ id: String(i.id), title: i.title?.trim() || "未命名", cover: i.cover || "", epCount: parseInt(i.episode_count || 1) }));
    } catch (e) { return []; }
  },

  async _fetchHtmlPage(slug, page) {
    try {
      const html = await fetchText(`${this.HOSTS[0]}/${slug}/${page}/`);
      const items = [], blocks = html.split('<div class="hg-drama-card"');
      for (let i = 1; i < blocks.length; i++) {
        const b = blocks[i];
        const id = b.match(/href="\/detail\/(\d+)\/?"/)?.[1]; if (!id) continue;
        const title = b.match(/alt="([^"]+)"/)?.[1]?.trim() || "短剧";
        const cover = b.match(/data-src="([^"]+)"/)?.[1] || b.match(/src="([^"]+)"/)?.[1] || "";
        const epCount = parseInt(b.match(/class="hg-drama-card__episode">[^0-9]*(\d+)[^<]*</)?.[1] || 1);
        items.push({ id, title, cover, epCount });
      }
      return items;
    } catch (e) { return []; }
  },
};

// ============ 网站注册表 ============
const SITES = {
  huangguo: { name: "黄果短剧", type: "drama", handler: huangguo },
  // 新增网站在这里注册
};

// ============ 主路由 ============
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const params = url.searchParams;

    // 首页
    if (path === "/" && !params.get("site")) {
      return new Response(
        `tvbox影视 聚合Worker运行中\n\n` +
        `已支持网站: ${Object.keys(SITES).length}个\n` +
        Object.entries(SITES).map(([k, v]) => `  - ${k}: ${v.name}`).join("\n") +
        `\n\nTVBox配置: ${url.origin}/tvbox.json\n` +
        `网站列表: ${url.origin}/sites\n`,
        { headers: { "content-type": "text/plain; charset=utf-8" } }
      );
    }

    // 网站列表
    if (path === "/sites") {
      return jsonResponse({ total: Object.keys(SITES).length, sites: Object.entries(SITES).map(([k, v]) => ({ key: k, name: v.name, type: v.type })) });
    }

    // TVBox配置
    if (path === "/tvbox.json") {
      const spiderList = Object.entries(SITES).map(([key, site]) => ({
        key, name: site.name, type: site.type === "live" ? 3 : 1,
        api: `${url.origin}/?site=${key}&action=`,
      }));
      return jsonResponse({ spider: spiderList, sites: [], parses: [], lives: [], wallpaper: "", wallpaper_list: [] });
    }

    // TVBox API
    const siteKey = params.get("site"), action = params.get("action");
    if (!siteKey) return jsonResponse({ error: "缺少site参数", supported: Object.keys(SITES) }, 400);
    const site = SITES[siteKey];
    if (!site) return jsonResponse({ error: `不支持的网站: ${siteKey}`, supported: Object.keys(SITES) }, 400);

    try {
      let result;
      switch (action) {
        case "home": result = await site.handler.home(params); break;
        case "category": result = await site.handler.category(params); break;
        case "detail": result = await site.handler.detail(params); break;
        case "play": result = await site.handler.play(params); break;
        case "search": result = await site.handler.search(params); break;
        default: return jsonResponse({ error: `不支持的action: ${action}`, supported: ["home", "category", "detail", "play", "search"] }, 400);
      }
      return jsonResponse(result);
    } catch (e) {
      console.error(`[${siteKey}] ${action}:`, e);
      return jsonResponse({ error: e.message, site: siteKey, action }, 500);
    }
  },
};
