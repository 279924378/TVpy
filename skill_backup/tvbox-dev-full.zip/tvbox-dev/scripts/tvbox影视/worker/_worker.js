/**
 * tvbox影视 - 聚合Worker主文件
 * 一个Worker支持多个影视网站，通过 ?site=xxx 参数区分
 * 
 * TVBox标准API接口：
 *   /?site=xxx&action=home        首页推荐
 *   /?site=xxx&action=category&tid=xxx&pg=1   分类页
 *   /?site=xxx&action=detail&ids=xxx  详情页
 *   /?site=xxx&action=play&flag=xxx&id=xxx  播放地址
 *   /?site=xxx&action=search&wd=xxx&pg=1  搜索
 *   /tvbox.json                     生成TVBox配置
 *   /sites                          已支持网站列表
 */

// ============ 网站爬虫模块注册 ============
// 新增网站时，在下面import并注册
import huangguo from './sites/huangguo.js';

const SITES = {
  huangguo: {
    name: "黄果短剧",
    type: "drama",
    handler: huangguo,
  },
  // 新增网站在这里注册：
  // sitename: {
  //   name: "网站名称",
  //   type: "movie/drama/live",
  //   handler: siteHandler,
  // },
};

// ============ 工具函数 ============
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

async function fetchText(url, headers = {}) {
  const defaultHeaders = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    ...headers,
  };
  const res = await fetch(url, { headers: defaultHeaders });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
  return await res.text();
}

async function fetchJson(url, headers = {}) {
  const text = await fetchText(url, headers);
  return JSON.parse(text);
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "public, max-age=300",
    },
  });
}

// ============ TVBox标准API路由 ============
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const params = url.searchParams;

    // 健康检查
    if (path === "/" && !params.get("site")) {
      return new Response(
        `tvbox影视 聚合Worker运行中\n\n` +
        `已支持网站: ${Object.keys(SITES).length}个\n` +
        Object.entries(SITES).map(([k, v]) => `  - ${k}: ${v.name}`).join("\n") +
        `\n\nTVBox配置地址: ${url.origin}/tvbox.json\n` +
        `网站列表: ${url.origin}/sites\n`,
        { headers: { "content-type": "text/plain; charset=utf-8" } }
      );
    }

    // 网站列表
    if (path === "/sites") {
      const sites = Object.entries(SITES).map(([key, site]) => ({
        key,
        name: site.name,
        type: site.type,
      }));
      return jsonResponse({ total: sites.length, sites });
    }

    // 生成TVBox配置
    if (path === "/tvbox.json") {
      return generateTvboxConfig(url.origin);
    }

    // TVBox标准API
    const siteKey = params.get("site");
    const action = params.get("action");

    if (!siteKey) {
      return jsonResponse({ error: "缺少site参数", supported_sites: Object.keys(SITES) }, 400);
    }

    const site = SITES[siteKey];
    if (!site) {
      return jsonResponse({ error: `不支持的网站: ${siteKey}`, supported_sites: Object.keys(SITES) }, 400);
    }

    try {
      let result;
      switch (action) {
        case "home":
          result = await site.handler.home(params);
          break;
        case "category":
          result = await site.handler.category(params);
          break;
        case "detail":
          result = await site.handler.detail(params);
          break;
        case "play":
          result = await site.handler.play(params);
          break;
        case "search":
          result = await site.handler.search(params);
          break;
        default:
          return jsonResponse({ error: `不支持的action: ${action}`, supported: ["home", "category", "detail", "play", "search"] }, 400);
      }
      return jsonResponse(result);
    } catch (e) {
      console.error(`[${siteKey}] ${action} error:`, e);
      return jsonResponse({ error: e.message, site: siteKey, action }, 500);
    }
  },
};

// ============ 生成TVBox配置 ============
function generateTvboxConfig(origin) {
  const spiderList = Object.entries(SITES).map(([key, site]) => ({
    key: key,
    name: site.name,
    type: site.type === "live" ? 3 : 1,
    api: `${origin}/?site=${key}&action=`,
    // TVBox自定义spider格式
    ext: {
      site: key,
    },
  }));

  const config = {
    "spider": spiderList,
    "sites": [],
    "parses": [],
    "lives": [],
    "wallpaper": "",
    "wallpaper_list": [],
  };

  return jsonResponse(config);
}

// 导出工具函数供网站模块使用
export { fetchText, fetchJson, jsonResponse, UA };
