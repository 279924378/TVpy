/**
 * 黄果短剧 - 网站爬虫模块
 * 适配tvbox影视聚合Worker
 */

const HOSTS = ["https://huangguoai.com", "https://ediayikma.cc"];
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const CATEGORIES = [
  { name: "精选推荐", type: "page", slug: "recommend", pages: 2 },
  { name: "最近上新", type: "page", slug: "newest", pages: 2 },
  { name: "AI成人短剧", type: "api", slug: "ai-duanju", pages: 3 },
  { name: "AI成人漫剧", type: "api", slug: "ai-manju", pages: 3 },
  { name: "AI换脸", type: "api", slug: "ai-huanlian", pages: 3 },
  { name: "AI魔改", type: "api", slug: "ai-mogai", pages: 3 },
];

async function fetchText(url) {
  const res = await fetch(url, {
    headers: { "User-Agent": UA, "Referer": `${HOSTS[0]}/` }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.text();
}

async function fetchJson(url) {
  const text = await fetchText(url);
  return JSON.parse(text);
}

// ============ TVBox标准接口 ============

export default {
  // 首页
  async home(params) {
    const allItems = [];
    const categoryPromises = CATEGORIES.map(cat => fetchFullCategoryData(cat));
    const results = await Promise.all(categoryPromises);

    const classes = CATEGORIES.map((cat, i) => ({
      type_id: cat.slug,
      type_name: cat.name,
    }));

    const list = [];
    for (let i = 0; i < CATEGORIES.length; i++) {
      const items = results[i].slice(0, 12);
      for (const item of items) {
        list.push({
          vod_id: item.id,
          vod_name: item.title,
          vod_pic: item.cover,
          vod_remarks: `全${item.epCount}集`,
          type_id: CATEGORIES[i].slug,
        });
      }
    }

    return { class: classes, list };
  },

  // 分类页
  async category(params) {
    const tid = params.get("tid") || "recommend";
    const pg = parseInt(params.get("pg") || "1");
    const cat = CATEGORIES.find(c => c.slug === tid) || CATEGORIES[0];

    const items = await fetchFullCategoryData(cat);
    const pageSize = 24;
    const start = (pg - 1) * pageSize;
    const pageItems = items.slice(start, start + pageSize);

    return {
      page: pg,
      pagecount: Math.ceil(items.length / pageSize),
      limit: pageSize,
      total: items.length,
      list: pageItems.map(item => ({
        vod_id: item.id,
        vod_name: item.title,
        vod_pic: item.cover,
        vod_remarks: `全${item.epCount}集`,
      })),
    };
  },

  // 详情页
  async detail(params) {
    const ids = params.get("ids");
    const playPaths = [
      `/video/${ids}/ep-1/`,
      `/video/${ids}/ep1/`,
      `/video/${ids}/`,
    ];

    let title = "未知", cover = "", epCount = 1;
    for (const path of playPaths) {
      try {
        const html = await fetchText(`${HOSTS[0]}${path}`);
        const titleMatch = html.match(/<title>(.*?)<\/title>/);
        if (titleMatch) title = titleMatch[1].split("|")[0].trim();
        const imgMatch = html.match(/data-src="([^"]+)"/) || html.match(/src="([^"]+\.jpg)"/);
        if (imgMatch) cover = imgMatch[1];
        const epMatch = html.match(/全(\d+)集/);
        if (epMatch) epCount = parseInt(epMatch[1]);
        break;
      } catch (e) { continue; }
    }

    const playList = [];
    for (let ep = 1; ep <= epCount; ep++) {
      playList.push(`第${ep}集$${ids}#ep${ep}`);
    }

    return {
      list: [{
        vod_id: ids,
        vod_name: title,
        vod_pic: cover,
        vod_remarks: `全${epCount}集`,
        vod_play_from: "huangguo",
        vod_play_url: playList.join("#"),
      }]
    };
  },

  // 播放地址
  async play(params) {
    const id = params.get("id");
    const flag = params.get("flag");

    // 解析 id 格式: "视频ID#ep集数"
    const parts = id.split("#ep");
    const vodId = parts[0];
    const ep = parts[1] || "1";

    const playPaths = [
      `/video/${vodId}/ep-${ep}/`,
      `/video/${vodId}/ep${ep}/`,
      `/video/${vodId}/p${ep}/`,
      `/video/${vodId}/`,
    ];

    for (const path of playPaths) {
      try {
        const html = await fetchText(`${HOSTS[0]}${path}`);

        // 从JSON数据提取m3u8
        const jsonMatch = html.match(/<script id="videoInitialData" type="application\/json">(.*?)<\/script>/s);
        if (jsonMatch && jsonMatch[1]) {
          try {
            const jsonData = JSON.parse(jsonMatch[1]);
            let m3u8Url = jsonData.videoSrc || jsonData.videoUrl || jsonData.playUrl || jsonData.src;
            if (!m3u8Url && jsonData.epPlaySrcs) {
              m3u8Url = jsonData.epPlaySrcs[ep] || jsonData.epPlaySrcs[String(ep)] || Object.values(jsonData.epPlaySrcs)[0];
            }
            if (m3u8Url) {
              const clean = m3u8Url.replace(/\\u0026/g, "&").replace(/&amp;/g, "&").trim();
              const url = clean.startsWith("//") ? "https:" + clean : clean;
              return { url };
            }
          } catch (e) {}
        }

        // 从HTML属性提取
        const srcMatch = html.match(/data-play-src="(https?:\/\/[^"]+)"/);
        if (srcMatch && srcMatch[1]) {
          return { url: srcMatch[1] };
        }
      } catch (e) { continue; }
    }

    throw new Error("播放地址未找到");
  },

  // 搜索
  async search(params) {
    const wd = params.get("wd") || "";
    const pg = parseInt(params.get("pg") || "1");

    // 黄果短剧搜索API（如果有），否则从分类中过滤
    try {
      const searchUrl = `${HOSTS[0]}/api/search?keyword=${encodeURIComponent(wd)}&page=${pg}`;
      const data = await fetchJson(searchUrl);
      const items = data?.data?.items || data?.items || [];
      return {
        page: pg,
        pagecount: 1,
        limit: 24,
        total: items.length,
        list: items.map(it => ({
          vod_id: String(it.id),
          vod_name: it.title,
          vod_pic: it.cover || "",
          vod_remarks: it.episode_count ? `全${it.episode_count}集` : "",
        })),
      };
    } catch (e) {
      // 搜索失败返回空
      return { page: pg, pagecount: 0, limit: 24, total: 0, list: [] };
    }
  },
};

// ============ 内部函数 ============

async function fetchFullCategoryData(cat) {
  const pagePromises = [];
  for (let p = 1; p <= cat.pages; p++) {
    if (cat.type === "api") {
      pagePromises.push(fetchApiPage(cat.slug, p));
    } else {
      pagePromises.push(fetchHtmlPage(cat.slug, p));
    }
  }

  const pagesData = await Promise.all(pagePromises);
  const combined = pagesData.flat();

  const seen = new Set();
  return combined.filter(item => {
    if (!item.id || seen.has(item.id)) return false;
    seen.add(item.id);
    return true;
  });
}

async function fetchApiPage(slug, page) {
  const url = `${HOSTS[0]}/api/videos/category/${slug}?sort=hot&page=${page}&size=24`;
  try {
    const data = await fetchJson(url);
    const items = data?.data?.items || [];
    return items.map(it => ({
      id: String(it.id),
      title: it.title ? it.title.trim() : "未命名",
      cover: it.cover || "",
      epCount: parseInt(it.episode_count || 1),
    }));
  } catch (e) {
    return [];
  }
}

async function fetchHtmlPage(slug, page) {
  const url = `${HOSTS[0]}/${slug}/${page}/`;
  try {
    const html = await fetchText(url);
    const items = [];
    const blocks = html.split('<div class="hg-drama-card"');

    for (let i = 1; i < blocks.length; i++) {
      const block = blocks[i];
      const idMatch = block.match(/href="\/detail\/(\d+)\/?"/);
      if (!idMatch) continue;

      const id = idMatch[1];
      const titleMatch = block.match(/alt="([^"]+)"/);
      const title = titleMatch ? titleMatch[1].trim() : "短剧";
      const imgMatch = block.match(/data-src="([^"]+)"/) || block.match(/src="([^"]+)"/);
      const cover = imgMatch ? imgMatch[1] : "";
      const epMatch = block.match(/class="hg-drama-card__episode">[^0-9]*(\d+)[^<]*</);
      const epCount = epMatch ? parseInt(epMatch[1]) : 1;

      items.push({ id, title, cover, epCount });
    }
    return items;
  } catch (e) {
    return [];
  }
}
