/**
 * 段德机器人 - Cloudflare Workers 订阅鉴权服务
 * 
 * 功能：
 * 1. JWT风格Token验证（无状态，不需要数据库）
 * 2. 验证用户是否在Telegram群里（退群立马失效）
 * 3. 验证通过后反向代理到GitHub raw地址
 * 4. 记录访问日志（控制台输出）
 * 
 * 部署：Cloudflare Workers
 * 访问地址：https://<your-worker>.<your-account>.workers.dev/tvbox.json?token=xxx
 */

// ==================== 配置（部署时修改这些值）====================
const CONFIG = {
  // 共享密钥（必须和机器人端一致，用于Token签名验证）
  SECRET: 'your-secret-key-change-this-to-random-string',
  
  // Telegram Bot Token
  BOT_TOKEN: 'your-telegram-bot-token',
  
  // 目标群 chat_id
  CHAT_ID: '-1003795519678',
  
  // GitHub仓库信息（tvbox.json所在仓库）
  GITHUB_REPO: 'jwarrenrzflynn/TVpy',
  GITHUB_BRANCH: 'main',
  GITHUB_FILE: 'tvbox.json',
  
  // Token有效期（小时）
  TOKEN_VALID_HOURS: 24,
};

// ==================== 工具函数 ====================

/**
 * HMAC-SHA256 签名
 */
async function hmacSha256(message, secret) {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const messageData = encoder.encode(message);
  
  const key = await crypto.subtle.importKey(
    'raw', keyData, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const signature = await crypto.subtle.sign('HMAC', key, messageData);
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}

/**
 * Base64 URL 安全编码/解码
 */
function base64UrlEncode(str) {
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  return atob(str);
}

/**
 * 生成Token（机器人端调用，Worker端只验证）
 * Token格式: base64Url(payload).signature
 * payload: { userId, username, expires }
 */
async function generateToken(userId, username) {
  const expires = Date.now() + CONFIG.TOKEN_VALID_HOURS * 60 * 60 * 1000;
  const payload = JSON.stringify({ userId, username, expires });
  const payloadB64 = base64UrlEncode(payload);
  const signature = await hmacSha256(payloadB64, CONFIG.SECRET);
  return `${payloadB64}.${signature}`;
}

/**
 * 验证Token
 * 返回: { valid, message, payload }
 */
async function verifyToken(token) {
  if (!token || !token.includes('.')) {
    return { valid: false, message: '无效的Token格式' };
  }
  
  const [payloadB64, signature] = token.split('.');
  
  // 验证签名
  const expectedSignature = await hmacSha256(payloadB64, CONFIG.SECRET);
  if (signature !== expectedSignature) {
    return { valid: false, message: 'Token签名验证失败' };
  }
  
  // 解码payload
  try {
    const payload = JSON.parse(base64UrlDecode(payloadB64));
    
    // 验证过期
    if (Date.now() > payload.expires) {
      return { valid: false, message: 'Token已过期，请重新获取' };
    }
    
    return { valid: true, payload };
  } catch (e) {
    return { valid: false, message: 'Token解析失败' };
  }
}

/**
 * 检查用户是否在Telegram群里
 */
async function checkUserInGroup(userId) {
  const url = `https://api.telegram.org/bot${CONFIG.BOT_TOKEN}/getChatMember?chat_id=${CONFIG.CHAT_ID}&user_id=${userId}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.ok) {
      const status = data.result.status;
      // creator/administrator/member/restricted 都算在群里
      // left/kicked 算不在群里
      return ['creator', 'administrator', 'member', 'restricted'].includes(status);
    }
    return false;
  } catch (e) {
    console.error('检查群成员失败:', e);
    return true; // API调用失败时放行，避免误杀
  }
}

/**
 * 从GitHub获取tvbox.json内容
 */
async function fetchTvboxJson() {
  const url = `https://raw.githubusercontent.com/${CONFIG.GITHUB_REPO}/${CONFIG.GITHUB_BRANCH}/${CONFIG.GITHUB_FILE}`;
  
  try {
    const response = await fetch(url, {
      headers: { 'User-Agent': 'TVBox-Auth-Worker' }
    });
    
    if (!response.ok) {
      return null;
    }
    
    return await response.text();
  } catch (e) {
    console.error('获取tvbox.json失败:', e);
    return null;
  }
}

/**
 * JSON响应
 */
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-cache',
      'Access-Control-Allow-Origin': '*',
    }
  });
}

// ==================== 主请求处理 ====================

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const token = url.searchParams.get('token');
    const clientIP = request.headers.get('CF-Connecting-IP') || 'unknown';
    const userAgent = request.headers.get('User-Agent') || 'unknown';
    
    console.log(`[访问] IP: ${clientIP}, 路径: ${path}, Token: ${token ? '有' : '无'}`);
    
    // ========== 路由1: /tvbox.json 或 /subscribe - 订阅地址鉴权 ==========
    if (path === '/tvbox.json' || path === '/subscribe') {
      // 1. 检查Token
      if (!token) {
        return jsonResponse({ error: '缺少订阅Token，请在群里向机器人发送 /subscribe 获取' }, 401);
      }
      
      // 2. 验证Token
      const { valid, message, payload } = await verifyToken(token);
      if (!valid) {
        console.log(`[拒绝] Token验证失败: ${message}, IP: ${clientIP}`);
        return jsonResponse({ error: message }, 403);
      }
      
      // 3. 【铁律】检查用户是否在群里
      const inGroup = await checkUserInGroup(payload.userId);
      if (!inGroup) {
        console.log(`[拒绝] 用户已退群: ${payload.userId} (${payload.username}), IP: ${clientIP}`);
        return jsonResponse({ error: '您已不在群里，订阅地址已失效，请重新入群后获取' }, 403);
      }
      
      // 4. 获取tvbox.json内容
      const content = await fetchTvboxJson();
      if (!content) {
        return jsonResponse({ error: '获取订阅内容失败，请稍后重试' }, 502);
      }
      
      // 5. 返回订阅内容
      console.log(`[通过] 用户: ${payload.username} (${payload.userId}), IP: ${clientIP}`);
      return new Response(content, {
        status: 200,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-cache',
          'Access-Control-Allow-Origin': '*',
        }
      });
    }
    
    // ========== 路由2: /status - 服务状态 ==========
    if (path === '/status') {
      return jsonResponse({
        service: '段德机器人订阅鉴权服务 (Cloudflare Workers)',
        status: 'running',
        token_valid_hours: CONFIG.TOKEN_VALID_HOURS,
        github_repo: CONFIG.GITHUB_REPO,
        chat_id: CONFIG.CHAT_ID,
        time: new Date().toISOString(),
      });
    }
    
    // ========== 路由3: /generate - 生成Token（测试用，实际由机器人生成） ==========
    if (path === '/generate') {
      const userId = url.searchParams.get('user_id') || 'test_user';
      const username = url.searchParams.get('username') || '测试用户';
      const token = await generateToken(userId, username);
      const subscribeUrl = `${url.origin}/tvbox.json?token=${token}`;
      return jsonResponse({
        token,
        subscribe_url: subscribeUrl,
        expires_in_hours: CONFIG.TOKEN_VALID_HOURS,
      });
    }
    
    // ========== 路由4: /verify - 验证Token（测试用） ==========
    if (path === '/verify') {
      const { valid, message, payload } = await verifyToken(token);
      return jsonResponse({ valid, message, payload });
    }
    
    // ========== 默认：404 ==========
    return jsonResponse({ 
      error: '页面不存在',
      usage: {
        subscribe: '/tvbox.json?token=你的Token',
        status: '/status',
      }
    }, 404);
  },
};
