#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
段德机器人 - 订阅地址鉴权服务
功能：
1. 机器人生成带用户Token的订阅链接
2. 访问订阅时验证Token有效性
3. 记录访问IP，异常IP封禁
4. 只有群成员能获取有效Token
"""

import http.server
import json
import os
import sys
import sqlite3
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from urllib.parse import urlparse, parse_qs

# 项目路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "bot_data.db")
CONFIG_PATH = os.path.join(SCRIPT_DIR, "tg_config.json")

# 加载配置
def load_config():
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

CONFIG = load_config()
GITHUB_TOKEN = CONFIG.get('github_token', '')
GITHUB_REPO = CONFIG.get('github_repo', 'jwarrenrzflynn/TVpy')
GITHUB_BRANCH = CONFIG.get('github_branch', 'main')
BOT_TOKEN = CONFIG.get('bot', {}).get('token', '')
CHAT_ID = CONFIG.get('bot', {}).get('chat_id', '-1003795519678')
HTTP_PROXY = CONFIG.get('http_proxy', '')

# 鉴权Token有效期（小时）
TOKEN_VALID_HOURS = 24

# 封禁IP列表（内存+数据库持久化）
BANNED_IPS = set()


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init_auth_tables():
    """初始化鉴权相关表"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 鉴权Token表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS auth_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT UNIQUE,
        user_id TEXT,
        username TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at TIMESTAMP,
        is_active INTEGER DEFAULT 1,
        use_count INTEGER DEFAULT 0,
        last_used_at TIMESTAMP
    )
    ''')
    
    # 访问日志表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS access_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT,
        user_id TEXT,
        ip_address TEXT,
        user_agent TEXT,
        access_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT,
        detail TEXT
    )
    ''')
    
    # 封禁IP表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS banned_ips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT UNIQUE,
        reason TEXT,
        banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        banned_by TEXT
    )
    ''')
    
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_auth_token ON auth_tokens(token)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_access_ip ON access_logs(ip_address)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_banned_ip ON banned_ips(ip_address)')
    
    conn.commit()
    
    # 加载封禁IP到内存
    cursor.execute("SELECT ip_address FROM banned_ips")
    for row in cursor.fetchall():
        BANNED_IPS.add(row['ip_address'])
    
    conn.close()
    print(f"[鉴权服务] 数据库表初始化完成，已加载 {len(BANNED_IPS)} 个封禁IP")


def generate_token(user_id, username):
    """生成鉴权Token"""
    import secrets
    token = secrets.token_urlsafe(32)
    expires_at = (datetime.now() + timedelta(hours=TOKEN_VALID_HOURS)).strftime('%Y-%m-%d %H:%M:%S')
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO auth_tokens (token, user_id, username, expires_at)
                      VALUES (?, ?, ?, ?)''', (token, str(user_id), username, expires_at))
    conn.commit()
    conn.close()
    
    return token, expires_at


def check_user_in_group(user_id):
    """检查用户是否在群里（退群立马失效）"""
    if not BOT_TOKEN or not CHAT_ID:
        return True  # 配置缺失时放行（避免误杀）
    
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember?chat_id={CHAT_ID}&user_id={user_id}"
    
    proxy_handler = urllib.request.ProxyHandler({'http': HTTP_PROXY, 'https': HTTP_PROXY}) if HTTP_PROXY else urllib.request.ProxyHandler({})
    opener = urllib.request.build_opener(proxy_handler)
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Auth-Server'})
        with opener.open(req, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get('ok'):
                status = data['result']['status']
                # creator/administrator/member/restricted 都算在群里
                # left/kicked 算不在群里
                return status in ('creator', 'administrator', 'member', 'restricted')
            return False
    except Exception as e:
        print(f"[鉴权服务] 检查群成员失败: {e}")
        return True  # API调用失败时放行，避免误杀


def verify_token(token, ip_address):
    """验证Token有效性"""
    # 检查IP是否被封禁
    if ip_address in BANNED_IPS:
        return False, "IP已被封禁", None
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM auth_tokens WHERE token=? AND is_active=1", (token,))
    token_data = cursor.fetchone()
    
    if not token_data:
        log_access(token, "", ip_address, "invalid_token", "Token不存在或已失效")
        conn.close()
        return False, "无效的订阅Token", None
    
    # 检查是否过期
    expires_at = datetime.strptime(token_data['expires_at'], '%Y-%m-%d %H:%M:%S')
    if datetime.now() > expires_at:
        cursor.execute("UPDATE auth_tokens SET is_active=0 WHERE id=?", (token_data['id'],))
        conn.commit()
        log_access(token, token_data['user_id'], ip_address, "expired", "Token已过期")
        conn.close()
        return False, "订阅Token已过期，请重新获取", None
    
    # 【铁律】检查用户是否还在群里，不在群里立马失效
    user_id = token_data['user_id']
    in_group = check_user_in_group(user_id)
    if not in_group:
        cursor.execute("UPDATE auth_tokens SET is_active=0 WHERE id=?", (token_data['id'],))
        conn.commit()
        log_access(token, user_id, ip_address, "not_in_group", "用户已退群，订阅立马失效")
        conn.close()
        return False, "您已不在群里，订阅地址已失效，请重新入群后获取", None
    
    # 更新使用计数
    cursor.execute('''UPDATE auth_tokens SET use_count=use_count+1, last_used_at=? 
                      WHERE id=?''', (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), token_data['id']))
    conn.commit()
    
    log_access(token, token_data['user_id'], ip_address, "success", "验证通过")
    conn.close()
    
    return True, "验证通过", token_data


def log_access(token, user_id, ip_address, status, detail=""):
    """记录访问日志"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO access_logs (token, user_id, ip_address, status, detail)
                      VALUES (?, ?, ?, ?, ?)''', (token, user_id, ip_address, status, detail))
    conn.commit()
    conn.close()


def ban_ip(ip_address, reason="", banned_by="system"):
    """封禁IP"""
    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute('''INSERT INTO banned_ips (ip_address, reason, banned_by)
                          VALUES (?, ?, ?)''', (ip_address, reason, banned_by))
        conn.commit()
        BANNED_IPS.add(ip_address)
        print(f"[鉴权服务] 已封禁IP: {ip_address}, 原因: {reason}")
        return True
    except sqlite3.IntegrityError:
        return False  # 已封禁
    finally:
        conn.close()


def fetch_tvbox_json():
    """从GitHub获取tvbox.json内容"""
    url = f"https://raw.githubusercontent.com/{GITHUB_REPO}/{GITHUB_BRANCH}/tvbox.json"
    
    proxy_handler = urllib.request.ProxyHandler({'http': HTTP_PROXY, 'https': HTTP_PROXY}) if HTTP_PROXY else urllib.request.ProxyHandler({})
    opener = urllib.request.build_opener(proxy_handler)
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'TVBox-Auth-Server'})
        with opener.open(req, timeout=30) as resp:
            return resp.read()
    except Exception as e:
        print(f"[鉴权服务] 获取tvbox.json失败: {e}")
        return None


class AuthHandler(http.server.BaseHTTPRequestHandler):
    """鉴权HTTP请求处理器"""
    
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        
        # 获取客户端IP
        client_ip = self.client_address[0]
        if 'X-Forwarded-For' in self.headers:
            client_ip = self.headers['X-Forwarded-For'].split(',')[0].strip()
        
        user_agent = self.headers.get('User-Agent', '')
        
        # 路由：/tvbox.json?token=xxx
        if path == '/tvbox.json' or path == '/subscribe':
            token = query.get('token', [''])[0]
            
            if not token:
                self.send_error(401, "缺少订阅Token，请在群里向机器人获取")
                return
            
            # 验证Token
            valid, message, token_data = verify_token(token, client_ip)
            
            if not valid:
                self.send_response(403)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({"error": message}, ensure_ascii=False).encode())
                return
            
            # 获取tvbox.json内容
            content = fetch_tvbox_json()
            if content:
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_error(502, "获取订阅内容失败，请稍后重试")
            return
        
        # 路由：/status - 服务状态
        elif path == '/status':
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM auth_tokens WHERE is_active=1")
            active_tokens = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM access_logs")
            total_access = cursor.fetchone()[0]
            conn.close()
            
            status = {
                "service": "段德机器人订阅鉴权服务",
                "status": "running",
                "active_tokens": active_tokens,
                "total_access": total_access,
                "banned_ips": len(BANNED_IPS),
                "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(json.dumps(status, ensure_ascii=False, indent=2).encode())
            return
        
        # 路由：/ban?ip=xxx&reason=xxx - 封禁IP（需要管理员Token）
        elif path == '/ban':
            admin_token = query.get('admin_token', [''])[0]
            ip_to_ban = query.get('ip', [''])[0]
            reason = query.get('reason', ['违规访问'])[0]
            
            # 简单管理员验证（实际应使用更安全的方式）
            if admin_token != BOT_TOKEN[:16]:
                self.send_error(403, "管理员验证失败")
                return
            
            if ip_to_ban:
                ban_ip(ip_to_ban, reason, "admin")
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "message": f"已封禁IP: {ip_to_ban}"}).encode())
            else:
                self.send_error(400, "缺少IP参数")
            return
        
        else:
            self.send_error(404, "页面不存在")
    
    def log_message(self, format, *args):
        # 简化日志输出
        print(f"[鉴权服务] {self.client_address[0]} - {args[0]}")


def main():
    """启动鉴权服务"""
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8888
    
    print("=" * 60)
    print("段德机器人 - 订阅地址鉴权服务")
    print("=" * 60)
    
    # 初始化数据库表
    init_auth_tables()
    
    # 启动HTTP服务
    server = http.server.HTTPServer(('0.0.0.0', port), AuthHandler)
    print(f"[鉴权服务] 已启动，监听端口: {port}")
    print(f"[鉴权服务] 订阅地址: http://<服务器IP>:{port}/tvbox.json?token=<你的Token>")
    print(f"[鉴权服务] 状态查询: http://<服务器IP>:{port}/status")
    print("=" * 60)
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[鉴权服务] 正在关闭...")
        server.shutdown()


if __name__ == "__main__":
    main()
