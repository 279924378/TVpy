(function () {
  'use strict';

  // ============ 配置 ============
  var BASE_URL = 'https://www.sbjys5.top';
  var SITE_PATH = '/cn/home/web';
  var UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1';

  var CATEGORIES = [
    { id: '1', name: '人妻熟女' },
    { id: '2', name: '强奸乱伦' },
    { id: '3', name: '制服师生' },
    { id: '4', name: '网红主播' },
    { id: '20', name: '偷拍自拍' },
    { id: '21', name: '自慰自淫' },
    { id: '22', name: '国产专区' },
    { id: '23', name: '虐待同性' },
    { id: '24', name: '日韩精品' },
    { id: '25', name: '欧美性爱' },
    { id: '26', name: '卡通动漫' },
    { id: '27', name: '三级伦理' },
  ];

  var HOT_TAGS = ['人妻熟女', '偷拍自拍', '日韩精品', '国产专区', '网红主播', '制服师生'];

  // ============ 状态 ============
  var state = {
    currentPage: 'feedPage',
    feedVideos: [],
    feedPage: 1,
    feedLoading: false,
    currentFeedIndex: -1,
    catId: '1',
    catPage: 1,
    catLoading: false,
    searchPage: 1,
    searchLoading: false,
    playerHls: null,
    playerTimer: null,
    playUrlCache: {},
    SPEEDS: [1.0, 1.25, 1.5, 2.0, 0.5],
    speedIndex: 0,
  };

  // ============ 工具函数 ============
  function $(id) { return document.getElementById(id); }

  function request(url) {
    return new Promise(function (resolve, reject) {
      if (typeof ant !== 'undefined' && ant.request) {
        ant.request({
          url: url,
          method: 'GET',
          headers: { 'User-Agent': UA, 'Referer': BASE_URL + '/' }
        }).then(function (res) {
          resolve(res.data || res.body || '');
        }).catch(reject);
      } else {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('User-Agent', UA);
        xhr.setRequestHeader('Referer', BASE_URL + '/');
        xhr.onload = function () {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(xhr.responseText);
          } else {
            reject(new Error('HTTP ' + xhr.status));
          }
        };
        xhr.onerror = function () { reject(new Error('Network error')); };
        xhr.send();
      }
    });
  }

  function parseVideoList(html) {
    var videos = [];
    if (!html) return videos;
    var parser = new DOMParser();
    var doc = parser.parseFromString(html, 'text/html');
    var blocks = doc.querySelectorAll('.video_B');
    if (blocks.length === 0) {
      // 尝试li.item结构
      var items = doc.querySelectorAll('li.item a[href*="vod/play"]');
      if (items.length > 0) {
        items.forEach(function (a) {
          var idMatch = a.getAttribute('href').match(/vod\/play\/id\/(\d+)/);
          var title = a.getAttribute('title') || '';
          var img = a.querySelector('img');
          var pic = img ? (img.getAttribute('src') || img.getAttribute('data-src') || '') : '';
          if (idMatch && title) {
            videos.push({ vod_id: idMatch[1], vod_name: title.trim(), vod_pic: pic });
          }
        });
        return videos;
      }
      // 备用正则
      var regex = /<a[^>]*href="[^"]*vod\/play\/id\/(\d+)[^"]*"[^>]*title="([^"]*)"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"/g;
      var m;
      while ((m = regex.exec(html)) !== null) {
        videos.push({ vod_id: m[1], vod_name: m[2].trim(), vod_pic: m[3] });
      }
      return videos;
    }
    blocks.forEach(function (block) {
      var link = block.querySelector('a[href*="vod/play"]');
      var img = block.querySelector('img');
      var titleEl = block.querySelector('.sml a') || block.querySelector('a[title]');
      var vod_id = '';
      var title = '';
      var pic = '';
      if (link) {
        var idMatch = link.getAttribute('href').match(/vod\/play\/id\/(\d+)/);
        if (idMatch) vod_id = idMatch[1];
        title = link.getAttribute('title') || '';
      }
      if (titleEl && !title) title = titleEl.textContent.trim();
      if (img) pic = img.getAttribute('src') || img.getAttribute('data-original') || '';
      if (vod_id && title) {
        videos.push({ vod_id: vod_id, vod_name: title, vod_pic: pic });
      }
    });
    return videos;
  }

  function parsePlayerData(html) {
    var match = html.match(/player_data\s*=\s*(\{[^{}]*\})/);
    if (match) {
      try {
        var data = JSON.parse(match[1]);
        return data.url || '';
      } catch (e) {
        var urlMatch = match[1].match(/"url"\s*:\s*"([^"]+)"/);
        if (urlMatch) return urlMatch[1].replace(/\\\//g, '/');
      }
    }
    return '';
  }

  function parseTitle(html) {
    var match = html.match(/<title>([^<]+)<\/title>/);
    if (match) {
      return match[1].replace(/-搜B研究所/g, '').replace(/在线播放/g, '').replace(/HD免费高清视频播放/g, '').trim();
    }
    return '';
  }

  function formatTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    var m = Math.floor(sec / 60);
    var s = Math.floor(sec % 60);
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  // ============ 页面导航 ============
  function showPage(pageId) {
    document.querySelectorAll('.page').forEach(function (p) { p.classList.remove('active'); });
    $(pageId).classList.add('active');
    state.currentPage = pageId;
    // 更新底部tab
    document.querySelectorAll('.tab-item').forEach(function (t) {
      t.classList.toggle('active', t.getAttribute('data-page') === pageId);
    });
  }

  document.querySelectorAll('.tab-item').forEach(function (tab) {
    tab.addEventListener('click', function () {
      var page = tab.getAttribute('data-page');
      showPage(page);
      if (page === 'categoryPage') loadCategory();
      if (page === 'minePage') loadMine();
    });
  });

  document.querySelectorAll('.back-btn[data-page]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      showPage(btn.getAttribute('data-page'));
    });
  });

  // ============ 首页视频流 ============
  function loadFeed() {
    if (state.feedLoading) return;
    state.feedLoading = true;
    $('feedLoading').style.display = 'block';
    var url = BASE_URL + SITE_PATH + '/index.php/vod/type/id/20.html';
    if (state.feedPage > 1) {
      url = BASE_URL + SITE_PATH + '/index.php/vod/type/id/20/page/' + state.feedPage + '.html';
    }
    request(url).then(function (html) {
      var videos = parseVideoList(html);
      state.feedVideos = state.feedVideos.concat(videos);
      renderFeedItems(videos);
      state.feedPage++;
      state.feedLoading = false;
      $('feedLoading').style.display = 'none';
      // 自动播放第一个
      if (state.currentFeedIndex < 0 && state.feedVideos.length > 0) {
        setTimeout(function () { playFeedAt(0); }, 300);
      }
    }).catch(function () {
      state.feedLoading = false;
      $('feedLoading').textContent = '加载失败，点击重试';
    });
  }

  function renderFeedItems(videos) {
    var container = $('feedContainer');
    var startIndex = container.children.length;
    videos.forEach(function (v, i) {
      var idx = startIndex + i;
      var item = document.createElement('div');
      item.className = 'feed-item';
      item.dataset.index = idx;
      item.innerHTML =
        '<img class="feed-cover" src="' + (v.vod_pic || '') + '" alt="">' +
        '<video class="feed-video" playsinline webkit-playsinline muted loop></video>' +
        '<div class="feed-center-play" data-idx="' + idx + '">' +
        '<svg viewBox="0 0 24 24" width="36" height="36" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></div>' +
        '<div class="feed-side">' +
        '<div class="feed-avatar"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>' +
        '<div class="feed-side-btn" data-action="like"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><span>0</span></div>' +
        '<div class="feed-side-btn" data-action="fav"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg><span>收藏</span></div>' +
        '<div class="feed-side-btn" data-action="share"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg><span>分享</span></div>' +
        '</div>' +
        '<div class="feed-bottom-info">' +
        '<div class="feed-author">@露思AV</div>' +
        '<div class="feed-desc">' + escapeHtml(v.vod_name) + '</div>' +
        '<div class="feed-music"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>原声</div>' +
        '</div>' +
        '<div class="feed-progress" id="feedProgress' + idx + '"></div>';
      container.appendChild(item);
    });
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function playFeedAt(index) {
    if (index < 0 || index >= state.feedVideos.length) return;
    // 暂停上一个
    if (state.currentFeedIndex >= 0) {
      var prevVideo = document.querySelector('.feed-item[data-index="' + state.currentFeedIndex + '"] video');
      if (prevVideo) { prevVideo.pause(); prevVideo.currentTime = 0; }
      var prevPlay = document.querySelector('.feed-item[data-index="' + state.currentFeedIndex + '"] .feed-center-play');
      if (prevPlay) prevPlay.style.display = 'flex';
    }
    state.currentFeedIndex = index;
    var video = document.querySelector('.feed-item[data-index="' + index + '"] video');
    var playBtn = document.querySelector('.feed-item[data-index="' + index + '"] .feed-center-play');
    var cover = document.querySelector('.feed-item[data-index="' + index + '"] .feed-cover');
    if (!video) return;
    var v = state.feedVideos[index];
    // 获取播放地址
    if (state.playUrlCache[v.vod_id]) {
      startFeedVideo(video, state.playUrlCache[v.vod_id], playBtn, cover, index);
    } else {
      var playUrl = BASE_URL + SITE_PATH + '/index.php/vod/play/id/' + v.vod_id + '/sid/1/nid/1.html';
      request(playUrl).then(function (html) {
        var m3u8 = parsePlayerData(html);
        if (m3u8) {
          state.playUrlCache[v.vod_id] = m3u8;
          startFeedVideo(video, m3u8, playBtn, cover, index);
        }
      }).catch(function () {});
    }
    // 预加载下一个
    preloadPlayUrls(index + 1, 2);
  }

  function startFeedVideo(video, url, playBtn, cover, index) {
    if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = url;
    } else if (typeof Hls !== 'undefined' && Hls.isSupported()) {
      if (video._hls) { video._hls.destroy(); }
      var hls = new Hls({ enableWorker: false, maxBufferLength: 10 });
      hls.loadSource(url);
      hls.attachMedia(video);
      video._hls = hls;
    }
    video.muted = true;
    video.play().then(function () {
      if (playBtn) playBtn.style.display = 'none';
      if (cover) cover.style.display = 'none';
    }).catch(function () {});
    // 进度条
    var progressBar = $('feedProgress' + index);
    video.ontimeupdate = function () {
      if (progressBar && video.duration) {
        progressBar.style.width = (video.currentTime / video.duration * 100) + '%';
      }
    };
  }

  function preloadPlayUrls(start, count) {
    for (var i = start; i < Math.min(start + count, state.feedVideos.length); i++) {
      var v = state.feedVideos[i];
      if (!state.playUrlCache[v.vod_id]) {
        (function (vodId) {
          var playUrl = BASE_URL + SITE_PATH + '/index.php/vod/play/id/' + vodId + '/sid/1/nid/1.html';
          request(playUrl).then(function (html) {
            var m3u8 = parsePlayerData(html);
            if (m3u8) state.playUrlCache[vodId] = m3u8;
          }).catch(function () {});
        })(v.vod_id);
      }
    }
  }

  // 滚动监听
  var feedScrollTimer = null;
  $('feedContainer').addEventListener('scroll', function () {
    var container = $('feedContainer');
    var idx = Math.round(container.scrollTop / container.clientHeight);
    if (idx !== state.currentFeedIndex && idx >= 0 && idx < state.feedVideos.length) {
      playFeedAt(idx);
    }
    // 加载更多
    if (container.scrollTop + container.clientHeight >= container.scrollHeight - container.clientHeight * 2) {
      loadFeed();
    }
  });

  // 点击播放/暂停
  document.addEventListener('click', function (e) {
    var centerPlay = e.target.closest('.feed-center-play');
    if (centerPlay) {
      var idx = parseInt(centerPlay.dataset.idx);
      var video = document.querySelector('.feed-item[data-index="' + idx + '"] video');
      if (video) {
        if (video.paused) {
          video.play();
          centerPlay.style.display = 'none';
        } else {
          video.pause();
          centerPlay.style.display = 'flex';
        }
      }
      return;
    }
    // 收藏
    var favBtn = e.target.closest('.feed-side-btn[data-action="fav"]');
    if (favBtn) {
      var v = state.feedVideos[state.currentFeedIndex];
      if (v) toggleFav(v);
      return;
    }
    // 视频卡片点击 → 全屏播放
    var card = e.target.closest('.video-card');
    if (card) {
      var vodId = card.dataset.vodId;
      var vodName = card.dataset.vodName;
      openFullPlayer(vodId, vodName);
      return;
    }
  });

  // 首页搜索按钮
  $('feedSearchBtn').addEventListener('click', function () { showPage('searchPage'); });

  // ============ 分类页 ============
  function renderCategoryTree() {
    var tree = $('treePrimary');
    tree.innerHTML = '';
    CATEGORIES.forEach(function (cat) {
      var item = document.createElement('div');
      item.className = 'tree-primary-item' + (cat.id === state.catId ? ' active' : '');
      item.textContent = cat.name;
      item.dataset.id = cat.id;
      item.addEventListener('click', function () {
        document.querySelectorAll('.tree-primary-item').forEach(function (i) { i.classList.remove('active'); });
        item.classList.add('active');
        state.catId = cat.id;
        state.catPage = 1;
        $('catGrid').innerHTML = '';
        loadCategory();
      });
      tree.appendChild(item);
    });
  }

  function loadCategory() {
    if (state.catLoading) return;
    if ($('treePrimary').children.length === 0) renderCategoryTree();
    state.catLoading = true;
    $('catLoading').style.display = 'block';
    var url = BASE_URL + SITE_PATH + '/index.php/vod/type/id/' + state.catId + '.html';
    if (state.catPage > 1) {
      url = BASE_URL + SITE_PATH + '/index.php/vod/type/id/' + state.catId + '/page/' + state.catPage + '.html';
    }
    request(url).then(function (html) {
      var videos = parseVideoList(html);
      renderVideoGrid($('catGrid'), videos);
      state.catPage++;
      state.catLoading = false;
      $('catLoading').style.display = 'none';
    }).catch(function () {
      state.catLoading = false;
      $('catLoading').textContent = '加载失败';
    });
  }

  // 分类页滚动加载
  var catScrollTimer = null;
  document.querySelector('.category-right').addEventListener('scroll', function () {
    var el = document.querySelector('.category-right');
    if (el.scrollTop + el.clientHeight >= el.scrollHeight - 200) {
      loadCategory();
    }
  });

  // ============ 视频网格渲染 ============
  function renderVideoGrid(container, videos) {
    videos.forEach(function (v) {
      var card = document.createElement('div');
      card.className = 'video-card';
      card.dataset.vodId = v.vod_id;
      card.dataset.vodName = v.vod_name;
      card.innerHTML =
        '<div class="video-card-pic">' +
        '<img src="' + (v.vod_pic || '') + '" alt="" loading="lazy">' +
        '<span class="video-badge">HD</span>' +
        '</div>' +
        '<div class="video-card-title">' + escapeHtml(v.vod_name) + '</div>';
      container.appendChild(card);
    });
  }

  // ============ 搜索页 ============
  function renderHotTags() {
    var cloud = $('tagCloud');
    cloud.innerHTML = '';
    HOT_TAGS.forEach(function (tag) {
      var item = document.createElement('div');
      item.className = 'tag-item';
      item.textContent = tag;
      item.addEventListener('click', function () {
        $('searchInput').value = tag;
        doSearch();
      });
      cloud.appendChild(item);
    });
  }

  function doSearch() {
    var kw = $('searchInput').value.trim();
    if (!kw) return;
    state.searchPage = 1;
    $('searchGrid').innerHTML = '';
    $('hotTags').style.display = 'none';
    $('searchLoading').style.display = 'block';
    performSearch(kw);
  }

  function performSearch(kw) {
    if (state.searchLoading) return;
    state.searchLoading = true;
    var encoded = encodeURIComponent(kw);
    var url = BASE_URL + SITE_PATH + '/index.php/vod/search/wd/' + encoded + '.html';
    if (state.searchPage > 1) {
      url = BASE_URL + SITE_PATH + '/index.php/vod/search/page/' + state.searchPage + '/wd/' + encoded + '.html';
    }
    request(url).then(function (html) {
      var videos = parseVideoList(html);
      renderVideoGrid($('searchGrid'), videos);
      state.searchPage++;
      state.searchLoading = false;
      $('searchLoading').style.display = 'none';
    }).catch(function () {
      state.searchLoading = false;
      $('searchLoading').textContent = '搜索失败';
    });
  }

  $('searchBtn').addEventListener('click', doSearch);
  $('searchInput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') doSearch();
  });

  // 搜索页滚动加载
  $('searchPage').addEventListener('scroll', function () {
    if ($('searchPage').scrollTop + $('searchPage').clientHeight >= $('searchPage').scrollHeight - 200) {
      var kw = $('searchInput').value.trim();
      if (kw) performSearch(kw);
    }
  });

  // ============ 我的页 ============
  function getFavs() {
    try { return JSON.parse(localStorage.getItem('lusi_favs') || '[]'); } catch (e) { return []; }
  }
  function saveFavs(favs) { localStorage.setItem('lusi_favs', JSON.stringify(favs)); }
  function toggleFav(v) {
    var favs = getFavs();
    var idx = favs.findIndex(function (f) { return f.vod_id === v.vod_id; });
    if (idx >= 0) {
      favs.splice(idx, 1);
      if (typeof ant !== 'undefined' && ant.ui) ant.ui.toast('已取消收藏');
    } else {
      favs.unshift(v);
      if (typeof ant !== 'undefined' && ant.ui) ant.ui.toast('已收藏');
    }
    saveFavs(favs);
  }
  function getHistory() {
    try { return JSON.parse(localStorage.getItem('lusi_history') || '[]'); } catch (e) { return []; }
  }
  function addHistory(v) {
    var history = getHistory();
    history = history.filter(function (h) { return h.vod_id !== v.vod_id; });
    history.unshift(v);
    if (history.length > 50) history = history.slice(0, 50);
    localStorage.setItem('lusi_history', JSON.stringify(history));
  }

  var currentMineTab = 'fav';
  document.querySelectorAll('.mine-tab').forEach(function (tab) {
    tab.addEventListener('click', function () {
      document.querySelectorAll('.mine-tab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      currentMineTab = tab.dataset.mtab;
      loadMine();
    });
  });

  function loadMine() {
    var grid = $('mineGrid');
    grid.innerHTML = '';
    var data = currentMineTab === 'fav' ? getFavs() : getHistory();
    if (data.length === 0) {
      $('mineEmpty').style.display = 'block';
    } else {
      $('mineEmpty').style.display = 'none';
      renderVideoGrid(grid, data);
    }
  }

  // ============ 全屏播放器 ============
  function openFullPlayer(vodId, vodName) {
    showPage('fullPlayerPage');
    $('playerTitle').textContent = vodName || '播放中';
    $('fullPlayerLoading').style.display = 'block';
    $('playerCenterPlay').style.display = 'none';
    var video = $('fullVideo');
    // 销毁旧hls
    if (state.playerHls) { state.playerHls.destroy(); state.playerHls = null; }
    // 添加历史
    addHistory({ vod_id: vodId, vod_name: vodName, vod_pic: '' });
    // 获取播放地址
    if (state.playUrlCache[vodId]) {
      startFullPlayer(state.playUrlCache[vodId]);
    } else {
      var playUrl = BASE_URL + SITE_PATH + '/index.php/vod/play/id/' + vodId + '/sid/1/nid/1.html';
      request(playUrl).then(function (html) {
        var m3u8 = parsePlayerData(html);
        if (m3u8) {
          state.playUrlCache[vodId] = m3u8;
          startFullPlayer(m3u8);
        } else {
          $('fullPlayerLoading').style.display = 'none';
          $('playerCenterPlay').style.display = 'flex';
          if (typeof ant !== 'undefined' && ant.ui) ant.ui.toast('无法获取播放地址');
        }
      }).catch(function () {
        $('fullPlayerLoading').style.display = 'none';
        $('playerCenterPlay').style.display = 'flex';
      });
    }
  }

  function startFullPlayer(url) {
    var video = $('fullVideo');
    if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = url;
    } else if (typeof Hls !== 'undefined' && Hls.isSupported()) {
      state.playerHls = new Hls({ enableWorker: false, maxBufferLength: 30 });
      state.playerHls.loadSource(url);
      state.playerHls.attachMedia(video);
    }
    video.load();
    var playPromise = video.play();
    if (playPromise) {
      playPromise.then(function () {
        $('fullPlayerLoading').style.display = 'none';
        $('playerCenterPlay').style.display = 'none';
        updatePlayIcon(true);
      }).catch(function () {
        // 自动播放失败，降级静音
        video.muted = true;
        video.play().then(function () {
          $('fullPlayerLoading').style.display = 'none';
          $('playerCenterPlay').style.display = 'none';
          updatePlayIcon(true);
        }).catch(function () {
          $('fullPlayerLoading').style.display = 'none';
          $('playerCenterPlay').style.display = 'flex';
        });
      });
    }
    // 20秒超时
    setTimeout(function () {
      if ($('fullPlayerLoading').style.display !== 'none') {
        $('fullPlayerLoading').style.display = 'none';
        $('playerCenterPlay').style.display = 'flex';
      }
    }, 20000);
  }

  function updatePlayIcon(playing) {
    $('playIcon').style.display = playing ? 'none' : 'block';
    $('pauseIcon').style.display = playing ? 'block' : 'none';
  }

  // 播放/暂停
  $('fullPlayPauseBtn').addEventListener('click', function () {
    var video = $('fullVideo');
    if (video.paused) {
      video.play();
      updatePlayIcon(true);
      $('playerCenterPlay').style.display = 'none';
    } else {
      video.pause();
      updatePlayIcon(false);
      $('playerCenterPlay').style.display = 'flex';
    }
  });

  // 中央播放按钮
  $('playerCenterPlay').addEventListener('click', function () {
    $('fullVideo').play();
    $('playerCenterPlay').style.display = 'none';
    updatePlayIcon(true);
  });

  // 进度条
  var video = $('fullVideo');
  video.addEventListener('timeupdate', function () {
    if (video.duration) {
      $('fullPlayed').style.width = (video.currentTime / video.duration * 100) + '%';
      $('fullThumb').style.left = (video.currentTime / video.duration * 100) + '%';
      $('fullTime').textContent = formatTime(video.currentTime) + ' / ' + formatTime(video.duration);
    }
  });
  video.addEventListener('progress', function () {
    if (video.buffered.length > 0 && video.duration) {
      $('fullBuffered').style.width = (video.buffered.end(video.buffered.length - 1) / video.duration * 100) + '%';
    }
  });
  video.addEventListener('play', function () { updatePlayIcon(true); $('playerCenterPlay').style.display = 'none'; });
  video.addEventListener('pause', function () { updatePlayIcon(false); });
  video.addEventListener('waiting', function () { $('fullPlayerLoading').style.display = 'block'; });
  video.addEventListener('playing', function () { $('fullPlayerLoading').style.display = 'none'; });

  // 进度条点击和拖拽
  var isDragging = false;
  function seekFromEvent(e) {
    var bar = $('fullProgressBar');
    var rect = bar.getBoundingClientRect();
    var clientX = e.touches ? e.touches[0].clientX : e.clientX;
    var pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    if (video.duration) {
      video.currentTime = pct * video.duration;
      $('fullPlayed').style.width = (pct * 100) + '%';
      $('fullThumb').style.left = (pct * 100) + '%';
    }
  }
  $('fullProgressBar').addEventListener('click', seekFromEvent);
  $('fullProgressBar').addEventListener('touchstart', function (e) { isDragging = true; seekFromEvent(e); });
  document.addEventListener('touchmove', function (e) { if (isDragging) seekFromEvent(e); });
  document.addEventListener('touchend', function () { isDragging = false; });

  // 倍速
  $('fullSpeedBtn').addEventListener('click', function () {
    state.speedIndex = (state.speedIndex + 1) % state.SPEEDS.length;
    video.playbackRate = state.SPEEDS[state.speedIndex];
    $('fullSpeedBtn').textContent = state.SPEEDS[state.speedIndex] + 'x';
  });

  // 静音
  $('fullMuteBtn').addEventListener('click', function () {
    video.muted = !video.muted;
    $('fullMuteBtn').style.opacity = video.muted ? '0.5' : '1';
  });

  // 返回
  $('playerBackBtn').addEventListener('click', function () {
    video.pause();
    if (state.playerHls) { state.playerHls.destroy(); state.playerHls = null; }
    showPage('feedPage');
  });

  // ============ 页面可见性 ============
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      video.pause();
      document.querySelectorAll('.feed-video').forEach(function (v) { v.pause(); });
    } else {
      if (state.currentPage === 'feedPage' && state.currentFeedIndex >= 0) {
        var fv = document.querySelector('.feed-item[data-index="' + state.currentFeedIndex + '"] video');
        if (fv) fv.play().catch(function () {});
      }
    }
  });

  // ============ TV遥控器 ============
  if (typeof ant !== 'undefined' && ant.tv && ant.tv.onKey) {
    ant.tv.onKey(function (event) {
      var focusable = Array.prototype.slice.call(document.querySelectorAll('.video-card, .tab-item, .tree-primary-item, .tag-item, button, input, .ctrl-btn'));
      if (!focusable.length) return;
      var index = focusable.indexOf(document.activeElement);
      if (event.key === 'ArrowDown' || event.key === 'ArrowRight') {
        index = (index + 1) % focusable.length;
      } else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
        index = index <= 0 ? focusable.length - 1 : index - 1;
      } else if (event.key === 'Enter' || event.key === 'Select') {
        if (document.activeElement) document.activeElement.click();
        return;
      } else { return; }
      focusable[index].focus();
      focusable[index].scrollIntoView({ block: 'nearest' });
    });
  }

  // ============ 初始化 ============
  renderHotTags();
  loadFeed();

  // 环境信息
  if (typeof ant !== 'undefined' && ant.env) {
    ant.env.getSystemInfo().then(function (info) {
      if (info.isTV) document.body.classList.add('tv');
    }).catch(function () {});
  }

})();
