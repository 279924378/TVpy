#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TVBox远程订阅HTTP服务器
提供 tvbox.json 配置文件和 py 文件下载
用法: python3 tvbox_subscribe_server.py [端口]
"""

import http.server
import socketserver
import os
import sys
import json
import urllib.parse
import time
import uuid

# 订阅目录（项目根目录下的tvbox_subscribe）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
SUBSCRIBE_DIR = os.path.join(PROJECT_DIR, "tvbox_subscribe")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8888

# 鉴权token存储文件
TOKEN_FILE = os.path.join(SCRIPT_DIR, "subscribe_tokens.json")
# token有效期（秒），默认7天
TOKEN_EXPIRE = 7 * 24 * 3600


def load_tokens():
    """加载有效token列表"""
    if not os.path.isfile(TOKEN_FILE):
        return {}
    try:
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_tokens(tokens):
    """保存token列表"""
    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
        json.dump(tokens, f, ensure_ascii=False, indent=2)


def generate_token(user_id, user_name):
    """生成新的鉴权token"""
    tokens = load_tokens()
    # 清理过期token
    now = time.time()
    tokens = {k: v for k, v in tokens.items() if v.get("expire", 0) > now}
    # 检查该用户是否已有有效token，有则复用
    for tok, info in tokens.items():
        if info.get("user_id") == str(user_id) and info.get("expire", 0) > now:
            return tok
    # 生成新token
    new_token = uuid.uuid4().hex[:16]
    tokens[new_token] = {
        "user_id": str(user_id),
        "user_name": user_name,
        "created": now,
        "expire": now + TOKEN_EXPIRE,
    }
    save_tokens(tokens)
    return new_token


def verify_token(token):
    """验证token是否有效，返回(是否有效, 用户名)"""
    if not token:
        return False, None
    tokens = load_tokens()
    info = tokens.get(token)
    if not info:
        return False, None
    if info.get("expire", 0) < time.time():
        return False, None
    return True, info.get("user_name", "未知")


class TVBoxHandler(http.server.SimpleHTTPRequestHandler):
    """TVBox订阅请求处理器"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=SUBSCRIBE_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        token = query.get("token", [None])[0]

        # 根路径返回tvbox.json
        if path == "/" or path == "":
            self.path = "/tvbox.json"

        # /tvbox.json 返回配置（需要鉴权）
        if path == "/tvbox.json":
            valid, user_name = verify_token(token)
            if not valid:
                self._serve_auth_error()
                return
            self._serve_tvbox_json()
            return

        # /py/xxx.py 返回py文件（需要鉴权）
        if path.startswith("/py/"):
            valid, user_name = verify_token(token)
            if not valid:
                self._serve_auth_error()
                return
            self._serve_py_file(path[4:])
            return

        # /list 返回源列表（HTML，需要鉴权）
        if path == "/list":
            valid, user_name = verify_token(token)
            if not valid:
                self._serve_auth_error()
                return
            self._serve_list()
            return

        # /gen_token 生成token（内部接口，需要管理员密钥）
        if path == "/gen_token":
            admin_key = query.get("key", [None])[0]
            user_id = query.get("user_id", [""])[0]
            user_name = query.get("user_name", ["未知"])[0]
            if admin_key != "duande_subscribe_admin_2024":
                self.send_error(403, "Invalid admin key")
                return
            if not user_id:
                self.send_error(400, "user_id required")
                return
            token = generate_token(user_id, user_name)
            response = json.dumps({"token": token, "expire_days": 7}, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(response)))
            self.end_headers()
            self.wfile.write(response)
            return

        super().do_GET()

    def _serve_auth_error(self):
        """返回鉴权失败页面"""
        html = """<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><title>403 鉴权失败</title>
<style>body{font-family:sans-serif;background:#0D0D0D;color:#F5F5F5;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}
.box{text-align:center;padding:40px;background:#1E1E1E;border-radius:15px;border:1px solid #FF2D55;}
h1{color:#FF2D55;}p{color:#999;}</style></head>
<body><div class="box">
<h1>🔒 403 鉴权失败</h1>
<p>本订阅地址仅限群内成员使用<br>请通过机器人「📡 订阅源」按钮获取有效地址</p>
</div></body></html>"""
        response = html.encode("utf-8")
        self.send_response(403)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def _serve_tvbox_json(self):
        """返回tvbox.json，动态替换ext为完整URL"""
        config_path = os.path.join(SUBSCRIBE_DIR, "tvbox.json")
        if not os.path.exists(config_path):
            self.send_error(404, "tvbox.json not found")
            return

        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)

        # 构建基础URL
        host = self.headers.get("Host", f"127.0.0.1:{PORT}")
        base_url = f"http://{host}"

        # 替换ext为完整URL
        for site in config.get("sites", []):
            ext = site.get("ext", "")
            if ext and not ext.startswith("http"):
                site["ext"] = f"{base_url}/py/{urllib.parse.quote(ext)}"

        # 设置spider字段
        config["spider"] = f"{base_url}/tvbox.json"

        response = json.dumps(config, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(response)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(response)

    def _serve_py_file(self, filename):
        """返回py文件"""
        # 防止路径遍历
        filename = os.path.basename(filename)
        filepath = os.path.join(SUBSCRIBE_DIR, "py", filename)

        if not os.path.exists(filepath):
            self.send_error(404, f"File not found: {filename}")
            return

        with open(filepath, "rb") as f:
            content = f.read()

        self.send_response(200)
        self.send_header("Content-Type", "text/x-python; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)

    def _serve_list(self):
        """返回源列表HTML"""
        config_path = os.path.join(SUBSCRIBE_DIR, "tvbox.json")
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)

        host = self.headers.get("Host", f"127.0.0.1:{PORT}")
        sites = config.get("sites", [])

        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>段德TVBox订阅源 - 共{len(sites)}个源</title>
<style>
body {{ font-family: -apple-system, sans-serif; background: #0D0D0D; color: #F5F5F5; margin: 0; padding: 20px; }}
.container {{ max-width: 800px; margin: 0 auto; }}
h1 {{ color: #FF2D55; font-size: 24px; }}
.sub-url {{ background: #1E1E1E; padding: 15px; border-radius: 10px; margin: 20px 0; word-break: break-all; }}
.sub-url code {{ color: #FFB800; font-size: 14px; }}
.site-list {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; }}
.site-card {{ background: #1E1E1E; padding: 12px; border-radius: 8px; border: 1px solid #2A2A2A; }}
.site-name {{ font-weight: bold; color: #F5F5F5; }}
.site-key {{ font-size: 12px; color: #999; margin-top: 4px; }}
</style>
</head>
<body>
<div class="container">
<h1>📺 段德TVBox订阅源</h1>
<p>共 <strong style="color:#FF2D55;">{len(sites)}</strong> 个影视源</p>
<div class="sub-url">
<strong>订阅地址：</strong><br>
<code>http://{host}/tvbox.json</code>
</div>
<h3>源列表：</h3>
<div class="site-list">
"""
        for site in sites:
            html += f"""<div class="site-card">
<div class="site-name">{site.get('name', '')}</div>
<div class="site-key">{site.get('key', '')}</div>
</div>
"""
        html += """
</div>
</div>
</body>
</html>
"""
        response = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def log_message(self, format, *args):
        """简化日志"""
        print(f"[TVBox订阅] {args[0]}")


def main():
    os.chdir(SUBSCRIBE_DIR)
    
    class ReusableTCPServer(socketserver.ThreadingTCPServer):
        allow_reuse_address = True
        daemon_threads = True
    
    # 守护循环：崩溃后自动重启
    while True:
        try:
            with ReusableTCPServer(("0.0.0.0", PORT), TVBoxHandler) as httpd:
                print(f"=" * 50)
                print(f"📺 段德TVBox远程订阅服务启动")
                print(f"📂 订阅目录: {SUBSCRIBE_DIR}")
                print(f"🔗 订阅地址: http://127.0.0.1:{PORT}/tvbox.json")
                print(f"📋 源列表: http://127.0.0.1:{PORT}/list")
                print(f"=" * 50)
                httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[停止] TVBox订阅服务已关闭")
            break
        except Exception as e:
            print(f"[错误] 服务器异常: {e}，5秒后自动重启...")
            import time
            time.sleep(5)


if __name__ == "__main__":
    main()
