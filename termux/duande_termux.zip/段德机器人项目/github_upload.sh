#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# 自动推送订阅文件到GitHub公网仓库
# 用法：bash github_upload.sh "提交说明"
# ============================================================

PROJECT_DIR="$HOME/段德机器人项目"
SUBSCRIBE_DIR="$PROJECT_DIR/tvbox_subscribe"
CONFIG_FILE="$PROJECT_DIR/scripts/tg_config.json"

GITHUB_TOKEN=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['github']['token'])")
GITHUB_REPO=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['github']['repo'])")
GITHUB_BRANCH=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('github',{}).get('branch','main'))")

COMMIT_MSG="${1:-更新TVBox订阅源}"

if [ -z "$GITHUB_TOKEN" ] || [ "$GITHUB_TOKEN" = "你的GitHub Token" ]; then
    echo "❌ 请先在 tg_config.json 中配置GitHub Token"
    exit 1
fi

cd "$SUBSCRIBE_DIR"

if [ ! -d ".git" ]; then
    git init
    git config user.name "段德机器人"
    git config user.email "duande@termux.local"
fi

git remote remove origin 2>/dev/null || true
git remote add origin "https://x-access-token:${GITHUB_TOKEN}@github.com/${GITHUB_REPO}.git"

git add -A
git commit -m "$COMMIT_MSG" || echo "⚠️  没有新的变更"

echo "⏳ 推送到GitHub: $GITHUB_REPO ($GITHUB_BRANCH)..."
git push -u origin "$GITHUB_BRANCH" 2>&1

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 推送成功！"
    echo "📺 订阅地址: https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/tvbox.json"
    echo "🚀 加速地址: https://ghfast.top/https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/tvbox.json"
else
    echo "❌ 推送失败，请检查Token权限"
    exit 1
fi
