# 段德机器人 - Termux 直连版部署指南

## 特点
- ✅ **无代理直连**：去掉xray代理，手机网络直接访问Telegram（需手机本身能访问，或开全局VPN）
- ✅ **鉴权订阅**：内置token鉴权订阅服务器，群成员专属token（7天有效）
- ✅ **GitHub同步**：自动从GitHub仓库获取订阅地址，一键推送更新
- ✅ **完整功能**：积分系统、签到、兑换py、任务排队、@机器人反馈等全部保留

## 快速开始

### 1. 安装Termux
从 F-Droid 下载安装（不要用Google Play版）

### 2. 下载项目
把整个项目文件夹放到 Termux 的 home 目录：
```bash
# 方法1：从手机存储复制
cp -r /storage/emulated/0/Download/段德机器人项目 ~/

# 方法2：git克隆（需先配置好仓库）
git clone <你的仓库地址> ~/段德机器人项目
```

### 3. 一键安装
```bash
cd ~/段德机器人项目
chmod +x termux_install.sh termux_start.sh termux_stop.sh github_upload.sh
bash termux_install.sh
```

### 4. 编辑配置
```bash
vi scripts/tg_config.json
```
填写：
- `bot.token`：你的Bot Token
- `bot.chat_id`：目标群ID（-100开头）
- `bot.username`：Bot用户名
- `owner.user_id`：群主用户ID
- `github.token`：GitHub经典Token（勾repo权限）
- `github.repo`：仓库地址（如 `jwarrenrzflynn/TVpy`）

### 5. 启动
```bash
bash termux_start.sh
```

## 脚本说明

| 脚本 | 功能 |
|------|------|
| `termux_install.sh` | 一键安装依赖、生成配置模板 |
| `termux_start.sh` | 启动订阅服务器+机器人（直连模式） |
| `termux_stop.sh` | 停止所有服务 |
| `github_upload.sh` | 把tvbox.json和py推送到GitHub公网仓库 |

## 鉴权订阅说明

### 工作原理
1. 订阅服务器运行在本地8888端口
2. 群成员点击机器人「📡 订阅源」按钮
3. 机器人验证群成员身份，生成专属token（7天有效，同一用户复用）
4. 返回带token的地址：`http://手机IP:8888/tvbox.json?token=xxx`
5. TVBox请求该地址，服务器验证token有效后返回tvbox.json
6. 无token/错误token/过期token → 返回403鉴权失败页面

### 注意
- 手机和TVBox设备需在同一局域网（或用内网穿透）
- token存储在 `scripts/subscribe_tokens.json`
- 同一用户7天内复用token，不会重复生成

## GitHub订阅地址（公开，无鉴权）

推送订阅到GitHub后，可用公开地址：
```
https://raw.githubusercontent.com/用户名/仓库名/main/tvbox.json
```
- 优点：稳定、任何设备都能用、CDN加速
- 缺点：公开地址，任何人拿到都能用（无鉴权）

## 两种订阅模式对比

| 模式 | 地址 | 鉴权 | 稳定性 | 适用场景 |
|------|------|------|--------|----------|
| 本地鉴权 | `http://手机IP:8888/tvbox.json?token=xxx` | ✅ 群成员专属 | ⚠️ 需同局域网 | 自己用、家庭网络 |
| GitHub公开 | `https://raw.githubusercontent.com/.../tvbox.json` | ❌ 公开 | ✅ 稳定CDN | 分享给群成员、异地使用 |

## 目录结构

```
~/段德机器人项目/
├── termux_install.sh        # 一键安装
├── termux_start.sh          # 启动（直连版）
├── termux_stop.sh           # 停止
├── github_upload.sh         # GitHub推送
├── README_TERMUX.md         # 本说明
├── scripts/
│   ├── tg_bot_service.py    # 机器人主程序（已改支持no_proxy直连）
│   ├── tvbox_subscribe_server.py  # 鉴权订阅服务器
│   ├── tg_config.json       # 配置文件（no_proxy: true）
│   ├── user_points.db       # 积分数据库
│   └── subscribe_tokens.json # 鉴权token存储
├── tvbox_subscribe/
│   ├── tvbox.json           # TVBox订阅配置
│   └── py/                  # Python Spider源
└── logs/                    # 日志目录
```

## 常见问题

**Q: 机器人连不上Telegram？**
A: 直连模式需要手机本身能访问Telegram。国内网络请开全局VPN（如Clash、v2rayNG），VPN开启后机器人走手机VPN流量，无需额外配置。

**Q: 本地鉴权地址TVBox访问不了？**
A: 确认手机和TVBox设备在同一WiFi，手机防火墙没拦截8888端口。可在TVBox设备浏览器测试 `http://手机IP:8888/tvbox.json?token=xxx` 是否能打开。

**Q: 怎么保持后台运行？**
A: 执行 `termux-wake-lock` 防止CPU休眠，或在Termux设置里开启"获取唤醒锁"。

**Q: 订阅源更新了怎么同步？**
A: 把新的tvbox.json和py放到 `tvbox_subscribe/` 目录，执行 `bash github_upload.sh` 推送到GitHub，群成员用GitHub地址自动获取最新版。
