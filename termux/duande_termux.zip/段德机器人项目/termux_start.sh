#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# 段德机器人 - Termux 一键启动（无代理直连版）
# 启动：鉴权订阅服务器 + Telegram机器人
# ============================================================

PROJECT_DIR="$HOME/段德机器人项目"
SCRIPTS_DIR="$PROJECT_DIR/scripts"
LOG_DIR="$PROJECT_DIR/logs"

mkdir -p "$LOG_DIR"

echo "╔══════════════════════════════════════════════╗"
echo "║   段德机器人 - Termux 启动（直连版）        ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# 检查配置
if [ ! -f "$SCRIPTS_DIR/tg_config.json" ]; then
    echo "❌ 配置文件不存在: $SCRIPTS_DIR/tg_config.json"
    exit 1
fi

# 检查no_proxy是否开启
NO_PROXY=$(python3 -c "import json; print(json.load(open('$SCRIPTS_DIR/tg_config.json')).get('no_proxy', False))")
if [ "$NO_PROXY" != "True" ]; then
    echo "⚠️  警告: 配置中 no_proxy 未开启，当前为直连版脚本"
    echo "   如需使用代理，请用原版启动脚本"
fi

# 杀掉旧进程
echo "[1/3] 清理旧进程..."
pkill -9 -f "tg_bot_service.py" 2>/dev/null || true
pkill -9 -f "tvbox_subscribe_server" 2>/dev/null || true
sleep 2
echo "✅ 旧进程已清理"

# 启动鉴权订阅服务器
echo ""
echo "[2/3] 启动TVBox鉴权订阅服务器 (端口8888)..."
cd "$SCRIPTS_DIR"
nohup python3 tvbox_subscribe_server.py 8888 >> "$LOG_DIR/tvbox_subscribe.log" 2>&1 &
sleep 2
if curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/tvbox.json 2>/dev/null | grep -q "403"; then
    echo "✅ 订阅服务器启动成功（鉴权生效，无token返回403）"
else
    echo "⚠️  订阅服务器可能未启动，请检查日志"
fi

# 启动机器人（无代理直连）
echo ""
echo "[3/3] 启动Telegram机器人（直连模式）..."
cd "$SCRIPTS_DIR"
nohup python3 tg_bot_service.py --silent >> "$LOG_DIR/bot.log" 2>&1 &
sleep 5
if pgrep -f "tg_bot_service.py" > /dev/null; then
    echo "✅ 机器人启动成功"
else
    echo "❌ 机器人启动失败，请检查日志: tail -f $LOG_DIR/bot.log"
    exit 1
fi

# 从GitHub获取最新订阅地址
echo ""
echo "📡 从GitHub获取订阅地址..."
GITHUB_REPO=$(python3 -c "import json; print(json.load(open('$SCRIPTS_DIR/tg_config.json'))['github']['repo'])")
GITHUB_BRANCH=$(python3 -c "import json; print(json.load(open('$SCRIPTS_DIR/tg_config.json')).get('github',{}).get('branch','main'))")
SUB_URL="https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/tvbox.json"
FAST_URL="https://ghfast.top/https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/tvbox.json"

echo "  GitHub订阅地址: $SUB_URL"
echo "  国内加速地址: $FAST_URL"
echo ""
echo "  💡 群成员点击机器人「📡 订阅源」按钮获取带鉴权的本地地址"
echo "  💡 管理员可用 bash github_upload.sh 推送最新订阅到GitHub"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   全部启动完成！                              ║"
echo "╠══════════════════════════════════════════════╣"
echo "║ 查看机器人日志:                               ║"
echo "║   tail -f $LOG_DIR/bot.log                 ║"
echo "║                                              ║"
echo "║ 查看订阅服务器日志:                           ║"
echo "║   tail -f $LOG_DIR/tvbox_subscribe.log     ║"
echo "║                                              ║"
echo "║ 停止所有服务:                                 ║"
echo "║   bash $PROJECT_DIR/termux_stop.sh          ║"
echo "║                                              ║"
echo "║ 推送订阅到GitHub:                             ║"
echo "║   bash $PROJECT_DIR/github_upload.sh         ║"
echo "╚══════════════════════════════════════════════╝"
