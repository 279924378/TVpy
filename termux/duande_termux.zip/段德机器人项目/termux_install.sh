#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# 段德机器人项目 - Termux 一键安装（无代理直连版）
# ============================================================

set -e

PROJECT_DIR="$HOME/段德机器人项目"
SCRIPTS_DIR="$PROJECT_DIR/scripts"
LOG_DIR="$PROJECT_DIR/logs"

echo "╔══════════════════════════════════════════════╗"
echo "║   段德机器人 - Termux 安装（直连版）        ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ========== 1. 安装系统依赖 ==========
echo "[1/4] 安装系统依赖..."
pkg update -y
pkg upgrade -y
pkg install -y python git wget curl openssl-tool jq
echo "✅ 系统依赖安装完成"

# ========== 2. 创建目录 ==========
echo ""
echo "[2/4] 创建项目目录..."
mkdir -p "$SCRIPTS_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$PROJECT_DIR/tvbox_subscribe/py"
echo "✅ 目录创建完成"

# ========== 3. 配置Python ==========
echo ""
echo "[3/4] 配置Python环境..."
python3 -m pip install --upgrade pip -q
echo "✅ Python环境配置完成（纯标准库项目，无需额外包）"

# ========== 4. 生成配置模板 ==========
echo ""
echo "[4/4] 生成配置文件..."
if [ ! -f "$SCRIPTS_DIR/tg_config.json" ]; then
cat > "$SCRIPTS_DIR/tg_config.json" << 'EOF'
{
  "bot": {
    "token": "你的Bot Token",
    "chat_id": "-100你的群ID",
    "username": "你的Bot用户名"
  },
  "owner": {
    "user_id": "你的用户ID",
    "nickname": "群主昵称"
  },
  "github": {
    "token": "你的GitHub Token",
    "repo": "用户名/仓库名",
    "branch": "main"
  },
  "no_proxy": true,
  "subscribe_server": {
    "port": 8888,
    "token_expire_days": 7
  },
  "history_file": "tg_push_history.json"
}
EOF
echo "  ⚠️  请编辑 $SCRIPTS_DIR/tg_config.json 填写配置"
else
echo "  配置文件已存在，跳过"
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   安装完成！下一步：                           ║"
echo "╠══════════════════════════════════════════════╣"
echo "║ 1. 编辑配置:                                  ║"
echo "║    vi $SCRIPTS_DIR/tg_config.json          ║"
echo "║                                              ║"
echo "║ 2. 把项目脚本放到:                            ║"
echo "║    $SCRIPTS_DIR/                            ║"
echo "║    (tg_bot_service.py, tvbox_subscribe_server.py) ║"
echo "║                                              ║"
echo "║ 3. 把订阅文件放到:                            ║"
echo "║    $PROJECT_DIR/tvbox_subscribe/           ║"
echo "║                                              ║"
echo "║ 4. 启动:                                      ║"
echo "║    bash $PROJECT_DIR/termux_start.sh        ║"
echo "╚══════════════════════════════════════════════╝"
