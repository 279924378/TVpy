#!/data/data/com.termux/files/usr/bin/bash
echo "停止所有服务..."
pkill -9 -f "tg_bot_service.py" 2>/dev/null && echo "  ✅ 机器人已停止" || echo "  ⚠️  机器人未运行"
pkill -9 -f "tvbox_subscribe_server" 2>/dev/null && echo "  ✅ 订阅服务器已停止" || echo "  ⚠️  订阅服务器未运行"
echo "全部停止完成"
